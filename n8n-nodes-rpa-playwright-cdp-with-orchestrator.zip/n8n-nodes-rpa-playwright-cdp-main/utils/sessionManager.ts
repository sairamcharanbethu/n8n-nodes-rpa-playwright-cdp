import playwright, { Browser } from 'playwright';
import http, { RequestOptions, IncomingMessage } from 'http';
import { URL } from 'url';
import { SessionObject } from './SessionObject';

export interface LaunchBrowserParams {
  seleniumHubUrl: string;
  profileDir: string;
  navigateUrl: string;
  ignoreCertificateErrors?: boolean;
  browserArgs?: string[];
  windowSize?: string; // e.g. "1920,1080"
  uniqueSession?: boolean; // Generate unique profile for concurrent sessions
}

function parseUrl(url: string): URL {
  return new URL(url);
}

function reqJSON(
  method: string,
  url: string,
  body?: any,
  timeoutMs: number = 60000 // Increased to 60s for session creation queue
): Promise<{ status: number; data: any; raw?: string }> {
  return new Promise((resolve, reject) => {
    const urlObj = parseUrl(url);
    const options: RequestOptions = {
      method,
      hostname: urlObj.hostname,
      port: parseInt(urlObj.port) || (urlObj.protocol === 'https:' ? 443 : 80),
      path: urlObj.pathname,
      headers: { 'Content-Type': 'application/json' },
      timeout: timeoutMs,
    };

    const req = http.request(options, (res: IncomingMessage) => {
      let data = '';
      res.on('data', (chunk: Buffer) => {
        data += chunk.toString();
      });
      res.on('end', () => {
        try {
          const parsed = data ? JSON.parse(data) : {};
          resolve({
            status: res.statusCode || 500,
            data: parsed,
            raw: data,
          });
        } catch (e) {
          resolve({ status: res.statusCode || 500, data: {}, raw: data });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error(`Request timeout after ${timeoutMs}ms`)));

    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

export async function launchGoogleSession(params: LaunchBrowserParams): Promise<SessionObject> {
  let sessionId: string | null = null;
  let browser: Browser | null = null;

  try {
    // Generate unique profile directory for concurrent sessions
    // Use /tmp for unique sessions so they auto-clean on container restart
    const profileDir = params.uniqueSession 
      ? `/tmp/chrome-session-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`
      : params.profileDir;

    // Anti-detection browser arguments
    const browserArgs = [
      `--user-data-dir=${profileDir}`,
      '--profile-directory=Default',
      '--no-sandbox',
      '--disable-dev-shm-usage',
      ...(params.ignoreCertificateErrors ? ['--ignore-certificate-errors'] : []),
      ...(params.windowSize ? [`--window-size=${params.windowSize}`] : []),
      // Disable automation flags
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      // Additional stealth settings
      '--disable-web-security',
      '--disable-features=VizDisplayCompositor',
      '--disable-gpu',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-infobars',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--disable-background-timer-throttling',
      '--disable-breakpad',
      '--disable-client-side-phishing-detection',
      '--disable-component-update',
      '--disable-default-apps',
      '--disable-hang-monitor',
      '--disable-popup-blocking',
      '--disable-prompt-on-repost',
      '--disable-sync',
      '--disable-translate',
      '--metrics-recording-only',
      '--safebrowsing-disable-auto-update',
      '--enable-automation=false',
      '--password-store=basic',
      '--use-mock-keychain',
      ...(params.browserArgs || []),
      '--remote-debugging-port=0',
    ];

    const sessionResp = await reqJSON('POST', `${params.seleniumHubUrl}/session`, {
      capabilities: {
        alwaysMatch: {
          browserName: 'chrome',
          'goog:chromeOptions': {
            args: browserArgs,
            excludeSwitches: ['enable-automation', 'enable-logging'],
            useAutomationExtension: false,
          },
          // Explicitly request CDP
          'se:cdp': true,
          'webSocketUrl': true,
        },
        firstMatch: [{}],
      },
    }, 120000); // 2 minute timeout for session queue

    // Check for HTTP errors
    if (sessionResp.status !== 200) {
      const errorMsg = sessionResp.data?.value?.message || sessionResp.raw || 'Unknown error';
      throw new Error(`Selenium Hub returned HTTP ${sessionResp.status}: ${errorMsg}`);
    }

    // Check for WebDriver protocol errors
    if (sessionResp.data?.value?.error) {
      throw new Error(`Selenium error: ${sessionResp.data.value.error} - ${sessionResp.data.value.message || ''}`);
    }

    sessionId = sessionResp.data.value?.sessionId;
    const capabilities = sessionResp.data.value?.capabilities || {};
    
    // Try multiple ways to get CDP URL
    let cdpUrl = capabilities['se:cdp'] as string;
    
    if (!cdpUrl && sessionId) {
      // Fallback: construct CDP URL from session ID (Selenium Grid 4 format)
      const hubUrlObj = parseUrl(params.seleniumHubUrl);
      cdpUrl = `ws://${hubUrlObj.hostname}:${hubUrlObj.port || 4444}/session/${sessionId}/se/cdp`;
    }
    
    if (!cdpUrl || !sessionId) {
      throw new Error(
        `Failed to create session. ` +
        `HTTP Status: ${sessionResp.status}, ` +
        `Session ID: ${sessionId}, ` +
        `Capabilities: ${JSON.stringify(capabilities)}, ` +
        `Raw Response: ${sessionResp.raw?.substring(0, 500) || 'empty'}`
      );
    }

    // Wait a moment for CDP to be ready (helps with concurrent sessions)
    await new Promise(resolve => setTimeout(resolve, 500));

    // Retry CDP connection up to 3 times
    let lastError: Error | null = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        browser = await playwright.chromium.connectOverCDP(cdpUrl, {
          timeout: 10000,
        });
        break; // Success, exit loop
      } catch (err: any) {
        lastError = err;
        if (attempt < 3) {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
      }
    }
    
    if (!browser) {
      throw new Error(`Failed to connect to CDP after 3 attempts: ${lastError?.message}. CDP URL: ${cdpUrl}`);
    }

  	const context = browser.contexts()[0] || (await browser.newContext());
   	const page = context.pages().length > 0 ? context.pages()[0] : await context.newPage();

    // Additional stealth configurations via CDP
    const client = await context.newCDPSession(page);
    
    // Override navigator.webdriver
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });
    });

    // Set realistic user agent
    await page.evaluate(() => {
      Object.defineProperty(navigator, 'platform', {
        get: () => 'Win32',
      });
      Object.defineProperty(navigator, 'vendor', {
        get: () => 'Google Inc.',
      });
      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
      });
    });

    // Set permissions
    await context.grantPermissions(['geolocation', 'notifications']);

    await page.goto(params.navigateUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 15000,
    });

    const title = await page.title();
    await browser.close();

    return {
      success: true,
      sessionId: sessionId || '',
      cdpUrl: cdpUrl || '',
      seleniumHubUrl: params.seleniumHubUrl,
      pageTitle: title,
      currentUrl: page.url(),
      step: 'launch',
      message: 'Website session launched successfully',
      timestamp: new Date().toISOString(),
      profileDir,
      uniqueSession: params.uniqueSession,
    };
  } catch (error: any) {
    if (browser) await browser.close().catch(() => {});
    if (sessionId) {
      await reqJSON('DELETE', `${params.seleniumHubUrl}/session/${sessionId}`).catch(() => {});
    }
    return {
      success: false,
      error: error.message || String(error),
      step: 'launch',
      timestamp: new Date().toISOString(),
      sessionId: sessionId || '',
      cdpUrl: '',
      profileDir: params.uniqueSession ? undefined : params.profileDir,
      uniqueSession: params.uniqueSession,
    };
  }
}

export async function navigateWithSession(
  session: SessionObject,
  navigateUrl: string
): Promise<SessionObject> {
  let browser: Browser | null = null;
  try {
    browser = await playwright.chromium.connectOverCDP(session.cdpUrl);
    const context = browser.contexts()[0] || (await browser.newContext());
    const page = context.pages().length ? context.pages()[0] : await context.newPage();

    // Apply stealth scripts
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });
    });

    await page.goto(navigateUrl, {
      waitUntil: 'networkidle',
      timeout: 30000,
    });

    const title = await page.title();
    await browser.close();

    return {
      ...session,
      currentUrl: page.url(),
      pageTitle: title,
      success: true,
      step: 'navigate',
      message: `Navigation to ${navigateUrl} successful`,
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    if (browser) await browser.close().catch(() => {});
    return {
      ...session,
      success: false,
      error: error.message || String(error),
      step: 'navigate',
      timestamp: new Date().toISOString(),
    };
  }
}

export async function closeSession(session: SessionObject): Promise<SessionObject> {
  try {
    if (!session.seleniumHubUrl || !session.sessionId) {
      throw new Error('Missing seleniumHubUrl or sessionId. These are required to close the session.');
    }

    // Ensure seleniumHubUrl doesn't have trailing slash
    const hubUrl = session.seleniumHubUrl.replace(/\/$/, '');
    const closeUrl = `${hubUrl}/session/${session.sessionId}`;

    // Send DELETE request and verify response
    const response = await reqJSON('DELETE', closeUrl);
    
    // Check if the DELETE was successful
    // Selenium returns 200 for success, 404 if session doesn't exist
    if (response.status !== 200 && response.status !== 404) {
      const errorMsg = response.data?.value?.message || response.raw || `HTTP ${response.status}`;
      throw new Error(`Failed to delete session: ${errorMsg}`);
    }

    // Verify session is actually gone by checking status
    const verifyResp = await reqJSON('GET', `${hubUrl}/session/${session.sessionId}`);
    if (verifyResp.status === 200) {
      // Session still exists after DELETE - this is a problem
      // Try deleting again with a small delay
      await new Promise(resolve => setTimeout(resolve, 500));
      const retryDelete = await reqJSON('DELETE', closeUrl);
      
      // Check again
      const retryVerify = await reqJSON('GET', `${hubUrl}/session/${session.sessionId}`);
      if (retryVerify.status === 200) {
        throw new Error(`Session ${session.sessionId} still active after DELETE. DELETE returned: ${response.status}. The session may be locked by an active connection.`);
      }
    }
    // Status 404 or other error means session is gone - that's what we want
    
    // Note: Unique session profiles are stored in /tmp on the Selenium node
    // and will be automatically cleaned up on container restart
    const cleanupNote = session.uniqueSession 
      ? ' (Temporary profile will auto-clean on container restart)'
      : '';

    return {
      ...session,
      success: true,
      step: 'close',
      message: `Session closed successfully${cleanupNote}`,
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    return {
      ...session,
      success: false,
      error: error.message || String(error),
      step: 'close',
      timestamp: new Date().toISOString(),
    };
  }
}

export interface CleanupResult {
  closed: number;
  failed: number;
  sessions: { sessionId: string; status: 'closed' | 'failed'; error?: string }[];
}

export async function cleanupAllSessions(seleniumHubUrl: string): Promise<CleanupResult> {
  const result: CleanupResult = {
    closed: 0,
    failed: 0,
    sessions: [],
  };

  try {
    // Get all active sessions from Selenium Grid status API
    const hubUrl = seleniumHubUrl.replace(/\/$/, '');
    const statusResp = await reqJSON('GET', `${hubUrl}/status`);
    
    if (statusResp.status !== 200) {
      throw new Error(`Failed to get grid status: HTTP ${statusResp.status}`);
    }

    // Extract sessions from grid status
    // Selenium Grid 4 format: value.nodes[].slots[].session
    const nodes = statusResp.data?.value?.nodes || [];
    const sessionIds: string[] = [];

    for (const node of nodes) {
      const slots = node.slots || [];
      for (const slot of slots) {
        if (slot.session?.sessionId) {
          sessionIds.push(slot.session.sessionId);
        }
      }
    }

    // Close each session
    for (const sessionId of sessionIds) {
      try {
        await reqJSON('DELETE', `${hubUrl}/session/${sessionId}`);
        result.closed++;
        result.sessions.push({ sessionId, status: 'closed' });
      } catch (e: any) {
        result.failed++;
        result.sessions.push({ sessionId, status: 'failed', error: e.message });
      }
    }

    return result;
  } catch (error: any) {
    throw new Error(`Failed to cleanup sessions: ${error.message}`);
  }
}
