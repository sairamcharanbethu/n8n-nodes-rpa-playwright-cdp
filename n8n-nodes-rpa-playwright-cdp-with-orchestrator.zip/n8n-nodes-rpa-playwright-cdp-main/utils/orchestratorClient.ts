/**
 * Orchestrator Client
 * Handles communication with the Playwright Browser Orchestrator service
 */

import http from 'http';
import https from 'https';
import { URL } from 'url';

export interface OrchestratorSession {
  sessionId: string;
  cdpUrl: string;
  status: string;
  mode: 'ephemeral' | 'persistent';
  profileId?: string;
  workerId: string;
  createdAt: string;
  expiresAt: string;
  vncEnabled: boolean;
  vncPort?: number;
  vncHost?: string;
}

export interface CreateSessionOptions {
  mode?: 'ephemeral' | 'persistent';
  profileId?: string;
  workflowId?: string;
  executionId?: string;
  timeout?: number;  // seconds
}

export interface OrchestratorResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

/**
 * Make HTTP request to orchestrator
 */
function request<T>(
  method: string,
  url: string,
  body?: any,
  timeoutMs: number = 60000
): Promise<OrchestratorResponse<T>> {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const isHttps = urlObj.protocol === 'https:';
    const lib = isHttps ? https : http;

    const options = {
      method,
      hostname: urlObj.hostname,
      port: parseInt(urlObj.port) || (isHttps ? 443 : 80),
      path: urlObj.pathname + urlObj.search,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      timeout: timeoutMs,
    };

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk.toString();
      });
      res.on('end', () => {
        try {
          const parsed = data ? JSON.parse(data) : {};
          resolve(parsed as OrchestratorResponse<T>);
        } catch (e) {
          resolve({
            success: false,
            error: `Failed to parse response: ${data.substring(0, 200)}`,
            timestamp: new Date().toISOString(),
          });
        }
      });
    });

    req.on('error', (error) => {
      reject(new Error(`Orchestrator request failed: ${error.message}`));
    });

    req.on('timeout', () => {
      req.destroy(new Error(`Request timeout after ${timeoutMs}ms`));
    });

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

/**
 * Create a new browser session
 */
export async function createSession(
  orchestratorUrl: string,
  options: CreateSessionOptions = {}
): Promise<OrchestratorSession> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions`;
  
  const response = await request<OrchestratorSession>('POST', url, {
    mode: options.mode || 'ephemeral',
    profileId: options.profileId,
    workflowId: options.workflowId,
    executionId: options.executionId,
    timeout: options.timeout || 300,
  }, 120000); // 2 minute timeout for session creation

  if (!response.success || !response.data) {
    throw new Error(response.error || 'Failed to create session');
  }

  return {
    sessionId: response.data.sessionId,
    cdpUrl: response.data.cdpUrl,
    status: response.data.status,
    mode: options.mode || 'ephemeral',
    profileId: options.profileId,
    workerId: response.data.workerId || '',
    createdAt: response.data.createdAt || new Date().toISOString(),
    expiresAt: response.data.expiresAt || '',
    vncEnabled: false,
  };
}

/**
 * Get session details
 */
export async function getSession(
  orchestratorUrl: string,
  sessionId: string
): Promise<OrchestratorSession | null> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}`;
  
  const response = await request<OrchestratorSession>('GET', url);

  if (!response.success) {
    if (response.error?.includes('not found')) {
      return null;
    }
    throw new Error(response.error || 'Failed to get session');
  }

  return response.data || null;
}

/**
 * Get CDP URL for a session (also touches the session to keep it alive)
 */
export async function getCdpUrl(
  orchestratorUrl: string,
  sessionId: string
): Promise<string> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}/cdp`;
  
  const response = await request<{ cdpUrl: string }>('GET', url);

  if (!response.success || !response.data?.cdpUrl) {
    throw new Error(response.error || 'Failed to get CDP URL');
  }

  return response.data.cdpUrl;
}

/**
 * Close a session
 */
export async function closeSession(
  orchestratorUrl: string,
  sessionId: string,
  force = false
): Promise<void> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}${force ? '?force=true' : ''}`;
  
  const response = await request('DELETE', url);

  if (!response.success) {
    throw new Error(response.error || 'Failed to close session');
  }
}

/**
 * Touch session (keep alive)
 */
export async function touchSession(
  orchestratorUrl: string,
  sessionId: string
): Promise<void> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}/touch`;
  
  const response = await request('POST', url);

  if (!response.success) {
    throw new Error(response.error || 'Failed to touch session');
  }
}

/**
 * Enable VNC for debugging
 */
export async function enableVnc(
  orchestratorUrl: string,
  sessionId: string
): Promise<{ port: number; host: string }> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}/vnc`;
  
  const response = await request<{ port: number; host: string }>('POST', url);

  if (!response.success || !response.data) {
    throw new Error(response.error || 'Failed to enable VNC');
  }

  return response.data;
}

/**
 * Disable VNC
 */
export async function disableVnc(
  orchestratorUrl: string,
  sessionId: string
): Promise<void> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}/vnc`;
  
  const response = await request('DELETE', url);

  if (!response.success) {
    throw new Error(response.error || 'Failed to disable VNC');
  }
}

/**
 * Capture screenshot
 */
export async function captureScreenshot(
  orchestratorUrl: string,
  sessionId: string,
  options: { fullPage?: boolean } = {}
): Promise<{ url: string }> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions/${sessionId}/screenshot`;
  
  const response = await request<{ url: string }>('POST', url, options);

  if (!response.success || !response.data) {
    throw new Error(response.error || 'Failed to capture screenshot');
  }

  return response.data;
}

/**
 * Get pool status
 */
export async function getPoolStatus(
  orchestratorUrl: string
): Promise<{
  totalCapacity: number;
  activeSession: number;
  availableSlots: number;
  queuedRequests: number;
}> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/pool`;
  
  const response = await request<any>('GET', url);

  if (!response.success || !response.data) {
    throw new Error(response.error || 'Failed to get pool status');
  }

  return response.data;
}

/**
 * List all sessions
 */
export async function listSessions(
  orchestratorUrl: string
): Promise<OrchestratorSession[]> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/sessions`;
  
  const response = await request<{ sessions: OrchestratorSession[]; total: number }>('GET', url);

  if (!response.success || !response.data) {
    throw new Error(response.error || 'Failed to list sessions');
  }

  return response.data.sessions;
}

/**
 * Close all sessions (cleanup)
 */
export async function closeAllSessions(
  orchestratorUrl: string
): Promise<{ closed: number; failed: number }> {
  const sessions = await listSessions(orchestratorUrl);
  let closed = 0;
  let failed = 0;

  for (const session of sessions) {
    try {
      await closeSession(orchestratorUrl, session.sessionId, true);
      closed++;
    } catch (e) {
      failed++;
    }
  }

  return { closed, failed };
}

/**
 * Health check
 */
export async function healthCheck(
  orchestratorUrl: string
): Promise<{ status: string; healthy: boolean }> {
  const url = `${orchestratorUrl.replace(/\/$/, '')}/health`;
  
  try {
    const response = await request<{ status: string }>('GET', url, undefined, 5000);
    return {
      status: response.data?.status || 'unknown',
      healthy: response.success && response.data?.status !== 'unhealthy',
    };
  } catch (e) {
    return { status: 'offline', healthy: false };
  }
}
