export interface SessionObject {
  sessionId: string;
  cdpUrl: string;
  seleniumHubUrl?: string;
  success: boolean;
  timestamp: string;
  currentUrl?: string;
  pageTitle?: string;
  step?: string;
  message?: string;
  error?: string;
  profileDir?: string;       // The actual profile directory used
  uniqueSession?: boolean;   // Whether to cleanup profile on close (legacy)
  
  // Orchestrator-specific fields
  orchestratorUrl?: string;  // URL of the orchestrator service
  mode?: 'ephemeral' | 'persistent';  // Session mode
  profileId?: string;        // Profile ID for persistent sessions
  workerId?: string;         // Worker container ID
  expiresAt?: string;        // Session expiration time
  vncEnabled?: boolean;      // Whether VNC is enabled
  vncPort?: number;          // VNC port if enabled
  vncHost?: string;          // VNC host if enabled
}
