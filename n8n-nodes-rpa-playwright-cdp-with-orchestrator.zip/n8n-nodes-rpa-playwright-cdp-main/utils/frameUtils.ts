import { Page, Frame, ElementHandle } from 'playwright';

/**
 * Frame handling options for node properties
 */
export const frameHandlingProperties = [
  {
    displayName: 'Frame Handling',
    name: 'frameHandling',
    type: 'options' as const,
    default: 'auto',
    options: [
      {
        name: 'Auto-Detect (Recommended)',
        value: 'auto',
        description: 'Automatically search all frames to find the element',
      },
      {
        name: 'Main Page Only',
        value: 'main',
        description: 'Only search in the main page, not in iframes',
      },
      {
        name: 'Specific Iframe',
        value: 'specific',
        description: 'Manually specify which iframe to use',
      },
    ],
    description: 'How to handle iframes when searching for elements',
  },
  {
    displayName: 'Iframe Selector Strategy',
    name: 'iframeSelectorStrategy',
    type: 'options' as const,
    default: 'css',
    displayOptions: {
      show: {
        frameHandling: ['specific'],
      },
    },
    options: [
      {
        name: 'CSS Selector',
        value: 'css',
        description: 'CSS selector for the iframe element',
      },
      {
        name: 'Frame Name',
        value: 'name',
        description: 'Name attribute of the iframe',
      },
      {
        name: 'Frame URL (contains)',
        value: 'url',
        description: 'Part of the iframe URL',
      },
      {
        name: 'Index',
        value: 'index',
        description: 'Iframe index (0 = first iframe)',
      },
    ],
    description: 'How to locate the iframe',
  },
  {
    displayName: 'Iframe Selector',
    name: 'iframeSelector',
    type: 'string' as const,
    default: '',
    displayOptions: {
      show: {
        frameHandling: ['specific'],
      },
    },
    placeholder: 'e.g., #login-frame, main-frame, login.html, or 0',
    description: 'The iframe identifier based on chosen strategy',
  },
];

/**
 * Result of finding an element in frames
 */
export interface FrameSearchResult {
  element: ElementHandle | null;
  frame: Page | Frame;
  frameInfo: {
    frameHandling: string;
    framesFound?: number;
    framesSearched?: Array<{ url: string; name: string; found: boolean; error?: boolean }>;
    elementFoundInFrame?: { url: string; name: string };
    iframeStrategy?: string;
    iframeSelector?: string;
    iframeUrl?: string;
    iframeFound?: boolean;
  };
}

/**
 * Find an element across all frames or in a specific frame
 */
export async function findElementInFrames(
  page: Page,
  selector: string,
  options: {
    frameHandling: string;
    iframeSelectorStrategy?: string;
    iframeSelector?: string;
    waitTimeout: number;
    waitState?: 'visible' | 'attached' | 'hidden' | 'detached';
  }
): Promise<FrameSearchResult> {
  const { frameHandling, iframeSelectorStrategy, iframeSelector, waitTimeout, waitState = 'visible' } = options;
  
  const frameInfo: FrameSearchResult['frameInfo'] = {
    frameHandling,
  };

  if (frameHandling === 'auto') {
    // AUTO-DETECT: Search through all frames to find the element
    const allFrames = page.frames();
    frameInfo.framesFound = allFrames.length;
    frameInfo.framesSearched = [];

    let element: ElementHandle | null = null;
    let targetFrame: Page | Frame = page;

    for (const frame of allFrames) {
      const info = { url: frame.url(), name: frame.name() || '(main)', found: false, error: false };
      try {
        // Try to find element in this frame with a short timeout
        const el = await frame.waitForSelector(selector, {
          timeout: Math.min(2000, waitTimeout / Math.max(allFrames.length, 1)),
          state: waitState,
        }).catch(() => null);

        if (el) {
          element = el;
          targetFrame = frame;
          info.found = true;
          frameInfo.elementFoundInFrame = { url: frame.url(), name: frame.name() || '(main)' };
          frameInfo.framesSearched!.push(info);
          break;
        } else {
          frameInfo.framesSearched!.push(info);
        }
      } catch {
        info.error = true;
        frameInfo.framesSearched!.push(info);
      }
    }

    // If not found in quick search, do a longer wait on all frames
    if (!element) {
      for (const frame of allFrames) {
        try {
          const el = await frame.$(selector);
          if (el) {
            element = el;
            targetFrame = frame;
            frameInfo.elementFoundInFrame = { url: frame.url(), name: frame.name() || '(main)' };
            break;
          }
        } catch {
          // Continue to next frame
        }
      }
    }

    if (!element) {
      const frameList = allFrames.map(f => `${f.name() || '(main)'}: ${f.url()}`).join('\n  - ');
      throw new Error(
        `Element not found with selector "${selector}" in any frame.\n\n` +
        `Searched ${allFrames.length} frames:\n  - ${frameList}\n\n` +
        `Tip: Check if the selector is correct using browser DevTools.`
      );
    }

    return { element, frame: targetFrame, frameInfo };

  } else if (frameHandling === 'specific' && iframeSelector) {
    // SPECIFIC IFRAME: User specified which iframe to use
    frameInfo.iframeStrategy = iframeSelectorStrategy;
    frameInfo.iframeSelector = iframeSelector;

    let frame: Frame | null = null;
    
    switch (iframeSelectorStrategy) {
      case 'css': {
        const iframeCss = iframeSelector.startsWith('#') || iframeSelector.startsWith('.') || iframeSelector.startsWith('[')
          ? iframeSelector
          : `iframe[id="${iframeSelector}"], iframe[name="${iframeSelector}"], iframe.${iframeSelector}`;
        await page.waitForSelector(iframeCss, { timeout: waitTimeout });
        const frameElement = await page.$(iframeCss);
        if (frameElement) {
          frame = await frameElement.contentFrame();
        }
        break;
      }
      case 'name': {
        await page.waitForFunction(
          (name: string) => {
            const win = globalThis as any;
            const frames = win.document.querySelectorAll('iframe');
            for (const f of frames) {
              if (f.name === name || f.id === name) return true;
            }
            return false;
          },
          iframeSelector,
          { timeout: waitTimeout }
        );
        frame = page.frame({ name: iframeSelector });
        break;
      }
      case 'url': {
        await page.waitForFunction(
          (urlPart: string) => {
            const win = globalThis as any;
            const frames = win.document.querySelectorAll('iframe');
            for (const f of frames) {
              if (f.src && f.src.includes(urlPart)) return true;
            }
            return false;
          },
          iframeSelector,
          { timeout: waitTimeout }
        );
        frame = page.frame({ url: new RegExp(iframeSelector) });
        break;
      }
      case 'index': {
        const index = parseInt(iframeSelector, 10) || 0;
        const frames = page.frames();
        if (frames.length > index + 1) {
          frame = frames[index + 1];
        }
        break;
      }
    }

    if (!frame) {
      throw new Error(
        `Iframe not found with ${iframeSelectorStrategy}: ${iframeSelector}. ` +
        `Available frames: ${page.frames().map(f => f.url()).join(', ')}`
      );
    }

    frameInfo.iframeUrl = frame.url();
    frameInfo.iframeFound = true;

    // Now find element in the specified iframe
    await frame.waitForSelector(selector, { timeout: waitTimeout, state: waitState });
    const element = await frame.$(selector);
    
    if (!element) {
      throw new Error(`Element not found with selector: ${selector} (inside iframe)`);
    }

    return { element, frame, frameInfo };

  } else {
    // MAIN PAGE ONLY
    await page.waitForSelector(selector, { timeout: waitTimeout, state: waitState });
    const element = await page.$(selector);
    
    if (!element) {
      throw new Error(`Element not found with selector: ${selector}`);
    }

    return { element, frame: page, frameInfo };
  }
}

/**
 * Get the page context for operations that need it (like keyboard input or downloads)
 */
export function getPageFromFrame(frame: Page | Frame): Page {
  // Check if it's a Frame by checking for the page() method
  if ('page' in frame && typeof (frame as Frame).page === 'function') {
    return (frame as Frame).page();
  }
  return frame as Page;
}
