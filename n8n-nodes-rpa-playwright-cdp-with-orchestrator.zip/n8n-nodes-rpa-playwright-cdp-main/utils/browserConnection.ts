/**
 * Browser Connection Utility
 * Handles connection to browsers via CDP or Playwright server endpoints
 */

import { chromium, Browser } from 'playwright';
import { SessionObject } from './SessionObject';

/**
 * Connect to a browser session using the appropriate method
 * - For orchestrator sessions: uses chromium.connect() (Playwright server endpoint)
 * - For Selenium/CDP sessions: uses chromium.connectOverCDP()
 */
export async function connectToBrowser(
  session: SessionObject,
  options: { timeout?: number } = {}
): Promise<Browser> {
  const timeout = options.timeout || 30000;
  const cdpUrl = session.cdpUrl;

  if (!cdpUrl) {
    throw new Error('No CDP/WebSocket URL available in session');
  }

  // Determine connection method based on session type
  if (session.orchestratorUrl) {
    // Orchestrator mode - use Playwright's connect() method
    // The wsEndpoint from launchServer() is Playwright-specific
    return chromium.connect(cdpUrl, { timeout });
  } else {
    // Legacy Selenium/CDP mode - use connectOverCDP
    return chromium.connectOverCDP(cdpUrl, { timeout });
  }
}

/**
 * Connect to browser using URL directly (for nodes that don't have full session object)
 * Defaults to Playwright connect() for ws:// URLs, CDP for http:// URLs
 */
export async function connectToBrowserByUrl(
  cdpUrl: string,
  isOrchestrator: boolean = false,
  options: { timeout?: number } = {}
): Promise<Browser> {
  const timeout = options.timeout || 30000;

  if (isOrchestrator || cdpUrl.startsWith('ws://')) {
    // Playwright server endpoint
    return chromium.connect(cdpUrl, { timeout });
  } else {
    // CDP endpoint (typically http:// or ws:// with /devtools path)
    return chromium.connectOverCDP(cdpUrl, { timeout });
  }
}
