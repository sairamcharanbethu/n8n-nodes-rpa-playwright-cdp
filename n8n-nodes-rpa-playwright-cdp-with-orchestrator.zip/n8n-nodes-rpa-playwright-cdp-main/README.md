# n8n-nodes-rpa-playwright

Custom n8n nodes for browser automation using Playwright and Selenium Grid with CDP.

## Features

- **Auto-frame detection** - Automatically finds elements inside iframes
- **Multiple selector strategies** - CSS, XPath, ID, Name, Class, Placeholder, Label, ARIA
- **Smart typing** - Auto-detects best method for React/Angular/Vue apps
- **Retry logic** - Automatic fallback to alternative methods

## Nodes

| Node | Description |
|------|-------------|
| **Launch Browser** | Start browser session via Selenium Grid |
| **Navigate** | Go to URL |
| **Close Browser** | End browser session |
| **Type Into** | Type text into inputs (with iframe support) |
| **Click** | Click elements (with iframe support) |
| **Get Text** | Extract text from elements |
| **Get Table** | Scrape tables as JSON |
| **Take Screenshot** | Capture page or element screenshots |
| **Element Exists** | Check if element is present |
| **Download File** | Trigger and capture file downloads |
| **Select Option** | Select dropdown options |
| **Get Select Options** | Get all dropdown options |
| **Find Element (AI)** | Use LLM to find elements by description |

## Installation

```bash
# Clone the repo
git clone <repo-url>
cd n8n-nodes-rpa-playwright

# Install dependencies
npm install

# Build
npm run build
```

## Usage with n8n

### Option 1: Custom Extensions Path
Set in n8n environment:
```
N8N_CUSTOM_EXTENSIONS=/path/to/n8n-nodes-rpa-playwright
```

### Option 2: npm link
```bash
cd /path/to/n8n-nodes-rpa-playwright
npm link

cd ~/.n8n
npm link n8n-nodes-rpa-playwright
```

## Docker Setup (Selenium Grid)

```bash
docker-compose up -d
```

This starts:
- `selenium-hub` - Grid hub on port 4444
- `node-chromium` - Chrome browser node

## Quick Example

1. **Launch Browser** → Get CDP URL
2. **Navigate** → Go to website  
3. **Type Into** → Fill form fields (auto-detects iframes!)
4. **Click** → Submit button
5. **Close Browser** → End session

## Frame Handling

All interaction nodes support automatic iframe detection:

```
Frame Handling: Auto-Detect (Recommended)
Selector: #myInput
```

The node will automatically search all frames to find your element.

## License

MIT
