# n8n Custom Node Icons

Place your generated icon files (PNG 60x60 or SVG) in this folder.

## Required Icon Files

| Filename | Node | Current FA Icon |
|----------|------|-----------------|
| `launchBrowser.png` | Launch Browser | fa:rocket |
| `closeBrowser.png` | Close Browser | fa:window-close |
| `navigate.png` | Navigate | fa:compass |
| `click.png` | Click Element | fa:mouse-pointer |
| `typeInto.png` | Type Into | fa:keyboard-o |
| `findElementByDescription.png` | Find Element (AI) | fa:search |
| `takeScreenshot.png` | Screenshot | fa:camera |
| `getText.png` | Get Text | fa:font |
| `getTable.png` | Get Table | fa:table |
| `elementExists.png` | Element Exists | fa:crosshairs |
| `pageLoaded.png` | Page Loaded | fa:check-circle |
| `downloadFile.png` | Download File | fa:download |
| `getSelectOptions.png` | Get Select Options | fa:list-ul |
| `selectOption.png` | Select Option | fa:check-square-o |

## After Adding Icons

Update each node's `icon` property from:
```typescript
icon: 'fa:rocket',
```

To:
```typescript
icon: 'file:launchBrowser.png',
```

## Icon Specifications

- **Format**: PNG (60x60px) or SVG
- **Background**: Transparent or white
- **Style**: Minimalist flat design
- **Colors**: See color palette in generate-icons.txt
