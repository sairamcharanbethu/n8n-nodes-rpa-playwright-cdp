const { task } = require('gulp');

// No-op task - FontAwesome icons are used, no file copying needed
task('build:icons', (done) => {
	done();
});
