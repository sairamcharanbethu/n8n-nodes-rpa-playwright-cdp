/**
 * Profile Lock Manager
 * Handles exclusive locking for persistent browser profiles
 */

import redis, { REDIS_KEYS } from '../redis';
import config from '../config';
import logger from '../logger';
import { ProfileLock } from '../types';

export class ProfileLockManager {
  /**
   * Acquire a lock on a profile
   * Returns true if lock acquired, false if profile is already locked
   */
  async acquire(profileId: string, sessionId: string): Promise<boolean> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;
    const ttlSeconds = Math.ceil(config.profileLockTTL / 1000);

    // Try to set the lock with NX (only if not exists)
    const result = await redis.set(key, sessionId, 'EX', ttlSeconds, 'NX');

    if (result === 'OK') {
      logger.info(`Profile lock acquired`, { profileId, sessionId });
      return true;
    }

    // Lock exists - check if it's our session (reentrant lock)
    const existingSessionId = await redis.get(key);
    if (existingSessionId === sessionId) {
      // Refresh the lock TTL
      await redis.expire(key, ttlSeconds);
      logger.debug(`Profile lock refreshed`, { profileId, sessionId });
      return true;
    }

    logger.warn(`Profile lock denied - already locked`, {
      profileId,
      sessionId,
      lockedBy: existingSessionId,
    });
    return false;
  }

  /**
   * Release a profile lock
   */
  async release(profileId: string, sessionId: string): Promise<boolean> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;

    // Only delete if the lock is owned by this session
    const script = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
      else
        return 0
      end
    `;

    const result = await redis.eval(script, 1, key, sessionId);

    if (result === 1) {
      logger.info(`Profile lock released`, { profileId, sessionId });
      return true;
    }

    logger.debug(`Profile lock not released - not owner`, { profileId, sessionId });
    return false;
  }

  /**
   * Check if a profile is locked
   */
  async isLocked(profileId: string): Promise<boolean> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;
    const exists = await redis.exists(key);
    return exists === 1;
  }

  /**
   * Get lock info for a profile
   */
  async getLockInfo(profileId: string): Promise<ProfileLock | null> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;
    const sessionId = await redis.get(key);

    if (!sessionId) {
      return null;
    }

    const ttl = await redis.ttl(key);

    return {
      profileId,
      sessionId,
      lockedAt: new Date(), // Approximate - we don't store this
      expiresAt: new Date(Date.now() + ttl * 1000),
    };
  }

  /**
   * Refresh a profile lock (extend TTL)
   */
  async refresh(profileId: string, sessionId: string): Promise<boolean> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;
    const ttlSeconds = Math.ceil(config.profileLockTTL / 1000);

    // Only refresh if we own the lock
    const script = `
      if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("expire", KEYS[1], ARGV[2])
      else
        return 0
      end
    `;

    const result = await redis.eval(script, 1, key, sessionId, ttlSeconds.toString());
    return result === 1;
  }

  /**
   * Force release a lock (admin only)
   */
  async forceRelease(profileId: string): Promise<boolean> {
    const key = `${REDIS_KEYS.PROFILE_LOCK}${profileId}`;
    const result = await redis.del(key);
    
    if (result === 1) {
      logger.warn(`Profile lock force released`, { profileId });
      return true;
    }
    return false;
  }

  /**
   * Get all active profile locks
   */
  async getAllLocks(): Promise<ProfileLock[]> {
    const pattern = `${REDIS_KEYS.PROFILE_LOCK}*`;
    const keys = await redis.keys(pattern);
    const locks: ProfileLock[] = [];

    for (const key of keys) {
      const profileId = key.replace(REDIS_KEYS.PROFILE_LOCK, '');
      const lockInfo = await this.getLockInfo(profileId);
      if (lockInfo) {
        locks.push(lockInfo);
      }
    }

    return locks;
  }
}

export default ProfileLockManager;
