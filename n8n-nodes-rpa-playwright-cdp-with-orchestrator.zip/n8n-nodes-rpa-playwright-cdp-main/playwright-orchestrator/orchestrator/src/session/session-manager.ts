/**
 * Session Manager
 * Handles browser session lifecycle, warm pool, and request queue
 */

import { v4 as uuidv4 } from 'uuid';
import redis, { REDIS_KEYS, redisPub, REDIS_CHANNELS } from '../redis';
import config from '../config';
import logger from '../logger';
import WorkerClient from '../pool/worker-client';
import ProfileLockManager from './profile-lock';
import {
  BrowserSession,
  CreateSessionRequest,
  CreateSessionResponse,
  QueuedRequest,
  PoolStatus,
} from '../types';

export class SessionManager {
  private workerClient: WorkerClient;
  private profileLockManager: ProfileLockManager;
  private requestQueue: QueuedRequest[] = [];
  private cleanupInterval: NodeJS.Timeout | null = null;
  private warmPoolInterval: NodeJS.Timeout | null = null;

  constructor(workerClient: WorkerClient) {
    this.workerClient = workerClient;
    this.profileLockManager = new ProfileLockManager();
  }

  /**
   * Start background processes
   */
  start(): void {
    // Start cleanup job
    this.cleanupInterval = setInterval(
      () => this.cleanupExpiredSessions(),
      config.cleanupInterval
    );

    // Start warm pool maintenance
    this.warmPoolInterval = setInterval(
      () => this.maintainWarmPool(),
      config.healthCheckInterval
    );

    logger.info('Session manager started');
  }

  /**
   * Stop background processes
   */
  stop(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    if (this.warmPoolInterval) {
      clearInterval(this.warmPoolInterval);
      this.warmPoolInterval = null;
    }
  }

  /**
   * Create a new browser session
   */
  async createSession(request: CreateSessionRequest): Promise<CreateSessionResponse> {
    const sessionId = uuidv4();
    const timeout = (request.timeout || 300) * 1000; // Convert to ms

    logger.info('Creating session', { sessionId, mode: request.mode, profileId: request.profileId });

    try {
      // For persistent sessions, acquire profile lock
      if (request.mode === 'persistent' && request.profileId) {
        const lockAcquired = await this.profileLockManager.acquire(
          request.profileId,
          sessionId
        );
        if (!lockAcquired) {
          return {
            success: false,
            error: `Profile ${request.profileId} is currently in use by another session`,
          };
        }
      }

      // Try to get a warm session first
      const warmSession = await this.getWarmSession();
      if (warmSession && request.mode !== 'persistent') {
        // Use warm session for ephemeral requests
        warmSession.id = sessionId;
        warmSession.mode = 'ephemeral';
        warmSession.metadata = {
          workflowId: request.workflowId,
          executionId: request.executionId,
        };
        warmSession.status = 'ready';
        warmSession.expiresAt = new Date(Date.now() + timeout);

        await this.saveSession(warmSession);
        await this.removeFromWarmPool(warmSession.id);

        logger.info('Session created from warm pool', { sessionId });

        return {
          success: true,
          sessionId: warmSession.id,
          cdpUrl: warmSession.cdpUrl,
          status: 'ready',
          workerId: warmSession.workerId,
          createdAt: warmSession.createdAt.toISOString(),
          expiresAt: warmSession.expiresAt.toISOString(),
        };
      }

      // No warm session available - try to launch a new browser
      const availableWorkers = this.workerClient.getAvailable();

      if (availableWorkers.length === 0) {
        // No capacity - queue the request
        return this.queueRequest(sessionId, request);
      }

      // Select worker with most available capacity
      const worker = availableWorkers.sort(
        (a, b) => b.capacity.available - a.capacity.available
      )[0];

      // Launch browser on worker
      const { browserId, wsEndpoint } = await this.workerClient.launchBrowser(worker.id, {
        profileId: request.profileId,
      });

      // Create session object
      const session: BrowserSession = {
        id: sessionId,
        mode: request.mode || 'ephemeral',
        profileId: request.profileId,
        workerId: worker.id,
        browserId,
        cdpUrl: wsEndpoint,
        status: 'ready',
        createdAt: new Date(),
        lastActivity: new Date(),
        expiresAt: new Date(Date.now() + timeout),
        metadata: {
          workflowId: request.workflowId,
          executionId: request.executionId,
        },
        vncEnabled: false,
      };

      await this.saveSession(session);

      // Publish session created event
      await this.publishEvent('session.created', session);

      logger.info('Session created', { sessionId, workerId: worker.id, browserId });

      return {
        success: true,
        sessionId: session.id,
        cdpUrl: session.cdpUrl,
        status: 'ready',
        workerId: session.workerId,
        createdAt: session.createdAt.toISOString(),
        expiresAt: session.expiresAt.toISOString(),
      };
    } catch (error: any) {
      logger.error('Failed to create session', { sessionId, error: error.message });

      // Release profile lock if we acquired one
      if (request.mode === 'persistent' && request.profileId) {
        await this.profileLockManager.release(request.profileId, sessionId);
      }

      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Close a session
   */
  async closeSession(sessionId: string, force = false): Promise<void> {
    const session = await this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found`);
    }

    logger.info('Closing session', { sessionId, force });

    try {
      session.status = 'closing';
      await this.saveSession(session);

      // Close browser on worker
      await this.workerClient.closeBrowser(session.workerId, session.browserId, force);

      // Release profile lock
      if (session.mode === 'persistent' && session.profileId) {
        await this.profileLockManager.release(session.profileId, sessionId);
      }

      // Delete session from Redis
      await this.deleteSession(sessionId);

      // Publish session closed event
      await this.publishEvent('session.closed', { sessionId });

      logger.info('Session closed', { sessionId });

      // Process queue if there are waiting requests
      this.processQueue();
    } catch (error: any) {
      logger.error('Error closing session', { sessionId, error: error.message });
      
      // Mark session as error but still delete
      session.status = 'error';
      session.error = error.message;
      await this.deleteSession(sessionId);

      // Release profile lock anyway
      if (session.mode === 'persistent' && session.profileId) {
        await this.profileLockManager.release(session.profileId, sessionId);
      }

      throw error;
    }
  }

  /**
   * Get a session by ID
   */
  async getSession(sessionId: string): Promise<BrowserSession | null> {
    const key = `${REDIS_KEYS.SESSION}${sessionId}`;
    const data = await redis.get(key);

    if (!data) {
      return null;
    }

    const session = JSON.parse(data) as BrowserSession;
    // Convert date strings back to Date objects
    session.createdAt = new Date(session.createdAt);
    session.lastActivity = new Date(session.lastActivity);
    session.expiresAt = new Date(session.expiresAt);

    return session;
  }

  /**
   * Get all active sessions
   */
  async getAllSessions(): Promise<BrowserSession[]> {
    const pattern = `${REDIS_KEYS.SESSION}*`;
    const keys = await redis.keys(pattern);
    const sessions: BrowserSession[] = [];

    for (const key of keys) {
      const data = await redis.get(key);
      if (data) {
        const session = JSON.parse(data) as BrowserSession;
        session.createdAt = new Date(session.createdAt);
        session.lastActivity = new Date(session.lastActivity);
        session.expiresAt = new Date(session.expiresAt);
        sessions.push(session);
      }
    }

    return sessions;
  }

  /**
   * Update session activity timestamp
   */
  async touchSession(sessionId: string): Promise<void> {
    const session = await this.getSession(sessionId);
    if (session) {
      session.lastActivity = new Date();
      // Extend expiration if idle timeout would expire before session timeout
      const idleExpiry = Date.now() + config.idleTimeout;
      if (idleExpiry > session.expiresAt.getTime()) {
        session.expiresAt = new Date(Math.min(
          idleExpiry,
          session.createdAt.getTime() + config.maxSessionLifetime
        ));
      }
      await this.saveSession(session);

      // Touch browser on worker
      await this.workerClient.touchBrowser(session.workerId, session.browserId);
    }
  }

  /**
   * Enable VNC for a session
   */
  async enableVNC(sessionId: string): Promise<{ port: number; host: string }> {
    const session = await this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found`);
    }

    const { port } = await this.workerClient.enableVNC(session.workerId, session.browserId);

    session.vncEnabled = true;
    session.vncPort = port;
    await this.saveSession(session);

    // Get worker URL for VNC host
    const worker = this.workerClient.get(session.workerId);
    const host = worker?.url.replace(/https?:\/\//, '').split(':')[0] || 'localhost';

    return { port, host };
  }

  /**
   * Disable VNC for a session
   */
  async disableVNC(sessionId: string): Promise<void> {
    const session = await this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found`);
    }

    await this.workerClient.disableVNC(session.workerId, session.browserId);

    session.vncEnabled = false;
    session.vncPort = undefined;
    await this.saveSession(session);
  }

  /**
   * Capture screenshot for a session
   */
  async captureScreenshot(
    sessionId: string,
    options: { fullPage?: boolean } = {}
  ): Promise<{ url: string }> {
    const session = await this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found`);
    }

    const result = await this.workerClient.captureScreenshot(
      session.workerId,
      session.browserId,
      options
    );

    return { url: result.url };
  }

  /**
   * Get pool status
   */
  async getPoolStatus(): Promise<PoolStatus> {
    const workers = this.workerClient.getAll();
    const warmPoolSize = await redis.scard(REDIS_KEYS.WARM_POOL);

    return {
      totalCapacity: this.workerClient.totalCapacity,
      activeSession: (await this.getAllSessions()).length,
      availableSlots: this.workerClient.availableSlots,
      queuedRequests: this.requestQueue.length,
      warmPoolSize,
      warmPoolTarget: config.warmPoolSize,
      workers: workers.map((w) => ({
        id: w.id,
        status: w.status,
        active: w.capacity.active,
        max: w.capacity.max,
      })),
    };
  }

  // ============================================
  // Private Methods
  // ============================================

  private async saveSession(session: BrowserSession): Promise<void> {
    const key = `${REDIS_KEYS.SESSION}${session.id}`;
    const ttl = Math.ceil((session.expiresAt.getTime() - Date.now()) / 1000) + 60; // Add 60s buffer
    await redis.set(key, JSON.stringify(session), 'EX', Math.max(ttl, 60));
  }

  private async deleteSession(sessionId: string): Promise<void> {
    const key = `${REDIS_KEYS.SESSION}${sessionId}`;
    await redis.del(key);
  }

  private async getWarmSession(): Promise<BrowserSession | null> {
    const sessionId = await redis.spop(REDIS_KEYS.WARM_POOL);
    if (!sessionId) {
      return null;
    }

    return this.getSession(sessionId);
  }

  private async addToWarmPool(sessionId: string): Promise<void> {
    await redis.sadd(REDIS_KEYS.WARM_POOL, sessionId);
  }

  private async removeFromWarmPool(sessionId: string): Promise<void> {
    await redis.srem(REDIS_KEYS.WARM_POOL, sessionId);
  }

  private queueRequest(
    sessionId: string,
    request: CreateSessionRequest
  ): CreateSessionResponse {
    return new Promise((resolve, reject) => {
      const queuedRequest: QueuedRequest = {
        id: sessionId,
        request,
        priority: request.priority || 'normal',
        createdAt: new Date(),
        timeoutAt: new Date(Date.now() + config.queueTimeout),
        resolve: (session) => {
          resolve({
            success: true,
            sessionId: session.id,
            cdpUrl: session.cdpUrl,
            status: 'ready',
          });
        },
        reject: (error) => {
          resolve({
            success: false,
            error: error.message,
          });
        },
      };

      // Add to queue based on priority
      if (request.priority === 'high') {
        this.requestQueue.unshift(queuedRequest);
      } else {
        this.requestQueue.push(queuedRequest);
      }

      logger.info('Request queued', {
        sessionId,
        queuePosition: this.requestQueue.length,
      });

      // Set timeout for the queued request
      setTimeout(() => {
        const index = this.requestQueue.findIndex((r) => r.id === sessionId);
        if (index !== -1) {
          this.requestQueue.splice(index, 1);
          reject(new Error('Queue timeout - no capacity available'));
        }
      }, config.queueTimeout);
    }) as any;
  }

  private async processQueue(): Promise<void> {
    if (this.requestQueue.length === 0) return;

    const availableWorkers = this.workerClient.getAvailable();
    if (availableWorkers.length === 0) return;

    const queuedRequest = this.requestQueue.shift();
    if (!queuedRequest) return;

    try {
      const result = await this.createSession(queuedRequest.request);
      if (result.success) {
        const session = await this.getSession(result.sessionId!);
        if (session) {
          queuedRequest.resolve(session);
        }
      } else {
        queuedRequest.reject(new Error(result.error));
      }
    } catch (error: any) {
      queuedRequest.reject(error);
    }
  }

  private async cleanupExpiredSessions(): Promise<void> {
    const sessions = await this.getAllSessions();
    const now = Date.now();

    for (const session of sessions) {
      const isExpired = session.expiresAt.getTime() < now;
      const isIdle =
        session.lastActivity.getTime() + config.idleTimeout < now;
      const isMaxLifetime =
        session.createdAt.getTime() + config.maxSessionLifetime < now;

      if (isExpired || isIdle || isMaxLifetime) {
        logger.info('Cleaning up session', {
          sessionId: session.id,
          reason: isExpired ? 'expired' : isIdle ? 'idle' : 'max_lifetime',
        });

        try {
          await this.closeSession(session.id, true);
        } catch (error: any) {
          logger.error('Failed to cleanup session', {
            sessionId: session.id,
            error: error.message,
          });
        }
      }
    }
  }

  private async maintainWarmPool(): Promise<void> {
    const currentSize = await redis.scard(REDIS_KEYS.WARM_POOL);
    const targetSize = config.warmPoolSize;

    if (currentSize >= targetSize) return;

    const needed = targetSize - currentSize;
    const availableWorkers = this.workerClient.getAvailable();

    if (availableWorkers.length === 0) return;

    logger.debug('Maintaining warm pool', { current: currentSize, target: targetSize });

    for (let i = 0; i < needed && availableWorkers.length > 0; i++) {
      const worker = availableWorkers[i % availableWorkers.length];

      if (worker.capacity.available <= 0) continue;

      try {
        const sessionId = uuidv4();
        const { browserId, wsEndpoint } = await this.workerClient.launchBrowser(worker.id);

        const session: BrowserSession = {
          id: sessionId,
          mode: 'ephemeral',
          workerId: worker.id,
          browserId,
          cdpUrl: wsEndpoint,
          status: 'ready',
          createdAt: new Date(),
          lastActivity: new Date(),
          expiresAt: new Date(Date.now() + config.sessionTimeout),
          metadata: {},
          vncEnabled: false,
        };

        await this.saveSession(session);
        await this.addToWarmPool(sessionId);

        logger.debug('Added session to warm pool', { sessionId });
      } catch (error: any) {
        logger.warn('Failed to add warm pool session', { error: error.message });
      }
    }
  }

  private async publishEvent(event: string, data: any): Promise<void> {
    await redisPub.publish(
      REDIS_CHANNELS.SESSION_EVENTS,
      JSON.stringify({ event, data, timestamp: new Date().toISOString() })
    );
  }
}

export default SessionManager;
