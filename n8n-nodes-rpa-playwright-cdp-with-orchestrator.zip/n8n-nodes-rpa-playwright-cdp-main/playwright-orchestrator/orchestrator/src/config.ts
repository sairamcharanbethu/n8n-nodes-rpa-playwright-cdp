/**
 * Orchestrator Configuration
 */

import { OrchestratorConfig } from './types';

function parseWorkers(envValue: string | undefined): string[] {
  if (!envValue) {
    // Default to a single worker for development
    return ['http://worker:3001'];
  }
  return envValue.split(',').map((url) => url.trim()).filter(Boolean);
}

export const config: OrchestratorConfig = {
  port: parseInt(process.env.PORT || '3000', 10),
  
  redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
  
  // Worker URLs (comma-separated)
  workers: parseWorkers(process.env.WORKER_URLS),
  
  // Warm pool configuration
  warmPoolSize: parseInt(process.env.WARM_POOL_SIZE || '2', 10),
  
  // Session timeouts
  sessionTimeout: parseInt(process.env.SESSION_TIMEOUT || '300000', 10),       // 5 minutes
  maxSessionLifetime: parseInt(process.env.MAX_SESSION_LIFETIME || '1800000', 10), // 30 minutes
  idleTimeout: parseInt(process.env.IDLE_TIMEOUT || '300000', 10),             // 5 minutes
  
  // Queue configuration
  queueTimeout: parseInt(process.env.QUEUE_TIMEOUT || '60000', 10),            // 1 minute
  
  // Health check configuration
  healthCheckInterval: parseInt(process.env.HEALTH_CHECK_INTERVAL || '10000', 10), // 10 seconds
  
  // Cleanup configuration
  cleanupInterval: parseInt(process.env.CLEANUP_INTERVAL || '30000', 10),      // 30 seconds
  
  // Profile lock configuration
  profileLockTTL: parseInt(process.env.PROFILE_LOCK_TTL || '300000', 10),      // 5 minutes
};

export default config;
