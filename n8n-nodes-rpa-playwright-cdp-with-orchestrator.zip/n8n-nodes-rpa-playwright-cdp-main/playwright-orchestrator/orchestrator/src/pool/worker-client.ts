/**
 * Worker Client
 * Handles communication with browser worker containers
 */

import fetch from 'node-fetch';
import { WorkerInfo, WorkerHealthResponse } from '../types';
import logger from '../logger';

export class WorkerClient {
  private workers: Map<string, WorkerInfo> = new Map();
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private healthCheckIntervalMs: number;

  constructor(workerUrls: string[], healthCheckIntervalMs: number) {
    this.healthCheckIntervalMs = healthCheckIntervalMs;

    // Initialize workers
    for (const url of workerUrls) {
      const id = this.urlToId(url);
      this.workers.set(id, {
        id,
        url,
        status: 'offline',
        capacity: { max: 1, active: 0, available: 0 },
        lastHealthCheck: new Date(0),
        registeredAt: new Date(),
      });
    }
  }

  /**
   * Start health check loop
   */
  start(): void {
    logger.info('Starting worker health checks');
    this.checkAllWorkers();
    this.healthCheckInterval = setInterval(
      () => this.checkAllWorkers(),
      this.healthCheckIntervalMs
    );
  }

  /**
   * Stop health check loop
   */
  stop(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }

  /**
   * Check health of all workers
   */
  private async checkAllWorkers(): Promise<void> {
    const checks = Array.from(this.workers.keys()).map((id) => this.checkWorker(id));
    await Promise.all(checks);
  }

  /**
   * Check health of a specific worker
   */
  private async checkWorker(workerId: string): Promise<void> {
    const worker = this.workers.get(workerId);
    if (!worker) return;

    try {
      const response = await fetch(`${worker.url}/health`, {
        timeout: 5000,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const health = (await response.json()) as WorkerHealthResponse;

      worker.status = health.status;
      worker.capacity = {
        max: health.browsers.max,
        active: health.browsers.active,
        available: health.browsers.max - health.browsers.active,
      };
      worker.lastHealthCheck = new Date();

      this.workers.set(workerId, worker);
    } catch (error: any) {
      logger.warn(`Worker ${workerId} health check failed`, { error: error.message });
      worker.status = 'offline';
      worker.capacity.available = 0;
      worker.lastHealthCheck = new Date();
      this.workers.set(workerId, worker);
    }
  }

  /**
   * Get all workers
   */
  getAll(): WorkerInfo[] {
    return Array.from(this.workers.values());
  }

  /**
   * Get healthy workers with available capacity
   */
  getAvailable(): WorkerInfo[] {
    return Array.from(this.workers.values()).filter(
      (w) => (w.status === 'healthy' || w.status === 'degraded') && w.capacity.available > 0
    );
  }

  /**
   * Get a specific worker
   */
  get(workerId: string): WorkerInfo | undefined {
    return this.workers.get(workerId);
  }

  /**
   * Launch a browser on a worker
   */
  async launchBrowser(
    workerId: string,
    options: { profileId?: string; args?: string[] } = {}
  ): Promise<{ browserId: string; wsEndpoint: string }> {
    const worker = this.workers.get(workerId);
    if (!worker) {
      throw new Error(`Worker ${workerId} not found`);
    }

    const response = await fetch(`${worker.url}/browsers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(options),
      timeout: 60000, // 60 second timeout for browser launch
    });

    const result = await response.json() as any;

    if (!result.success) {
      throw new Error(result.error || 'Failed to launch browser');
    }

    // Update worker capacity
    worker.capacity.active++;
    worker.capacity.available = worker.capacity.max - worker.capacity.active;
    this.workers.set(workerId, worker);

    return {
      browserId: result.browserId,
      wsEndpoint: result.wsEndpoint,
    };
  }

  /**
   * Close a browser on a worker
   */
  async closeBrowser(workerId: string, browserId: string, force = false): Promise<void> {
    const worker = this.workers.get(workerId);
    if (!worker) {
      throw new Error(`Worker ${workerId} not found`);
    }

    const response = await fetch(
      `${worker.url}/browsers/${browserId}?force=${force}`,
      {
        method: 'DELETE',
        timeout: 30000,
      }
    );

    if (!response.ok) {
      const result = await response.json() as any;
      throw new Error(result.error || `Failed to close browser: HTTP ${response.status}`);
    }

    // Update worker capacity
    worker.capacity.active = Math.max(0, worker.capacity.active - 1);
    worker.capacity.available = worker.capacity.max - worker.capacity.active;
    this.workers.set(workerId, worker);
  }

  /**
   * Enable VNC for a browser
   */
  async enableVNC(workerId: string, browserId: string): Promise<{ port: number }> {
    const worker = this.workers.get(workerId);
    if (!worker) {
      throw new Error(`Worker ${workerId} not found`);
    }

    const response = await fetch(`${worker.url}/browsers/${browserId}/vnc`, {
      method: 'POST',
      timeout: 10000,
    });

    const result = await response.json() as any;

    if (!result.success) {
      throw new Error(result.error || 'Failed to enable VNC');
    }

    return { port: result.port };
  }

  /**
   * Disable VNC for a browser
   */
  async disableVNC(workerId: string, browserId: string): Promise<void> {
    const worker = this.workers.get(workerId);
    if (!worker) {
      throw new Error(`Worker ${workerId} not found`);
    }

    await fetch(`${worker.url}/browsers/${browserId}/vnc`, {
      method: 'DELETE',
      timeout: 10000,
    });
  }

  /**
   * Capture screenshot from a browser
   */
  async captureScreenshot(
    workerId: string,
    browserId: string,
    options: { fullPage?: boolean; type?: 'png' | 'jpeg' } = {}
  ): Promise<{ path: string; url: string }> {
    const worker = this.workers.get(workerId);
    if (!worker) {
      throw new Error(`Worker ${workerId} not found`);
    }

    const response = await fetch(`${worker.url}/browsers/${browserId}/screenshot`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(options),
      timeout: 30000,
    });

    const result = await response.json() as any;

    if (!result.success) {
      throw new Error(result.error || 'Failed to capture screenshot');
    }

    return {
      path: result.path,
      url: `${worker.url}${result.url}`,
    };
  }

  /**
   * Touch (update activity) for a browser
   */
  async touchBrowser(workerId: string, browserId: string): Promise<void> {
    const worker = this.workers.get(workerId);
    if (!worker) return;

    try {
      await fetch(`${worker.url}/browsers/${browserId}/touch`, {
        method: 'POST',
        timeout: 5000,
      });
    } catch (error: any) {
      logger.debug(`Failed to touch browser ${browserId}`, { error: error.message });
    }
  }

  /**
   * Convert worker URL to ID
   */
  private urlToId(url: string): string {
    return url.replace(/https?:\/\//, '').replace(/[:/]/g, '-');
  }

  /**
   * Get total capacity across all workers
   */
  get totalCapacity(): number {
    return Array.from(this.workers.values()).reduce((sum, w) => sum + w.capacity.max, 0);
  }

  /**
   * Get total available slots across all workers
   */
  get availableSlots(): number {
    return this.getAvailable().reduce((sum, w) => sum + w.capacity.available, 0);
  }
}

export default WorkerClient;
