/**
 * Orchestrator Types
 */

// ============================================
// Session Types
// ============================================

export interface BrowserSession {
  id: string;
  mode: 'ephemeral' | 'persistent';
  profileId?: string;           // For persistent sessions
  workerId: string;             // Which worker container
  browserId: string;            // Browser ID on the worker
  cdpUrl: string;               // Playwright CDP connection URL
  status: 'pending' | 'launching' | 'ready' | 'active' | 'closing' | 'closed' | 'error';
  createdAt: Date;
  lastActivity: Date;
  expiresAt: Date;              // Auto-cleanup after this time
  metadata: {
    workflowId?: string;        // n8n workflow ID
    executionId?: string;       // n8n execution ID
    currentUrl?: string;
    apiKeyId?: string;          // Which API key created this
  };
  vncEnabled: boolean;
  vncPort?: number;
  error?: string;
}

export interface CreateSessionRequest {
  mode?: 'ephemeral' | 'persistent';
  profileId?: string;           // Required for persistent mode
  workflowId?: string;
  executionId?: string;
  timeout?: number;             // Session timeout in seconds (default: 300)
  priority?: 'low' | 'normal' | 'high';
}

export interface CreateSessionResponse {
  success: boolean;
  sessionId?: string;
  cdpUrl?: string;
  status?: string;
  workerId?: string;
  createdAt?: string;
  expiresAt?: string;
  error?: string;
  queuePosition?: number;       // If queued, position in queue
}

// ============================================
// Worker Types
// ============================================

export interface WorkerInfo {
  id: string;
  url: string;                  // Worker API URL
  status: 'healthy' | 'degraded' | 'unhealthy' | 'offline';
  capacity: {
    max: number;
    active: number;
    available: number;
  };
  lastHealthCheck: Date;
  registeredAt: Date;
}

export interface WorkerHealthResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  workerId: string;
  uptime: number;
  browsers: {
    active: number;
    max: number;
  };
  timestamp: string;
}

// ============================================
// Pool Types
// ============================================

export interface PoolStatus {
  totalCapacity: number;
  activeSession: number;
  availableSlots: number;
  queuedRequests: number;
  warmPoolSize: number;
  warmPoolTarget: number;
  workers: Array<{
    id: string;
    status: string;
    active: number;
    max: number;
  }>;
}

export interface QueuedRequest {
  id: string;
  request: CreateSessionRequest;
  priority: 'low' | 'normal' | 'high';
  createdAt: Date;
  timeoutAt: Date;
  resolve: (session: BrowserSession) => void;
  reject: (error: Error) => void;
}

// ============================================
// Profile Lock Types
// ============================================

export interface ProfileLock {
  profileId: string;
  sessionId: string;
  lockedAt: Date;
  expiresAt: Date;
}

// ============================================
// Configuration Types
// ============================================

export interface OrchestratorConfig {
  port: number;
  redisUrl: string;
  workers: string[];            // Worker URLs
  warmPoolSize: number;         // Target warm pool size
  sessionTimeout: number;       // Default session timeout (ms)
  maxSessionLifetime: number;   // Max session lifetime (ms)
  idleTimeout: number;          // Session idle timeout (ms)
  queueTimeout: number;         // How long to wait in queue (ms)
  healthCheckInterval: number;  // Worker health check interval (ms)
  cleanupInterval: number;      // Session cleanup interval (ms)
  profileLockTTL: number;       // Profile lock TTL (ms)
}

// ============================================
// API Response Types
// ============================================

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

export interface SessionListResponse {
  sessions: Array<{
    id: string;
    mode: string;
    status: string;
    workerId: string;
    createdAt: string;
    lastActivity: string;
    expiresAt: string;
    vncEnabled: boolean;
    metadata: BrowserSession['metadata'];
  }>;
  total: number;
}
