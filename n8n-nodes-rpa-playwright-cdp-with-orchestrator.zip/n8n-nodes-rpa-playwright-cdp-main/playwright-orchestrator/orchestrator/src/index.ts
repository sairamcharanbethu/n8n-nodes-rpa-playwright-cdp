/**
 * Browser Orchestrator Service
 * Main entry point
 */

import express, { Request, Response, NextFunction } from 'express';
import config from './config';
import logger from './logger';
import { closeRedis } from './redis';
import WorkerClient from './pool/worker-client';
import SessionManager from './session/session-manager';
import createSessionRoutes from './api/sessions';
import { ApiResponse, PoolStatus } from './types';

// Initialize components
const workerClient = new WorkerClient(config.workers, config.healthCheckInterval);
const sessionManager = new SessionManager(workerClient);

// Express app
const app = express();
app.use(express.json());

// Request logging middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  const startTime = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    logger.info(`${req.method} ${req.path}`, {
      status: res.statusCode,
      duration: `${duration}ms`,
    });
  });
  next();
});

// ============================================
// Health & Status Endpoints
// ============================================

/**
 * Health check endpoint
 */
app.get('/health', async (req: Request, res: Response) => {
  try {
    const poolStatus = await sessionManager.getPoolStatus();
    const healthyWorkers = poolStatus.workers.filter(
      (w) => w.status === 'healthy' || w.status === 'degraded'
    );

    const status =
      healthyWorkers.length === poolStatus.workers.length
        ? 'healthy'
        : healthyWorkers.length > 0
        ? 'degraded'
        : 'unhealthy';

    res.status(status === 'unhealthy' ? 503 : 200).json({
      success: true,
      data: {
        status,
        uptime: process.uptime(),
        workers: {
          total: poolStatus.workers.length,
          healthy: healthyWorkers.length,
        },
        sessions: {
          active: poolStatus.activeSession,
          queued: poolStatus.queuedRequests,
        },
      },
      timestamp: new Date().toISOString(),
    } as ApiResponse);
  } catch (error: any) {
    res.status(503).json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString(),
    } as ApiResponse);
  }
});

/**
 * Pool status endpoint
 */
app.get('/pool', async (req: Request, res: Response) => {
  try {
    const status = await sessionManager.getPoolStatus();

    res.json({
      success: true,
      data: status,
      timestamp: new Date().toISOString(),
    } as ApiResponse<PoolStatus>);
  } catch (error: any) {
    logger.error('Error getting pool status', { error: error.message });
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString(),
    } as ApiResponse);
  }
});

/**
 * Workers status endpoint
 */
app.get('/workers', (req: Request, res: Response) => {
  const workers = workerClient.getAll();

  res.json({
    success: true,
    data: {
      workers: workers.map((w) => ({
        id: w.id,
        url: w.url,
        status: w.status,
        capacity: w.capacity,
        lastHealthCheck: w.lastHealthCheck.toISOString(),
      })),
      total: workers.length,
      healthy: workers.filter((w) => w.status === 'healthy').length,
    },
    timestamp: new Date().toISOString(),
  } as ApiResponse);
});

// ============================================
// Session Routes
// ============================================

app.use('/sessions', createSessionRoutes(sessionManager));

// ============================================
// Error Handler
// ============================================

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    timestamp: new Date().toISOString(),
  } as ApiResponse);
});

// ============================================
// Graceful Shutdown
// ============================================

async function shutdown(signal: string): Promise<void> {
  logger.info(`Received ${signal}, shutting down gracefully...`);

  try {
    // Stop accepting new requests
    sessionManager.stop();
    workerClient.stop();

    // Close all sessions
    const sessions = await sessionManager.getAllSessions();
    for (const session of sessions) {
      try {
        await sessionManager.closeSession(session.id, true);
      } catch (error: any) {
        logger.error(`Failed to close session ${session.id}`, { error: error.message });
      }
    }

    // Close Redis connections
    await closeRedis();

    logger.info('Shutdown complete');
    process.exit(0);
  } catch (error: any) {
    logger.error('Error during shutdown', { error: error.message });
    process.exit(1);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ============================================
// Start Server
// ============================================

async function start(): Promise<void> {
  // Start worker health checks
  workerClient.start();

  // Start session manager background processes
  sessionManager.start();

  // Wait a moment for initial health checks
  await new Promise((resolve) => setTimeout(resolve, 2000));

  // Start HTTP server
  app.listen(config.port, () => {
    logger.info(`Browser orchestrator started`, {
      port: config.port,
      workers: config.workers.length,
      warmPoolSize: config.warmPoolSize,
    });
  });
}

start().catch((error) => {
  logger.error('Failed to start orchestrator', { error: error.message });
  process.exit(1);
});

export default app;
