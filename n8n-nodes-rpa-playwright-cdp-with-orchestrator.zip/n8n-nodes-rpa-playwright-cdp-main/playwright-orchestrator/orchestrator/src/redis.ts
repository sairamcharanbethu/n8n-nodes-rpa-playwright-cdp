/**
 * Redis Client
 * Used for session state, profile locks, and pub/sub
 */

import Redis from 'ioredis';
import config from './config';
import logger from './logger';

// Main Redis client for commands
export const redis = new Redis(config.redisUrl, {
  maxRetriesPerRequest: 3,
  retryStrategy: (times) => {
    if (times > 10) {
      logger.error('Redis connection failed after 10 retries');
      return null; // Stop retrying
    }
    return Math.min(times * 100, 3000);
  },
  reconnectOnError: (err) => {
    logger.warn('Redis reconnecting due to error', { error: err.message });
    return true;
  },
});

// Pub/sub client (separate connection required for subscriptions)
export const redisSub = new Redis(config.redisUrl);
export const redisPub = new Redis(config.redisUrl);

// Connection event handlers
redis.on('connect', () => {
  logger.info('Redis connected');
});

redis.on('error', (err) => {
  logger.error('Redis error', { error: err.message });
});

redis.on('close', () => {
  logger.warn('Redis connection closed');
});

// Redis key prefixes
export const REDIS_KEYS = {
  SESSION: 'session:',           // session:{sessionId}
  SESSIONS_BY_WORKER: 'worker-sessions:', // worker-sessions:{workerId}
  PROFILE_LOCK: 'profile-lock:', // profile-lock:{profileId}
  WORKER_STATUS: 'worker:',      // worker:{workerId}
  WARM_POOL: 'warm-pool',        // Set of warm session IDs
  QUEUE: 'session-queue',        // Sorted set for request queue
};

// Pub/sub channels
export const REDIS_CHANNELS = {
  SESSION_EVENTS: 'session-events',
  WORKER_EVENTS: 'worker-events',
};

/**
 * Close all Redis connections
 */
export async function closeRedis(): Promise<void> {
  await Promise.all([
    redis.quit(),
    redisSub.quit(),
    redisPub.quit(),
  ]);
  logger.info('Redis connections closed');
}

export default redis;
