/**
 * Session API Routes
 */

import { Router, Request, Response } from 'express';
import SessionManager from '../session/session-manager';
import logger from '../logger';
import { CreateSessionRequest, ApiResponse, SessionListResponse } from '../types';

export function createSessionRoutes(sessionManager: SessionManager): Router {
  const router = Router();

  /**
   * Create a new session
   * POST /sessions
   */
  router.post('/', async (req: Request, res: Response) => {
    try {
      const request: CreateSessionRequest = req.body;

      // Validate request
      if (request.mode === 'persistent' && !request.profileId) {
        return res.status(400).json({
          success: false,
          error: 'profileId is required for persistent sessions',
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }

      const result = await sessionManager.createSession(request);

      if (result.success) {
        res.status(201).json({
          success: true,
          data: {
            sessionId: result.sessionId,
            cdpUrl: result.cdpUrl,
            status: result.status,
            workerId: result.workerId,
            createdAt: result.createdAt,
            expiresAt: result.expiresAt,
          },
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      } else {
        res.status(result.queuePosition ? 202 : 500).json({
          success: false,
          error: result.error,
          data: result.queuePosition ? { queuePosition: result.queuePosition } : undefined,
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }
    } catch (error: any) {
      logger.error('Error creating session', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * List all sessions
   * GET /sessions
   */
  router.get('/', async (req: Request, res: Response) => {
    try {
      const sessions = await sessionManager.getAllSessions();

      const response: SessionListResponse = {
        sessions: sessions.map((s) => ({
          id: s.id,
          mode: s.mode,
          status: s.status,
          workerId: s.workerId,
          createdAt: s.createdAt.toISOString(),
          lastActivity: s.lastActivity.toISOString(),
          expiresAt: s.expiresAt.toISOString(),
          vncEnabled: s.vncEnabled,
          metadata: s.metadata,
        })),
        total: sessions.length,
      };

      res.json({
        success: true,
        data: response,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      logger.error('Error listing sessions', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Get a specific session
   * GET /sessions/:id
   */
  router.get('/:id', async (req: Request, res: Response) => {
    try {
      const session = await sessionManager.getSession(req.params.id);

      if (!session) {
        return res.status(404).json({
          success: false,
          error: 'Session not found',
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }

      res.json({
        success: true,
        data: {
          id: session.id,
          mode: session.mode,
          profileId: session.profileId,
          status: session.status,
          cdpUrl: session.cdpUrl,
          workerId: session.workerId,
          createdAt: session.createdAt.toISOString(),
          lastActivity: session.lastActivity.toISOString(),
          expiresAt: session.expiresAt.toISOString(),
          vncEnabled: session.vncEnabled,
          vncPort: session.vncPort,
          metadata: session.metadata,
          error: session.error,
        },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      logger.error('Error getting session', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Get CDP URL for a session
   * GET /sessions/:id/cdp
   */
  router.get('/:id/cdp', async (req: Request, res: Response) => {
    try {
      const session = await sessionManager.getSession(req.params.id);

      if (!session) {
        return res.status(404).json({
          success: false,
          error: 'Session not found',
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }

      // Touch session to keep it alive
      await sessionManager.touchSession(req.params.id);

      res.json({
        success: true,
        data: {
          cdpUrl: session.cdpUrl,
          status: session.status,
        },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      logger.error('Error getting CDP URL', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Close a session
   * DELETE /sessions/:id
   */
  router.delete('/:id', async (req: Request, res: Response) => {
    try {
      const force = req.query.force === 'true';
      await sessionManager.closeSession(req.params.id, force);

      res.json({
        success: true,
        data: { message: 'Session closed' },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          error: error.message,
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }
      logger.error('Error closing session', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Touch session (keep alive)
   * POST /sessions/:id/touch
   */
  router.post('/:id/touch', async (req: Request, res: Response) => {
    try {
      await sessionManager.touchSession(req.params.id);

      res.json({
        success: true,
        data: { message: 'Session touched' },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      logger.error('Error touching session', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Enable VNC for a session
   * POST /sessions/:id/vnc
   */
  router.post('/:id/vnc', async (req: Request, res: Response) => {
    try {
      const { port, host } = await sessionManager.enableVNC(req.params.id);

      res.json({
        success: true,
        data: { enabled: true, port, host },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          error: error.message,
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }
      logger.error('Error enabling VNC', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Disable VNC for a session
   * DELETE /sessions/:id/vnc
   */
  router.delete('/:id/vnc', async (req: Request, res: Response) => {
    try {
      await sessionManager.disableVNC(req.params.id);

      res.json({
        success: true,
        data: { enabled: false },
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          error: error.message,
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }
      logger.error('Error disabling VNC', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  /**
   * Capture screenshot
   * POST /sessions/:id/screenshot
   */
  router.post('/:id/screenshot', async (req: Request, res: Response) => {
    try {
      const { fullPage } = req.body;
      const result = await sessionManager.captureScreenshot(req.params.id, { fullPage });

      res.json({
        success: true,
        data: result,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    } catch (error: any) {
      if (error.message.includes('not found')) {
        return res.status(404).json({
          success: false,
          error: error.message,
          timestamp: new Date().toISOString(),
        } as ApiResponse);
      }
      logger.error('Error capturing screenshot', { error: error.message });
      res.status(500).json({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      } as ApiResponse);
    }
  });

  return router;
}

export default createSessionRoutes;
