/**
 * Screenshot Capture Module
 * Captures screenshots from browser instances for debugging and failure analysis
 */

import { Browser, Page } from 'playwright';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { ScreenshotRequest, ScreenshotResponse, WorkerConfig } from './types';
import logger from './logger';
import BrowserManager from './browser';

export class ScreenshotManager {
  private config: WorkerConfig;
  private browserManager: BrowserManager;

  constructor(config: WorkerConfig, browserManager: BrowserManager) {
    this.config = config;
    this.browserManager = browserManager;
  }

  /**
   * Capture screenshot from a browser instance
   */
  async capture(
    browserId: string,
    options: ScreenshotRequest = {}
  ): Promise<ScreenshotResponse> {
    let browser: Browser | null = null;

    try {
      browser = await this.browserManager.connect(browserId);
      const contexts = browser.contexts();
      
      if (contexts.length === 0) {
        return {
          success: false,
          error: 'No browser contexts available',
        };
      }

      const pages = contexts[0].pages();
      if (pages.length === 0) {
        return {
          success: false,
          error: 'No pages available in browser context',
        };
      }

      const page = pages[0];
      return await this.captureFromPage(page, browserId, options);
    } catch (error: any) {
      logger.error(`Failed to capture screenshot for browser ${browserId}`, {
        error: error.message,
      });
      return {
        success: false,
        error: error.message,
      };
    } finally {
      if (browser) {
        await browser.close();
      }
    }
  }

  /**
   * Capture screenshot from a specific page
   */
  async captureFromPage(
    page: Page,
    browserId: string,
    options: ScreenshotRequest = {}
  ): Promise<ScreenshotResponse> {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const screenshotId = uuidv4().substring(0, 8);
      const extension = options.type === 'jpeg' ? 'jpg' : 'png';
      const filename = `${browserId}-${timestamp}-${screenshotId}.${extension}`;
      const filepath = path.join(this.config.screenshotDir, filename);

      await page.screenshot({
        path: filepath,
        fullPage: options.fullPage ?? false,
        type: options.type ?? 'png',
        quality: options.type === 'jpeg' ? (options.quality ?? 80) : undefined,
      });

      // Update browser activity
      this.browserManager.touch(browserId);

      logger.info(`Screenshot captured for browser ${browserId}`, {
        filename,
        fullPage: options.fullPage,
      });

      return {
        success: true,
        path: filepath,
        url: `/screenshots/${filename}`,
      };
    } catch (error: any) {
      logger.error(`Screenshot capture failed for browser ${browserId}`, {
        error: error.message,
      });
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Capture failure screenshot with additional metadata
   */
  async captureFailure(
    browserId: string,
    error: string,
    context: Record<string, any> = {}
  ): Promise<ScreenshotResponse> {
    const result = await this.capture(browserId, { fullPage: true });

    if (result.success && result.path) {
      // Write metadata alongside screenshot
      const metadataPath = result.path.replace(/\.(png|jpg)$/, '.json');
      const metadata = {
        browserId,
        error,
        context,
        capturedAt: new Date().toISOString(),
        screenshotPath: result.path,
      };

      try {
        fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));
        logger.info(`Failure metadata saved`, { metadataPath });
      } catch (e: any) {
        logger.warn(`Failed to save failure metadata`, { error: e.message });
      }
    }

    return result;
  }

  /**
   * Clean up old screenshots (retention policy)
   */
  async cleanup(maxAgeMs: number = 7 * 24 * 60 * 60 * 1000): Promise<number> {
    let deletedCount = 0;
    const now = Date.now();

    try {
      const files = fs.readdirSync(this.config.screenshotDir);

      for (const file of files) {
        const filepath = path.join(this.config.screenshotDir, file);
        const stats = fs.statSync(filepath);

        if (now - stats.mtimeMs > maxAgeMs) {
          fs.unlinkSync(filepath);
          deletedCount++;
        }
      }

      if (deletedCount > 0) {
        logger.info(`Cleaned up ${deletedCount} old screenshots`);
      }
    } catch (error: any) {
      logger.error('Screenshot cleanup failed', { error: error.message });
    }

    return deletedCount;
  }
}

export default ScreenshotManager;
