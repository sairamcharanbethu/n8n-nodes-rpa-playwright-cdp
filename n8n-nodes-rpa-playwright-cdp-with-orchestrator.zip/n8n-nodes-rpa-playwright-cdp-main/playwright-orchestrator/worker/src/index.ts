/**
 * Browser Worker Service
 * Main entry point for the browser worker container
 */

import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import BrowserManager from './browser';
import ScreenshotManager from './screenshot';
import VNCManager from './vnc';
import logger from './logger';
import {
  WorkerConfig,
  LaunchBrowserRequest,
  ScreenshotRequest,
  HealthResponse,
} from './types';

// Configuration from environment variables
const config: WorkerConfig = {
  port: parseInt(process.env.WORKER_PORT || '3001', 10),
  workerId: process.env.WORKER_ID || uuidv4(),
  maxBrowsers: parseInt(process.env.BROWSERS_PER_WORKER || '1', 10),
  display: parseInt(process.env.DISPLAY?.replace(':', '') || '99', 10),
  screenshotDir: process.env.SCREENSHOT_DIR || '/data/screenshots',
  profileDir: process.env.PROFILE_DIR || '/data/profiles',
  heartbeatInterval: parseInt(process.env.HEARTBEAT_INTERVAL || '10000', 10),
  browserLaunchTimeout: parseInt(process.env.BROWSER_LAUNCH_TIMEOUT || '30000', 10),
  idleTimeout: parseInt(process.env.IDLE_TIMEOUT || '300000', 10), // 5 minutes
};

// Initialize managers
const browserManager = new BrowserManager(config);
const screenshotManager = new ScreenshotManager(config, browserManager);
const vncManager = new VNCManager(config, browserManager);

// Express app
const app = express();
app.use(express.json());

// Request logging middleware
app.use((req: Request, res: Response, next: NextFunction) => {
  const startTime = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    logger.info(`${req.method} ${req.path}`, {
      status: res.statusCode,
      duration: `${duration}ms`,
    });
  });
  next();
});

// Serve screenshots statically
app.use('/screenshots', express.static(config.screenshotDir));

// ============================================
// Health & Status Endpoints
// ============================================

/**
 * Health check endpoint
 * Used by orchestrator and Docker health checks
 */
app.get('/health', (req: Request, res: Response) => {
  const browsers = browserManager.getAll();
  const healthyBrowsers = browsers.filter(
    (b) => b.status === 'ready' || b.status === 'busy'
  );

  const status: HealthResponse['status'] =
    browsers.length === 0 || healthyBrowsers.length === browsers.length
      ? 'healthy'
      : healthyBrowsers.length > 0
      ? 'degraded'
      : 'unhealthy';

  const response: HealthResponse = {
    status,
    workerId: config.workerId,
    uptime: process.uptime(),
    browsers: {
      active: browserManager.activeCount,
      max: browserManager.maxBrowsers,
      instances: browsers.map((b) => ({
        id: b.id,
        status: b.status,
        lastHeartbeat: b.lastHeartbeat.toISOString(),
      })),
    },
    system: {
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage(),
    },
    timestamp: new Date().toISOString(),
  };

  res.status(status === 'healthy' ? 200 : status === 'degraded' ? 200 : 503).json(response);
});

/**
 * Worker info endpoint
 */
app.get('/info', (req: Request, res: Response) => {
  res.json({
    workerId: config.workerId,
    maxBrowsers: config.maxBrowsers,
    activeBrowsers: browserManager.activeCount,
    display: config.display,
    uptime: process.uptime(),
  });
});

// ============================================
// Browser Management Endpoints
// ============================================

/**
 * Launch a new browser
 * POST /browsers
 */
app.post('/browsers', async (req: Request, res: Response) => {
  try {
    const request: LaunchBrowserRequest = req.body;
    const instance = await browserManager.launch(request);

    res.status(201).json({
      success: true,
      browserId: instance.id,
      wsEndpoint: instance.wsEndpoint,
      status: instance.status,
    });
  } catch (error: any) {
    logger.error('Failed to launch browser', { error: error.message });
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

/**
 * List all browsers
 * GET /browsers
 */
app.get('/browsers', (req: Request, res: Response) => {
  const browsers = browserManager.getAll();
  res.json({
    count: browsers.length,
    browsers: browsers.map((b) => ({
      id: b.id,
      status: b.status,
      wsEndpoint: b.wsEndpoint,
      createdAt: b.createdAt.toISOString(),
      lastActivity: b.lastActivity.toISOString(),
      lastHeartbeat: b.lastHeartbeat.toISOString(),
      vncEnabled: !!b.vncPort,
      vncPort: b.vncPort,
    })),
  });
});

/**
 * Get specific browser
 * GET /browsers/:id
 */
app.get('/browsers/:id', (req: Request, res: Response) => {
  const instance = browserManager.get(req.params.id);
  if (!instance) {
    return res.status(404).json({ error: 'Browser not found' });
  }

  res.json({
    id: instance.id,
    status: instance.status,
    wsEndpoint: instance.wsEndpoint,
    createdAt: instance.createdAt.toISOString(),
    lastActivity: instance.lastActivity.toISOString(),
    lastHeartbeat: instance.lastHeartbeat.toISOString(),
    vncEnabled: !!instance.vncPort,
    vncPort: instance.vncPort,
    profilePath: instance.profilePath,
    error: instance.error,
  });
});

/**
 * Close a browser
 * DELETE /browsers/:id
 */
app.delete('/browsers/:id', async (req: Request, res: Response) => {
  try {
    const force = req.query.force === 'true';
    await browserManager.close(req.params.id, force);
    res.json({ success: true, message: 'Browser closed' });
  } catch (error: any) {
    if (error.message.includes('not found')) {
      return res.status(404).json({ error: error.message });
    }
    logger.error('Failed to close browser', { error: error.message });
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * Update browser activity (touch)
 * POST /browsers/:id/touch
 */
app.post('/browsers/:id/touch', (req: Request, res: Response) => {
  const instance = browserManager.get(req.params.id);
  if (!instance) {
    return res.status(404).json({ error: 'Browser not found' });
  }

  browserManager.touch(req.params.id);
  res.json({ success: true, lastActivity: new Date().toISOString() });
});

// ============================================
// Screenshot Endpoints
// ============================================

/**
 * Capture screenshot
 * POST /browsers/:id/screenshot
 */
app.post('/browsers/:id/screenshot', async (req: Request, res: Response) => {
  try {
    const options: ScreenshotRequest = req.body;
    const result = await screenshotManager.capture(req.params.id, options);

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error: any) {
    logger.error('Screenshot capture failed', { error: error.message });
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * Capture failure screenshot with metadata
 * POST /browsers/:id/screenshot/failure
 */
app.post('/browsers/:id/screenshot/failure', async (req: Request, res: Response) => {
  try {
    const { error, context } = req.body;
    const result = await screenshotManager.captureFailure(
      req.params.id,
      error || 'Unknown error',
      context || {}
    );

    if (result.success) {
      res.json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error: any) {
    logger.error('Failure screenshot capture failed', { error: error.message });
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// VNC Endpoints
// ============================================

/**
 * Enable VNC for debugging
 * POST /browsers/:id/vnc
 */
app.post('/browsers/:id/vnc', async (req: Request, res: Response) => {
  const result = await vncManager.enable(req.params.id);

  if (result.success) {
    res.json(result);
  } else {
    res.status(result.error?.includes('not found') ? 404 : 500).json(result);
  }
});

/**
 * Disable VNC
 * DELETE /browsers/:id/vnc
 */
app.delete('/browsers/:id/vnc', async (req: Request, res: Response) => {
  await vncManager.disable(req.params.id);
  res.json({ success: true, message: 'VNC disabled' });
});

/**
 * Get VNC status
 * GET /browsers/:id/vnc
 */
app.get('/browsers/:id/vnc', (req: Request, res: Response) => {
  const instance = browserManager.get(req.params.id);
  if (!instance) {
    return res.status(404).json({ error: 'Browser not found' });
  }

  res.json({
    enabled: vncManager.isEnabled(req.params.id),
    port: instance.vncPort,
  });
});

// ============================================
// Error Handler
// ============================================

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Internal server error' });
});

// ============================================
// Graceful Shutdown
// ============================================

async function shutdown(signal: string): Promise<void> {
  logger.info(`Received ${signal}, shutting down gracefully...`);

  try {
    // Disable all VNC servers
    await vncManager.disableAll();

    // Close all browsers
    await browserManager.closeAll();

    logger.info('Shutdown complete');
    process.exit(0);
  } catch (error: any) {
    logger.error('Error during shutdown', { error: error.message });
    process.exit(1);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ============================================
// Start Server
// ============================================

app.listen(config.port, () => {
  logger.info(`Browser worker started`, {
    workerId: config.workerId,
    port: config.port,
    maxBrowsers: config.maxBrowsers,
    display: config.display,
  });
});

export default app;
