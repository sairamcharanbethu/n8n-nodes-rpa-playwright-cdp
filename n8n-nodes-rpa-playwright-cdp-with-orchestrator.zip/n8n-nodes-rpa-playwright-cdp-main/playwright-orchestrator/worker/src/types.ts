/**
 * Browser Worker Types
 */

export interface BrowserInstance {
  id: string;
  wsEndpoint: string;           // CDP WebSocket endpoint
  pid: number;                  // Browser process ID
  display: number;              // X11 display number
  status: 'launching' | 'ready' | 'busy' | 'error' | 'closing';
  createdAt: Date;
  lastActivity: Date;
  lastHeartbeat: Date;
  vncPort?: number;             // VNC port if enabled
  vncPid?: number;              // VNC process ID
  profilePath?: string;         // Chrome profile directory
  error?: string;
}

export interface LaunchBrowserRequest {
  profileId?: string;           // For persistent sessions
  profilePath?: string;         // Custom profile path
  headless?: boolean;           // Default: false (headed for VNC viewing)
  args?: string[];              // Additional browser arguments
  timeout?: number;             // Launch timeout in ms
}

export interface LaunchBrowserResponse {
  success: boolean;
  browserId?: string;
  wsEndpoint?: string;
  error?: string;
}

export interface CloseBrowserRequest {
  force?: boolean;              // Force kill if graceful close fails
}

export interface ScreenshotRequest {
  fullPage?: boolean;
  type?: 'png' | 'jpeg';
  quality?: number;             // JPEG quality (0-100)
}

export interface ScreenshotResponse {
  success: boolean;
  path?: string;
  url?: string;
  error?: string;
}

export interface VNCEnableResponse {
  success: boolean;
  port?: number;
  password?: string;            // VNC password if set
  error?: string;
}

export interface HealthResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  workerId: string;
  uptime: number;
  browsers: {
    active: number;
    max: number;
    instances: Array<{
      id: string;
      status: string;
      lastHeartbeat: string;
    }>;
  };
  system: {
    memoryUsage: NodeJS.MemoryUsage;
    cpuUsage: NodeJS.CpuUsage;
  };
  timestamp: string;
}

export interface WorkerConfig {
  port: number;
  workerId: string;
  maxBrowsers: number;
  display: number;
  screenshotDir: string;
  profileDir: string;
  heartbeatInterval: number;    // ms
  browserLaunchTimeout: number; // ms
  idleTimeout: number;          // ms - close browser after inactivity
}
