/**
 * VNC Manager
 * On-demand VNC server for browser debugging
 */

import { spawn, ChildProcess } from 'child_process';
import { BrowserInstance, VNCEnableResponse, WorkerConfig } from './types';
import logger from './logger';
import BrowserManager from './browser';

export class VNCManager {
  private config: WorkerConfig;
  private browserManager: BrowserManager;
  private vncProcesses: Map<string, ChildProcess> = new Map();
  private baseVncPort = 5900;

  constructor(config: WorkerConfig, browserManager: BrowserManager) {
    this.config = config;
    this.browserManager = browserManager;
  }

  /**
   * Enable VNC for a browser instance
   */
  async enable(browserId: string): Promise<VNCEnableResponse> {
    const instance = this.browserManager.get(browserId);
    if (!instance) {
      return {
        success: false,
        error: `Browser ${browserId} not found`,
      };
    }

    // Check if VNC is already running
    if (instance.vncPid && this.vncProcesses.has(browserId)) {
      logger.info(`VNC already running for browser ${browserId}`, {
        port: instance.vncPort,
      });
      return {
        success: true,
        port: instance.vncPort,
      };
    }

    try {
      // Allocate a VNC port
      const vncPort = this.allocatePort();

      // Start x11vnc server for the display
      const vncProcess = spawn('x11vnc', [
        '-display', `:${instance.display}`,
        '-rfbport', vncPort.toString(),
        '-shared',           // Allow multiple viewers
        '-forever',          // Don't exit after first client disconnects
        '-nopw',             // No password (security handled at network level)
        '-xkb',              // Use XKEYBOARD extension
        '-noxrecord',        // Don't use RECORD extension
        '-noxfixes',         // Don't use XFIXES extension
        '-noxdamage',        // Don't use DAMAGE extension
        '-repeat',           // Handle key repeat
        '-ncache', '0',      // Disable client-side caching (was causing 12x height issue)
        '-clip', '1920x1080+0+0',  // Clip to exact screen size
      ], {
        stdio: ['ignore', 'pipe', 'pipe'],
      });

      // Log VNC output
      vncProcess.stdout?.on('data', (data) => {
        logger.debug(`VNC stdout [${browserId}]: ${data.toString().trim()}`);
      });

      vncProcess.stderr?.on('data', (data) => {
        const msg = data.toString().trim();
        // Filter out common informational messages
        if (!msg.includes('Got connection from') && !msg.includes('other clients')) {
          logger.debug(`VNC stderr [${browserId}]: ${msg}`);
        }
      });

      vncProcess.on('error', (error) => {
        logger.error(`VNC process error for browser ${browserId}`, {
          error: error.message,
        });
        this.cleanup(browserId);
      });

      vncProcess.on('exit', (code) => {
        logger.info(`VNC process exited for browser ${browserId}`, { code });
        this.cleanup(browserId);
      });

      // Store process reference
      this.vncProcesses.set(browserId, vncProcess);

      // Update browser instance
      instance.vncPort = vncPort;
      instance.vncPid = vncProcess.pid;

      // Wait a moment for VNC to start
      await new Promise((resolve) => setTimeout(resolve, 500));

      logger.info(`VNC enabled for browser ${browserId}`, {
        port: vncPort,
        pid: vncProcess.pid,
      });

      return {
        success: true,
        port: vncPort,
      };
    } catch (error: any) {
      logger.error(`Failed to enable VNC for browser ${browserId}`, {
        error: error.message,
      });
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Disable VNC for a browser instance
   */
  async disable(browserId: string): Promise<void> {
    const vncProcess = this.vncProcesses.get(browserId);
    if (vncProcess) {
      logger.info(`Disabling VNC for browser ${browserId}`);
      vncProcess.kill('SIGTERM');
      this.cleanup(browserId);
    }
  }

  /**
   * Check if VNC is enabled for a browser
   */
  isEnabled(browserId: string): boolean {
    return this.vncProcesses.has(browserId);
  }

  /**
   * Get VNC port for a browser
   */
  getPort(browserId: string): number | undefined {
    const instance = this.browserManager.get(browserId);
    return instance?.vncPort;
  }

  /**
   * Allocate an available VNC port
   */
  private allocatePort(): number {
    const usedPorts = new Set<number>();
    for (const instance of this.browserManager.getAll()) {
      if (instance.vncPort) {
        usedPorts.add(instance.vncPort);
      }
    }

    // Find next available port starting from base
    let port = this.baseVncPort;
    while (usedPorts.has(port)) {
      port++;
    }
    return port;
  }

  /**
   * Cleanup VNC resources for a browser
   */
  private cleanup(browserId: string): void {
    const vncProcess = this.vncProcesses.get(browserId);
    if (vncProcess && !vncProcess.killed) {
      try {
        vncProcess.kill('SIGKILL');
      } catch (e) {
        // Process might already be dead
      }
    }
    this.vncProcesses.delete(browserId);

    // Update browser instance
    const instance = this.browserManager.get(browserId);
    if (instance) {
      instance.vncPort = undefined;
      instance.vncPid = undefined;
    }
  }

  /**
   * Disable all VNC servers (shutdown)
   */
  async disableAll(): Promise<void> {
    logger.info('Disabling all VNC servers...');
    for (const browserId of this.vncProcesses.keys()) {
      await this.disable(browserId);
    }
    logger.info('All VNC servers disabled');
  }
}

export default VNCManager;
