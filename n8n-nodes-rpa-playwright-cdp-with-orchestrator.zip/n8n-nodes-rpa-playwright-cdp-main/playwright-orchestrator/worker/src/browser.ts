/**
 * Browser Lifecycle Manager
 * Manages Chromium browser instances with CDP (Chrome DevTools Protocol)
 * Launches Chrome directly to enable true CDP sharing across connections
 */

import { chromium, Browser } from 'playwright';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';
import http from 'http';
import { spawn, ChildProcess } from 'child_process';
import { BrowserInstance, LaunchBrowserRequest, WorkerConfig } from './types';
import logger from './logger';

// Helper to get CDP WebSocket URL from debugging port with retries
async function getCdpWebSocketUrl(port: number, host: string = 'localhost', retries: number = 10): Promise<string> {
  for (let i = 0; i < retries; i++) {
    try {
      const url = await new Promise<string>((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Timeout')), 2000);

        http.get(`http://${host}:${port}/json/version`, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            clearTimeout(timeout);
            try {
              const json = JSON.parse(data);
              resolve(json.webSocketDebuggerUrl);
            } catch (e) {
              reject(new Error('Failed to parse CDP response'));
            }
          });
        }).on('error', (e) => {
          clearTimeout(timeout);
          reject(e);
        });
      });
      return url;
    } catch (e) {
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
  }
  throw new Error(`Failed to get CDP URL after ${retries} attempts`);
}

export class BrowserManager {
  private browsers: Map<string, BrowserInstance> = new Map();
  private browserProcesses: Map<string, ChildProcess> = new Map();
  private config: WorkerConfig;
  private heartbeatIntervals: Map<string, NodeJS.Timeout> = new Map();
  private nextDebugPort: number = 9222;

  constructor(config: WorkerConfig) {
    this.config = config;
    this.ensureDirectories();
  }

  private ensureDirectories(): void {
    if (!fs.existsSync(this.config.screenshotDir)) {
      fs.mkdirSync(this.config.screenshotDir, { recursive: true });
    }
    if (!fs.existsSync(this.config.profileDir)) {
      fs.mkdirSync(this.config.profileDir, { recursive: true });
    }
  }

  /**
   * Find the Chrome executable installed by Playwright
   */
  private findChromePath(): string {
    // Playwright installs browsers in /ms-playwright/
    const playwrightDir = '/ms-playwright';

    if (fs.existsSync(playwrightDir)) {
      const dirs = fs.readdirSync(playwrightDir);
      logger.info(`Playwright directory contents: ${dirs.join(', ')}`);

      // Find chromium directory (e.g., chromium-1155, chromium-1140, etc.)
      const chromiumDir = dirs.find(d => d.startsWith('chromium-'));
      if (chromiumDir) {
        // Try different possible paths (structure varies by Playwright version)
        const possiblePaths = [
          path.join(playwrightDir, chromiumDir, 'chrome-linux64', 'chrome'),
          path.join(playwrightDir, chromiumDir, 'chrome-linux', 'chrome'),
          path.join(playwrightDir, chromiumDir, 'chrome'),
        ];

        for (const chromePath of possiblePaths) {
          if (fs.existsSync(chromePath)) {
            logger.info(`Found Chrome at: ${chromePath}`);
            return chromePath;
          }
        }

        // Log what's in the chromium directory for debugging
        const chromiumContents = fs.readdirSync(path.join(playwrightDir, chromiumDir));
        logger.warn(`Chrome not found in expected paths. Chromium dir contents: ${chromiumContents.join(', ')}`);
      }
    }

    // Fallback to system chrome
    const fallbacks = [
      '/usr/bin/google-chrome',
      '/usr/bin/chromium',
      '/usr/bin/chromium-browser',
    ];

    for (const fallback of fallbacks) {
      if (fs.existsSync(fallback)) {
        logger.info(`Using fallback Chrome at: ${fallback}`);
        return fallback;
      }
    }

    throw new Error('Chrome executable not found. Check worker logs for directory contents.');
  }

  /**
   * Launch a new browser instance with CDP (Chrome DevTools Protocol) enabled
   * Spawns Chrome directly (not via Playwright) for true CDP sharing
   */
  async launch(request: LaunchBrowserRequest = {}): Promise<BrowserInstance> {
    // Check capacity
    if (this.browsers.size >= this.config.maxBrowsers) {
      throw new Error(`Worker at capacity: ${this.browsers.size}/${this.config.maxBrowsers} browsers`);
    }

    const browserId = uuidv4();
    const debugPort = this.nextDebugPort++;

    const instance: BrowserInstance = {
      id: browserId,
      wsEndpoint: '',
      pid: 0,
      display: this.config.display,
      status: 'launching',
      createdAt: new Date(),
      lastActivity: new Date(),
      lastHeartbeat: new Date(),
    };

    this.browsers.set(browserId, instance);
    logger.info(`Launching browser ${browserId} with CDP on port ${debugPort}`, { profileId: request.profileId });

    try {
      // Determine profile path
      let profilePath: string | undefined;
      if (request.profileId) {
        profilePath = path.join(this.config.profileDir, request.profileId);
        instance.profilePath = profilePath;
        if (!fs.existsSync(profilePath)) {
          fs.mkdirSync(profilePath, { recursive: true });
        }
      } else {
        // Create temp profile for this session
        profilePath = path.join(this.config.profileDir, `temp-${browserId}`);
        fs.mkdirSync(profilePath, { recursive: true });
        instance.profilePath = profilePath;
      }

      // Find Chrome executable installed by Playwright
      const chromePath = this.findChromePath();

      // Build browser arguments for CDP access
      const args = [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-infobars',
        '--disable-backgrounding-occluded-windows',
        '--disable-renderer-backgrounding',
        '--disable-background-timer-throttling',
        '--ignore-certificate-errors',
        '--test-type',  // Suppresses "unsupported command-line flag" warning
        '--disable-component-update',  // Prevents Chrome from trying to update components
        '--disable-default-apps',
        '--disable-extensions',
        '--disable-sync',
        '--disable-translate',
        '--metrics-recording-only',
        '--no-pings',
        '--start-maximized',  // Start browser maximized
        '--window-size=1920,1080',  // Set window size to match virtual display
        '--window-position=0,0',  // Position at top-left
        `--remote-debugging-port=${debugPort}`,
        '--remote-debugging-address=0.0.0.0',
        `--user-data-dir=${profilePath}`,
        ...(request.args || []),
      ];

      // Add headless flag if requested
      if (request.headless) {
        args.push('--headless=new');
      }

      // Spawn Chrome directly
      logger.info(`Spawning Chrome: ${chromePath} with args: ${args.slice(0, 5).join(' ')}...`);

      const chromeProcess = spawn(chromePath, args, {
        env: {
          ...process.env,
          DISPLAY: `:${this.config.display}`,
          // Set fake Google API keys to suppress "API keys missing" warning
          GOOGLE_API_KEY: 'no',
          GOOGLE_DEFAULT_CLIENT_ID: 'no',
          GOOGLE_DEFAULT_CLIENT_SECRET: 'no',
        },
        detached: false,
        stdio: ['ignore', 'pipe', 'pipe'],
      });

      // Check if process started
      if (!chromeProcess.pid) {
        throw new Error('Failed to spawn Chrome process');
      }

      const pid = chromeProcess.pid;
      logger.info(`Chrome process started with PID ${pid}`);

      // Track if Chrome exits early
      let chromeExited = false;
      let exitCode: number | null = null;

      chromeProcess.on('exit', (code) => {
        chromeExited = true;
        exitCode = code;
        logger.warn(`Chrome process ${pid} exited with code ${code}`);
      });

      // Log Chrome output for debugging
      chromeProcess.stdout?.on('data', (data) => {
        logger.debug(`Chrome stdout: ${data.toString().trim()}`);
      });
      chromeProcess.stderr?.on('data', (data) => {
        const msg = data.toString().trim();
        // Log all stderr for debugging
        logger.info(`Chrome stderr: ${msg}`);
      });

      // Wait a moment for Chrome to start
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Check if Chrome crashed immediately
      if (chromeExited) {
        throw new Error(`Chrome exited immediately with code ${exitCode}`);
      }

      // Wait for CDP to be ready and get the WebSocket URL
      let wsEndpoint: string;
      try {
        wsEndpoint = await getCdpWebSocketUrl(debugPort, '127.0.0.1', 20);
      } catch (e) {
        chromeProcess.kill();
        throw new Error(`Failed to connect to Chrome CDP: ${(e as Error).message}`);
      }

      // Chrome binds to 127.0.0.1 despite --remote-debugging-address=0.0.0.0
      // Use socat to proxy the connection from 0.0.0.0 to 127.0.0.1
      const externalPort = debugPort + 1000; // Use port 10222, 10223, etc. for external access
      const socatProcess = spawn('socat', [
        `TCP-LISTEN:${externalPort},fork,reuseaddr,bind=0.0.0.0`,
        `TCP:127.0.0.1:${debugPort}`
      ], {
        detached: false,
        stdio: ['ignore', 'pipe', 'pipe'],
      });

      if (!socatProcess.pid) {
        chromeProcess.kill();
        throw new Error('Failed to start socat proxy');
      }

      logger.info(`Started socat proxy: 0.0.0.0:${externalPort} -> 127.0.0.1:${debugPort} (PID: ${socatProcess.pid})`);

      // Store socat process for cleanup
      (chromeProcess as any).socatProcess = socatProcess;

      // Replace localhost with external hostname and use the proxied port
      const externalHost = process.env.EXTERNAL_HOST || process.env.HOSTNAME || 'worker';
      wsEndpoint = wsEndpoint
        .replace(`127.0.0.1:${debugPort}`, `${externalHost}:${externalPort}`)
        .replace(`localhost:${debugPort}`, `${externalHost}:${externalPort}`);

      // Update instance
      instance.wsEndpoint = wsEndpoint;
      instance.pid = pid;
      instance.status = 'ready';
      instance.lastActivity = new Date();
      instance.lastHeartbeat = new Date();

      this.browserProcesses.set(browserId, chromeProcess);
      this.browsers.set(browserId, instance);

      // Start heartbeat tracking
      this.startHeartbeat(browserId);

      // Handle unexpected close
      chromeProcess.on('exit', (code) => {
        logger.warn(`Browser ${browserId} process exited with code ${code}`);
        this.cleanup(browserId);
      });

      logger.info(`Browser ${browserId} launched successfully with CDP`, {
        wsEndpoint,
        pid,
        debugPort,
        profilePath,
      });

      return instance;
    } catch (error: any) {
      instance.status = 'error';
      instance.error = error.message;
      this.browsers.set(browserId, instance);

      logger.error(`Failed to launch browser ${browserId}`, { error: error.message });
      throw error;
    }
  }

  /**
   * Close a browser instance
   */
  async close(browserId: string, force = false): Promise<void> {
    const instance = this.browsers.get(browserId);
    if (!instance) {
      throw new Error(`Browser ${browserId} not found`);
    }

    logger.info(`Closing browser ${browserId}`, { force });

    instance.status = 'closing';
    this.browsers.set(browserId, instance);

    // Stop heartbeat
    this.stopHeartbeat(browserId);

    // Stop VNC if running
    if (instance.vncPid) {
      try {
        process.kill(instance.vncPid, 'SIGTERM');
      } catch (e) {
        // Process might already be dead
      }
    }

    // Kill the Chrome process and socat proxy
    const chromeProcess = this.browserProcesses.get(browserId);
    if (chromeProcess) {
      // Kill socat proxy first
      const socatProcess = (chromeProcess as any).socatProcess;
      if (socatProcess) {
        try {
          socatProcess.kill('SIGTERM');
        } catch (e) {
          // Ignore
        }
      }

      try {
        if (force) {
          chromeProcess.kill('SIGKILL');
        } else {
          chromeProcess.kill('SIGTERM');
        }
      } catch (error: any) {
        logger.warn(`Error killing browser process ${browserId}`, { error: error.message });
      }
    }

    this.cleanup(browserId);
  }

  /**
   * Get browser instance by ID
   */
  get(browserId: string): BrowserInstance | undefined {
    return this.browsers.get(browserId);
  }

  /**
   * Get all browser instances
   */
  getAll(): BrowserInstance[] {
    return Array.from(this.browsers.values());
  }

  /**
   * Update browser activity timestamp
   */
  touch(browserId: string): void {
    const instance = this.browsers.get(browserId);
    if (instance) {
      instance.lastActivity = new Date();
      this.browsers.set(browserId, instance);
    }
  }

  /**
   * Connect to browser via CDP for operations
   */
  async connect(browserId: string): Promise<Browser> {
    const instance = this.browsers.get(browserId);
    if (!instance) {
      throw new Error(`Browser ${browserId} not found`);
    }
    if (instance.status !== 'ready' && instance.status !== 'busy') {
      throw new Error(`Browser ${browserId} is not ready (status: ${instance.status})`);
    }

    return chromium.connectOverCDP(instance.wsEndpoint);
  }

  /**
   * Cleanup browser resources
   */
  private cleanup(browserId: string): void {
    this.stopHeartbeat(browserId);
    this.browserProcesses.delete(browserId);
    this.browsers.delete(browserId);
    logger.info(`Browser ${browserId} cleaned up`);
  }

  /**
   * Start heartbeat tracking for a browser
   */
  private startHeartbeat(browserId: string): void {
    const interval = setInterval(() => {
      const instance = this.browsers.get(browserId);
      if (instance) {
        instance.lastHeartbeat = new Date();
        this.browsers.set(browserId, instance);
      }
    }, this.config.heartbeatInterval);

    this.heartbeatIntervals.set(browserId, interval);
  }

  /**
   * Stop heartbeat tracking for a browser
   */
  private stopHeartbeat(browserId: string): void {
    const interval = this.heartbeatIntervals.get(browserId);
    if (interval) {
      clearInterval(interval);
      this.heartbeatIntervals.delete(browserId);
    }
  }

  /**
   * Close all browsers (shutdown)
   */
  async closeAll(): Promise<void> {
    logger.info('Closing all browsers...');
    const closePromises = Array.from(this.browsers.keys()).map((id) =>
      this.close(id, true).catch((e) => logger.error(`Error closing browser ${id}`, { error: e.message }))
    );
    await Promise.all(closePromises);
    logger.info('All browsers closed');
  }

  /**
   * Get count of active browsers
   */
  get activeCount(): number {
    return this.browsers.size;
  }

  /**
   * Get max browsers allowed
   */
  get maxBrowsers(): number {
    return this.config.maxBrowsers;
  }
}

export default BrowserManager;
