#!/bin/bash
set -e

# Start Xvfb (virtual framebuffer) for headed browser
echo "Starting Xvfb on display :99..."
Xvfb :99 -screen 0 1920x1080x24 -ac &
sleep 2

# Start fluxbox window manager (needed for proper window rendering)
echo "Starting Fluxbox window manager..."
DISPLAY=:99 fluxbox &
sleep 1

echo "Virtual display ready. Starting worker..."

# Execute the main command
exec "$@"
