# Playwright Browser Orchestrator

A custom Playwright-native browser orchestration layer for enterprise RPA automation with n8n.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         n8n Workflows                            │
│                    (Custom RPA Nodes)                            │
└─────────────────────────┬───────────────────────────────────────┘
                          │ REST API
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Orchestrator Service                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │ Session Mgr │  │ Pool Manager│  │ Profile Lock│              │
│  └─────────────┘  └─────────────┘  └─────────────┘              │
│                          │                                       │
│                    ┌─────┴─────┐                                 │
│                    │   Redis   │                                 │
│                    └───────────┘                                 │
└─────────────────────────┬───────────────────────────────────────┘
                          │ Worker API
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│    Worker 1     │ │    Worker 2     │ │    Worker N     │
│  ┌───────────┐  │ │  ┌───────────┐  │ │  ┌───────────┐  │
│  │ Chromium  │  │ │  │ Chromium  │  │ │  │ Chromium  │  │
│  │  (Headed) │  │ │  │  (Headed) │  │ │  │  (Headed) │  │
│  └───────────┘  │ │  └───────────┘  │ │  └───────────┘  │
│  ┌───────────┐  │ │  ┌───────────┐  │ │  ┌───────────┐  │
│  │    VNC    │  │ │  │    VNC    │  │ │  │    VNC    │  │
│  │ (on-demand)│ │ │  │ (on-demand)│ │ │  │ (on-demand)│ │
│  └───────────┘  │ │  └───────────┘  │ │  └───────────┘  │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

## Features

- **Native Playwright Support**: Direct CDP connections without Selenium abstraction
- **Browser Pool Management**: Hybrid warm pool with on-demand overflow
- **Session Modes**: Ephemeral (clean) and persistent (logged-in) sessions
- **Profile Locking**: Exclusive access to persistent browser profiles
- **Live Debugging**: On-demand VNC access for troubleshooting
- **Auto-Cleanup**: Idle timeout, max lifetime, and orphan session cleanup
- **Scalable**: Designed for Docker Compose now, Kubernetes later

## Quick Start

### Development (Single Worker)

```bash
cd playwright-orchestrator

# Build and start
docker-compose -f docker-compose.dev.yml up --build

# Services:
# - Orchestrator API: http://localhost:3000
# - Worker API: http://localhost:3001
# - noVNC Web Client: http://localhost:6080
# - Redis: localhost:6379
```

### Production (Multiple Workers)

```bash
cd playwright-orchestrator

# Set Redis password
export REDIS_PASSWORD=your-secure-password

# Build and start
docker-compose up --build -d

# Services:
# - Orchestrator API: http://localhost:3000
# - noVNC Web Client: http://localhost:6080
# - n8n: http://localhost:5678
```

## API Reference

### Sessions

#### Create Session
```http
POST /sessions
Content-Type: application/json

{
  "mode": "ephemeral",           // or "persistent"
  "profileId": "salesforce-login", // required for persistent
  "workflowId": "abc123",        // optional
  "timeout": 300                 // seconds, default 300
}
```

#### List Sessions
```http
GET /sessions
```

#### Get Session
```http
GET /sessions/:id
```

#### Get CDP URL
```http
GET /sessions/:id/cdp
```

#### Close Session
```http
DELETE /sessions/:id
```

#### Enable VNC
```http
POST /sessions/:id/vnc
```

#### Capture Screenshot
```http
POST /sessions/:id/screenshot
Content-Type: application/json

{
  "fullPage": true
}
```

### Pool Status

```http
GET /pool
```

### Health Check

```http
GET /health
```

## Configuration

### Orchestrator Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | HTTP server port |
| `REDIS_URL` | `redis://localhost:6379` | Redis connection URL |
| `WORKER_URLS` | `http://worker:3001` | Comma-separated worker URLs |
| `WARM_POOL_SIZE` | `2` | Target warm pool size |
| `SESSION_TIMEOUT` | `300000` | Default session timeout (ms) |
| `MAX_SESSION_LIFETIME` | `1800000` | Max session lifetime (ms) |
| `IDLE_TIMEOUT` | `300000` | Session idle timeout (ms) |
| `LOG_LEVEL` | `info` | Log level (debug, info, warn, error) |

### Worker Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `WORKER_PORT` | `3001` | HTTP server port |
| `WORKER_ID` | `auto-generated` | Unique worker identifier |
| `BROWSERS_PER_WORKER` | `1` | Max browsers per container |
| `DISPLAY` | `:99` | X11 display number |
| `SCREENSHOT_DIR` | `/data/screenshots` | Screenshot storage path |
| `PROFILE_DIR` | `/data/profiles` | Profile storage path |

## n8n Integration

Update your n8n RPA nodes to connect to the orchestrator instead of Selenium Grid:

```typescript
// Old: Selenium Hub
const seleniumHubUrl = 'http://selenium-hub:4444';

// New: Orchestrator
const orchestratorUrl = 'http://orchestrator:3000';

// Create session
const response = await fetch(`${orchestratorUrl}/sessions`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    mode: 'ephemeral',
    workflowId: this.getWorkflowId(),
  }),
});

const { data } = await response.json();
const cdpUrl = data.cdpUrl;

// Connect with Playwright
const browser = await playwright.chromium.connectOverCDP(cdpUrl);
```

## License

MIT
