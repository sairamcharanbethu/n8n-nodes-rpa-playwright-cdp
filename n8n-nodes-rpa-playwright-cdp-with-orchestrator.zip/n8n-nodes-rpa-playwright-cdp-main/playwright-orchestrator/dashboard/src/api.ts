import { ApiResponse, Session, PoolStatus, HealthStatus } from './types';

const API_BASE = '/api';

async function fetchApi<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });

  const data: ApiResponse<T> = await response.json();

  if (!data.success) {
    throw new Error(data.error || 'API request failed');
  }

  return data.data as T;
}

export async function getHealth(): Promise<HealthStatus> {
  return fetchApi<HealthStatus>('/health');
}

export async function getPoolStatus(): Promise<PoolStatus> {
  return fetchApi<PoolStatus>('/pool');
}

export async function getSessions(): Promise<{ sessions: Session[]; total: number }> {
  return fetchApi<{ sessions: Session[]; total: number }>('/sessions');
}

export async function getSession(sessionId: string): Promise<Session> {
  return fetchApi<Session>(`/sessions/${sessionId}`);
}

export async function createSession(options: {
  mode?: 'ephemeral' | 'persistent';
  profileId?: string;
  timeout?: number;
}): Promise<{ sessionId: string; cdpUrl: string }> {
  return fetchApi<{ sessionId: string; cdpUrl: string }>('/sessions', {
    method: 'POST',
    body: JSON.stringify(options),
  });
}

export async function closeSession(sessionId: string, force = false): Promise<void> {
  await fetchApi<void>(`/sessions/${sessionId}${force ? '?force=true' : ''}`, {
    method: 'DELETE',
  });
}

export async function enableVnc(sessionId: string): Promise<{ port: number; host: string }> {
  return fetchApi<{ port: number; host: string }>(`/sessions/${sessionId}/vnc`, {
    method: 'POST',
  });
}

export async function disableVnc(sessionId: string): Promise<void> {
  await fetchApi<void>(`/sessions/${sessionId}/vnc`, {
    method: 'DELETE',
  });
}

export async function captureScreenshot(sessionId: string): Promise<{ url: string }> {
  return fetchApi<{ url: string }>(`/sessions/${sessionId}/screenshot`, {
    method: 'POST',
    body: JSON.stringify({ fullPage: false }),
  });
}
