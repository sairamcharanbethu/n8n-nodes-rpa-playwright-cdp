import { useState, useEffect, useCallback } from 'react';
import { Session, PoolStatus, HealthStatus } from './types';
import { getHealth, getPoolStatus, getSessions, createSession, closeSession, enableVnc } from './api';
import { VNCViewer } from './components/VNCViewer';

function App() {
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [pool, setPool] = useState<PoolStatus | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [vncSession, setVncSession] = useState<{ sessionId: string; host: string; port: number } | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const [healthData, poolData, sessionsData] = await Promise.all([
        getHealth().catch(() => null),
        getPoolStatus().catch(() => null),
        getSessions().catch(() => ({ sessions: [], total: 0 })),
      ]);

      setHealth(healthData);
      setPool(poolData);
      setSessions(sessionsData.sessions);
      setError(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleCreateSession = async () => {
    try {
      await createSession({ mode: 'ephemeral' });
      fetchData();
    } catch (err: any) {
      alert(`Failed to create session: ${err.message}`);
    }
  };

  const handleCloseSession = async (sessionId: string) => {
    if (!confirm('Close this session?')) return;
    try {
      await closeSession(sessionId);
      fetchData();
    } catch (err: any) {
      alert(`Failed to close session: ${err.message}`);
    }
  };

  const handleViewVnc = async (sessionId: string) => {
    try {
      const { port, host } = await enableVnc(sessionId);
      setVncSession({ sessionId, host: host || 'worker', port });
    } catch (err: any) {
      alert(`Failed to enable VNC: ${err.message}`);
    }
  };

  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString();
  };

  const formatDuration = (start: string) => {
    const ms = Date.now() - new Date(start).getTime();
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <header className="header">
        <h1>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
            <circle cx="8.5" cy="8.5" r="1.5"></circle>
            <polyline points="21 15 16 10 5 21"></polyline>
          </svg>
          Playwright Browser Orchestrator
        </h1>
        <div className="header-status">
          <span
            className={`status-dot ${health?.status === 'healthy' ? '' : health?.status === 'degraded' ? 'degraded' : 'offline'}`}
          ></span>
          {health?.status || 'offline'}
        </div>
      </header>

      {error && (
        <div className="card" style={{ background: 'rgba(239, 68, 68, 0.1)', borderColor: 'var(--error)', marginBottom: 24 }}>
          <p style={{ color: 'var(--error)' }}>Error: {error}</p>
        </div>
      )}

      <div className="grid">
        <div className="card">
          <div className="card-title">Active Sessions</div>
          <div className={`card-value ${sessions.length > 0 ? 'success' : ''}`}>
            {sessions.length}
          </div>
        </div>
        <div className="card">
          <div className="card-title">Available Slots</div>
          <div className={`card-value ${pool?.availableSlots === 0 ? 'warning' : ''}`}>
            {pool?.availableSlots ?? '-'}
          </div>
        </div>
        <div className="card">
          <div className="card-title">Warm Pool</div>
          <div className="card-value">
            {pool?.warmPoolSize ?? 0} / {pool?.warmPoolTarget ?? 0}
          </div>
        </div>
      </div>

      <section className="section">
        <div className="section-header">
          <h2 className="section-title">Sessions</h2>
          <button className="btn btn-primary" onClick={handleCreateSession}>
            + New Session
          </button>
        </div>

        {sessions.length === 0 ? (
          <div className="empty-state">
            <p>No active sessions</p>
            <p style={{ fontSize: 14, marginTop: 8 }}>Create a session or wait for the warm pool to initialize</p>
          </div>
        ) : (
          <div className="sessions-list">
            {sessions.map((session) => (
              <div key={session.id} className="session-card">
                <div className="session-info">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span className="session-id">{session.id.substring(0, 8)}...</span>
                    <span className={`session-status ${session.status}`}>{session.status}</span>
                    <span style={{
                      fontSize: 12,
                      padding: '2px 6px',
                      background: 'var(--bg-card)',
                      borderRadius: 4
                    }}>
                      {session.mode}
                    </span>
                  </div>
                  <div className="session-meta">
                    <span>Worker: {session.workerId}</span>
                    <span>Duration: {formatDuration(session.createdAt)}</span>
                    <span>Last active: {formatTime(session.lastActivity)}</span>
                    {session.metadata.currentUrl && (
                      <span>URL: {session.metadata.currentUrl.substring(0, 40)}...</span>
                    )}
                  </div>
                </div>
                <div className="session-actions">
                  <button
                    className="btn btn-secondary btn-small"
                    onClick={() => handleViewVnc(session.id)}
                  >
                    View VNC
                  </button>
                  <button
                    className="btn btn-danger btn-small"
                    onClick={() => handleCloseSession(session.id)}
                  >
                    Close
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="section">
        <div className="section-header">
          <h2 className="section-title">Workers</h2>
        </div>

        <div className="workers-grid">
          {pool?.workers.map((worker) => (
            <div key={worker.id} className="worker-card">
              <div className="worker-header">
                <span className="worker-id">{worker.id}</span>
                <span className={`worker-status ${worker.status}`}>{worker.status}</span>
              </div>
              <div className="worker-stats">
                <span>Browsers: {worker.active}/{worker.max}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {vncSession && (
        <VNCViewer
          sessionId={vncSession.sessionId}
          vncHost={vncSession.host}
          vncPort={vncSession.port}
          onClose={() => setVncSession(null)}
        />
      )}
    </div>
  );
}

export default App;
