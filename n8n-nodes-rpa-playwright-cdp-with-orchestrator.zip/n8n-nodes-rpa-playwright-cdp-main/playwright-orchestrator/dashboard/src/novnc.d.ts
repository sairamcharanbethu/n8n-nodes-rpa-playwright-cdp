declare module '@novnc/novnc/lib/rfb.js' {
  export default class RFB {
    constructor(
      target: HTMLElement,
      url: string,
      options?: {
        shared?: boolean;
        credentials?: { password?: string };
        repeaterID?: string;
        wsProtocols?: string[];
      }
    );

    // Properties
    viewOnly: boolean;
    focusOnClick: boolean;
    clipViewport: boolean;
    dragViewport: boolean;
    scaleViewport: boolean;
    resizeSession: boolean;
    showDotCursor: boolean;
    background: string;
    qualityLevel: number;
    compressionLevel: number;
    capabilities: {
      power: boolean;
    };

    // Methods
    disconnect(): void;
    sendCredentials(credentials: { password?: string; username?: string; target?: string }): void;
    sendKey(keysym: number, code: string | null, down?: boolean): void;
    sendCtrlAltDel(): void;
    focus(): void;
    blur(): void;
    machineShutdown(): void;
    machineReboot(): void;
    machineReset(): void;
    clipboardPasteFrom(text: string): void;

    // Events
    addEventListener(type: 'connect', listener: () => void): void;
    addEventListener(type: 'disconnect', listener: (e: { detail: { clean: boolean } }) => void): void;
    addEventListener(type: 'credentialsrequired', listener: () => void): void;
    addEventListener(type: 'securityfailure', listener: (e: { detail: { status: number; reason: string } }) => void): void;
    addEventListener(type: 'clipboard', listener: (e: { detail: { text: string } }) => void): void;
    addEventListener(type: 'bell', listener: () => void): void;
    addEventListener(type: 'desktopname', listener: (e: { detail: { name: string } }) => void): void;
    addEventListener(type: 'capabilities', listener: (e: { detail: { capabilities: object } }) => void): void;
  }
}
