export interface Session {
  id: string;
  mode: 'ephemeral' | 'persistent';
  status: string;
  workerId: string;
  createdAt: string;
  lastActivity: string;
  expiresAt: string;
  vncEnabled: boolean;
  vncPort?: number;
  metadata: {
    workflowId?: string;
    executionId?: string;
    currentUrl?: string;
  };
}

export interface Worker {
  id: string;
  url: string;
  status: 'healthy' | 'degraded' | 'unhealthy' | 'offline';
  capacity: {
    max: number;
    active: number;
    available: number;
  };
  lastHealthCheck: string;
}

export interface PoolStatus {
  totalCapacity: number;
  activeSession: number;
  availableSlots: number;
  queuedRequests: number;
  warmPoolSize: number;
  warmPoolTarget: number;
  workers: Array<{
    id: string;
    status: string;
    active: number;
    max: number;
  }>;
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  uptime: number;
  workers: {
    total: number;
    healthy: number;
  };
  sessions: {
    active: number;
    queued: number;
  };
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}
