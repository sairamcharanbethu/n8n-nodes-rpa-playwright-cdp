import { useEffect, useRef, useState, useCallback } from 'react';

interface VNCViewerProps {
  sessionId: string;
  vncHost?: string;
  vncPort?: number;
  onClose: () => void;
}

export function VNCViewer({ sessionId, vncHost, vncPort, onClose }: VNCViewerProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const rfbRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('connecting');
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'fit' | 'full' | 'native'>('fit');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [quality, setQuality] = useState<'high' | 'medium' | 'low'>('high');
  const [clipToWindow, setClipToWindow] = useState(true);
  const [showKeyboard, setShowKeyboard] = useState(false);
  const [resolution, setResolution] = useState({ width: 0, height: 0 });

  const updateScaling = useCallback(() => {
    if (!rfbRef.current) return;
    
    switch (viewMode) {
      case 'fit':
        rfbRef.current.scaleViewport = true;
        rfbRef.current.clipViewport = false;
        break;
      case 'full':
        rfbRef.current.scaleViewport = true;
        rfbRef.current.clipViewport = true;
        break;
      case 'native':
        rfbRef.current.scaleViewport = false;
        rfbRef.current.clipViewport = false;
        break;
    }
  }, [viewMode]);

  useEffect(() => {
    let rfb: any = null;

    const connect = async () => {
      try {
        // Dynamic import of noVNC
        const { default: RFB } = await import('@novnc/novnc/lib/rfb.js');

        if (!canvasRef.current) return;

        // Connect through websockify proxy to worker's VNC
        const wsUrl = `ws://${window.location.hostname}:6080`;

        rfb = new RFB(canvasRef.current, wsUrl, {
          credentials: { password: '' },
          wsProtocols: ['binary'],
        });

        // Initial settings
        rfb.scaleViewport = viewMode === 'fit' || viewMode === 'full';
        rfb.clipViewport = viewMode === 'full';
        rfb.resizeSession = false;
        rfb.showDotCursor = true;
        rfb.background = '#1a1a2e';
        rfb.qualityLevel = quality === 'high' ? 9 : quality === 'medium' ? 6 : 3;
        rfb.compressionLevel = quality === 'high' ? 2 : quality === 'medium' ? 5 : 9;

        rfb.addEventListener('connect', () => {
          setStatus('connected');
          setError(null);
          // Get remote desktop size
          if (rfb._fbWidth && rfb._fbHeight) {
            setResolution({ width: rfb._fbWidth, height: rfb._fbHeight });
          }
        });

        rfb.addEventListener('disconnect', (e: any) => {
          setStatus('disconnected');
          if (e.detail.clean) {
            setError('Connection closed cleanly');
          } else {
            setError('Connection lost unexpectedly');
          }
        });

        rfb.addEventListener('securityfailure', (e: any) => {
          setStatus('error');
          setError(`Security error: ${e.detail.reason}`);
        });

        rfb.addEventListener('desktopname', (e: any) => {
          console.log('Desktop name:', e.detail.name);
        });

        rfbRef.current = rfb;
      } catch (err: any) {
        console.error('Failed to connect via noVNC:', err);
        setStatus('error');
        setError(`Connection failed: ${err.message}`);
      }
    };

    connect();

    return () => {
      if (rfbRef.current) {
        rfbRef.current.disconnect();
        rfbRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    updateScaling();
  }, [viewMode, updateScaling]);

  useEffect(() => {
    if (rfbRef.current) {
      rfbRef.current.qualityLevel = quality === 'high' ? 9 : quality === 'medium' ? 6 : 3;
      rfbRef.current.compressionLevel = quality === 'high' ? 2 : quality === 'medium' ? 5 : 9;
    }
  }, [quality]);

  const handleFullscreen = () => {
    if (!containerRef.current) return;

    if (!isFullscreen) {
      containerRef.current.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleKeyboardFocus = () => {
    if (rfbRef.current) {
      rfbRef.current.focus();
      setShowKeyboard(true);
    }
  };

  const handleCtrlAltDel = () => {
    if (rfbRef.current) {
      rfbRef.current.sendCtrlAltDel();
    }
  };

  const handleReconnect = () => {
    if (rfbRef.current) {
      rfbRef.current.disconnect();
    }
    setStatus('connecting');
    setError(null);
    // Trigger reconnect by remounting
    window.location.reload();
  };

  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (rfbRef.current) {
      rfbRef.current.disconnect();
    }
    onClose();
  };

  return (
    <div className="vnc-modal" onClick={handleClose}>
      <div 
        ref={containerRef}
        className={`vnc-container ${isFullscreen ? 'fullscreen' : ''}`} 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="vnc-header">
          <div className="vnc-title">
            <span className={`vnc-status-dot ${status}`}></span>
            <span>Live View - Session {sessionId.substring(0, 8)}...</span>
            <span className="vnc-status-text">
              ({status}{resolution.width > 0 ? ` - ${resolution.width}x${resolution.height}` : ''})
            </span>
          </div>
          <div className="vnc-controls">
            {/* View Mode */}
            <select 
              className="vnc-select"
              value={viewMode}
              onChange={(e) => setViewMode(e.target.value as any)}
              title="View mode"
            >
              <option value="fit">Fit to Window</option>
              <option value="full">Fill Window</option>
              <option value="native">Native Size (1:1)</option>
            </select>

            {/* Quality */}
            <select 
              className="vnc-select"
              value={quality}
              onChange={(e) => setQuality(e.target.value as any)}
              title="Image quality"
            >
              <option value="high">High Quality</option>
              <option value="medium">Medium</option>
              <option value="low">Low (Fast)</option>
            </select>

            <button
              className="btn btn-secondary btn-small"
              onClick={handleKeyboardFocus}
              title="Click to send keyboard input to remote"
            >
              Keyboard
            </button>
            <button
              className="btn btn-secondary btn-small"
              onClick={handleCtrlAltDel}
              title="Send Ctrl+Alt+Del"
            >
              Ctrl+Alt+Del
            </button>
            <button
              className="btn btn-secondary btn-small"
              onClick={handleFullscreen}
              title={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
            >
              {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            </button>
            <button className="btn btn-danger btn-small" onClick={handleClose}>
              Close
            </button>
          </div>
        </div>

        {error && (
          <div className="vnc-error">
            <span>{error}</span>
            <button className="btn btn-primary btn-small" onClick={handleReconnect}>
              Reconnect
            </button>
          </div>
        )}

        {status === 'connecting' && (
          <div className="vnc-loading">
            <div className="spinner"></div>
            <span>Connecting to browser display...</span>
          </div>
        )}

        <div
          ref={canvasRef}
          className="vnc-canvas-container"
          tabIndex={0}
          onFocus={() => setShowKeyboard(true)}
          onBlur={() => setShowKeyboard(false)}
        />

        {showKeyboard && status === 'connected' && (
          <div className="vnc-keyboard-hint">
            Keyboard input active - press Escape to release
          </div>
        )}
      </div>
    </div>
  );
}
