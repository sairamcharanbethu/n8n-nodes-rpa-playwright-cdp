import { INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType } from 'n8n-workflow';
import { closeSession, cleanupAllSessions } from '../../utils/sessionManager';
import { closeSession as closeOrchestratorSession, closeAllSessions as closeAllOrchestratorSessions } from '../../utils/orchestratorClient';
import { SessionObject } from '../../utils/SessionObject';
import { chromium } from 'playwright';

/**
 * Close an orchestrator session
 */
async function handleCloseOrchestratorSession(
  session: SessionObject,
  force: boolean
): Promise<INodeExecutionData> {
  try {
    if (!session.orchestratorUrl || !session.sessionId) {
      return {
        json: {
          ...session,
          success: false,
          error: 'Missing orchestratorUrl or sessionId in session data',
          step: 'close',
          timestamp: new Date().toISOString(),
        },
      };
    }

    // Close via orchestrator API (the orchestrator will handle browser cleanup)
    await closeOrchestratorSession(session.orchestratorUrl, session.sessionId, force);

    return {
      json: {
        ...session,
        success: true,
        step: 'close',
        message: 'Session closed successfully via Orchestrator',
        timestamp: new Date().toISOString(),
      },
    };
  } catch (error: any) {
    return {
      json: {
        ...session,
        success: false,
        error: error.message || 'Failed to close session',
        step: 'close',
        timestamp: new Date().toISOString(),
      },
    };
  }
}

/**
 * Close a legacy Selenium session
 */
async function handleCloseSeleniumSession(
  session: SessionObject,
  force: boolean
): Promise<INodeExecutionData> {
  try {
    // Close via Selenium API
    const closedSession = await closeSession(session);

    return {
      json: {
        ...closedSession as unknown as { [key: string]: any },
      },
    };
  } catch (error: any) {
    return {
      json: {
        ...session,
        success: false,
        error: error.message || 'Failed to close session',
        step: 'close',
        timestamp: new Date().toISOString(),
      },
    };
  }
}

export class CloseBrowser implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Close Browser',
    name: 'closeBrowser',
    icon: 'fa:window-close',
    group: ['transform'],
    version: 1,
    description: 'Closes the browser/session created by Launch Browser',
    defaults: {
      name: 'Close Browser',
    },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'Close All Sessions',
        name: 'closeAllSessions',
        type: 'boolean',
        default: false,
        description: 'Close ALL active sessions (useful for cleanup). Uses session data to determine backend.',
      },
      {
        displayName: 'Force Close',
        name: 'forceClose',
        type: 'boolean',
        default: false,
        description: 'Force close even if browser is unresponsive',
      },
      // Legacy Selenium settings (only shown when closing all and no orchestrator URL in session)
      {
        displayName: 'Selenium Hub URL',
        name: 'seleniumHubUrl',
        type: 'string',
        default: 'http://selenium-hub:4444',
        description: 'Selenium Hub URL (only used for legacy "Close All" when session has no orchestratorUrl)',
        displayOptions: {
          show: {
            closeAllSessions: [true],
          },
        },
      },
      {
        displayName: 'Orchestrator URL',
        name: 'orchestratorUrl',
        type: 'string',
        default: 'http://orchestrator:3000',
        description: 'Orchestrator URL (only used for "Close All" when session has no orchestratorUrl)',
        displayOptions: {
          show: {
            closeAllSessions: [true],
          },
        },
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session: SessionObject = items[i].json as unknown as SessionObject;
      const closeAllSessionsFlag = this.getNodeParameter('closeAllSessions', i, false) as boolean;
      const forceClose = this.getNodeParameter('forceClose', i, false) as boolean;

      // Determine if this is an orchestrator session
      const isOrchestratorSession = !!session.orchestratorUrl;

      // Handle "Close All Sessions" mode
      if (closeAllSessionsFlag) {
        try {
          let cleanupResult: { closed: number; failed: number };

          if (isOrchestratorSession || session.orchestratorUrl) {
            // Close all orchestrator sessions
            const orchestratorUrl = session.orchestratorUrl ||
              this.getNodeParameter('orchestratorUrl', i, 'http://orchestrator:3000') as string;
            cleanupResult = await closeAllOrchestratorSessions(orchestratorUrl);
          } else {
            // Close all Selenium sessions (legacy)
            const seleniumHubUrl = session.seleniumHubUrl ||
              this.getNodeParameter('seleniumHubUrl', i, 'http://selenium-hub:4444') as string;
            cleanupResult = await cleanupAllSessions(seleniumHubUrl);
          }

          results.push({
            json: {
              success: true,
              step: 'cleanup',
              message: `Closed ${cleanupResult.closed} sessions (${cleanupResult.failed} failed)`,
              ...cleanupResult,
              timestamp: new Date().toISOString(),
            },
          });
        } catch (error: any) {
          results.push({
            json: {
              success: false,
              error: error.message || 'Failed to cleanup sessions',
              step: 'cleanup',
              timestamp: new Date().toISOString(),
            },
          });
        }
        continue;
      }

      // Close single session
      if (isOrchestratorSession) {
        // Orchestrator mode
        results.push(await handleCloseOrchestratorSession(session, forceClose));
      } else {
        // Legacy Selenium mode
        results.push(await handleCloseSeleniumSession(session, forceClose));
      }
    }
    return [results];
  }
}
