import { INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType } from 'n8n-workflow';
import { launchGoogleSession } from '../../utils/sessionManager';
import { createSession as createOrchestratorSession } from '../../utils/orchestratorClient';
import { SessionObject } from '../../utils/SessionObject';
import { chromium } from 'playwright';

/**
 * Launch browser using the Playwright Browser Orchestrator
 */
async function launchWithOrchestrator(
  executeFunctions: IExecuteFunctions,
  navigateUrl: string
): Promise<SessionObject> {
  const orchestratorUrl = executeFunctions.getNodeParameter('orchestratorUrl', 0) as string;
  const sessionMode = executeFunctions.getNodeParameter('sessionMode', 0) as 'ephemeral' | 'persistent';
  const profileId = executeFunctions.getNodeParameter('profileId', 0, '') as string;
  const sessionTimeout = executeFunctions.getNodeParameter('sessionTimeout', 0, 300) as number;

  try {
    // Validate persistent mode requires profileId
    if (sessionMode === 'persistent' && !profileId) {
      return {
        success: false,
        error: 'Profile ID is required for persistent sessions',
        step: 'launch',
        timestamp: new Date().toISOString(),
        sessionId: '',
        cdpUrl: '',
      };
    }

    // Create session via orchestrator
    const orchestratorSession = await createOrchestratorSession(orchestratorUrl, {
      mode: sessionMode,
      profileId: sessionMode === 'persistent' ? profileId : undefined,
      workflowId: executeFunctions.getWorkflow().id,
      executionId: executeFunctions.getExecutionId(),
      timeout: sessionTimeout,
    });

    // Small delay to ensure browser is fully ready
    await new Promise(resolve => setTimeout(resolve, 500));

    // Connect to browser via CDP
    const browser = await chromium.connectOverCDP(orchestratorSession.cdpUrl, {
      timeout: 30000,
    });

    // Use the default browser context (shared across all CDP connections)
    // This ensures all n8n nodes interact with the same context/page
    // HTTPS errors are handled by Chrome's --ignore-certificate-errors flag
    const context = browser.contexts()[0];

    // Get or create page - reuse existing page (even chrome://) to avoid multiple tabs
    let page = context.pages()[0];
    if (!page) {
      page = await context.newPage();
    }

    // Apply comprehensive stealth settings BEFORE navigation
    await page.addInitScript(`
      // Hide webdriver property
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
        configurable: true,
      });

      // Make navigator.webdriver non-existent
      delete Object.getPrototypeOf(navigator).webdriver;

      // Override plugins to look more realistic
      Object.defineProperty(navigator, 'plugins', {
        get: () => {
          const plugins = [
            { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format', length: 1 },
            { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '', length: 1 },
            { name: 'Native Client', filename: 'internal-nacl-plugin', description: '', length: 2 },
          ];
          plugins.item = (i) => plugins[i] || null;
          plugins.namedItem = (name) => plugins.find(p => p.name === name) || null;
          plugins.refresh = () => {};
          return plugins;
        },
        configurable: true,
      });

      // Override mimeTypes
      Object.defineProperty(navigator, 'mimeTypes', {
        get: () => {
          const mimeTypes = [
            { type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format' },
            { type: 'application/x-google-chrome-pdf', suffixes: 'pdf', description: 'Portable Document Format' },
          ];
          mimeTypes.item = (i) => mimeTypes[i] || null;
          mimeTypes.namedItem = (name) => mimeTypes.find(m => m.type === name) || null;
          return mimeTypes;
        },
        configurable: true,
      });

      // Override languages
      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
        configurable: true,
      });

      // Override platform (if needed)
      Object.defineProperty(navigator, 'platform', {
        get: () => 'Win32',
        configurable: true,
      });

      // Hardware concurrency (realistic value)
      Object.defineProperty(navigator, 'hardwareConcurrency', {
        get: () => 8,
        configurable: true,
      });

      // Device memory
      Object.defineProperty(navigator, 'deviceMemory', {
        get: () => 8,
        configurable: true,
      });

      // Override chrome property to look like real Chrome
      window.chrome = {
        app: {
          isInstalled: false,
          InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' },
          RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' },
        },
        runtime: {
          OnInstalledReason: { CHROME_UPDATE: 'chrome_update', INSTALL: 'install', SHARED_MODULE_UPDATE: 'shared_module_update', UPDATE: 'update' },
          OnRestartRequiredReason: { APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic' },
          PlatformArch: { ARM: 'arm', ARM64: 'arm64', MIPS: 'mips', MIPS64: 'mips64', X86_32: 'x86-32', X86_64: 'x86-64' },
          PlatformNaclArch: { ARM: 'arm', MIPS: 'mips', MIPS64: 'mips64', X86_32: 'x86-32', X86_64: 'x86-64' },
          PlatformOs: { ANDROID: 'android', CROS: 'cros', LINUX: 'linux', MAC: 'mac', OPENBSD: 'openbsd', WIN: 'win' },
          RequestUpdateCheckStatus: { NO_UPDATE: 'no_update', THROTTLED: 'throttled', UPDATE_AVAILABLE: 'update_available' },
        },
        csi: function() { return {}; },
        loadTimes: function() { return {}; },
      };

      // Hide automation indicators
      delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
      delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
      delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
      delete window.cdc_adoQpoasnfa76pfcZLmcfl_Object;
      delete window.cdc_adoQpoasnfa76pfcZLmcfl_Proxy;

      // Override permissions API
      const originalQuery = window.navigator.permissions.query;
      window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' ?
          Promise.resolve({ state: Notification.permission }) :
          originalQuery(parameters)
      );

      // Fix iframe contentWindow
      const originalContentWindowGetter = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow').get;
      Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
        get: function() {
          const result = originalContentWindowGetter.call(this);
          if (result) {
            try {
              // Proxy detection check
              if (result.chrome === undefined) {
                result.chrome = window.chrome;
              }
            } catch (e) {}
          }
          return result;
        }
      });

      // Mask WebGL vendor/renderer
      const getParameterProto = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) return 'Intel Inc.'; // UNMASKED_VENDOR_WEBGL
        if (parameter === 37446) return 'Intel Iris OpenGL Engine'; // UNMASKED_RENDERER_WEBGL
        return getParameterProto.apply(this, arguments);
      };
    `);

    // Set viewport to full screen (matches virtual display 1920x1080)
    await page.setViewportSize({ width: 1920, height: 1080 });

    // Navigate to initial URL
    await page.goto(navigateUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 30000,
    });

    const title = await page.title();
    const currentUrl = page.url();

    // Disconnect from browser (do NOT call browser.close() - that closes the browser!)
    // The browser stays alive on the worker for subsequent nodes to use
    // Note: Just let the connection go out of scope - no explicit disconnect needed

    return {
      success: true,
      sessionId: orchestratorSession.sessionId,
      cdpUrl: orchestratorSession.cdpUrl,
      orchestratorUrl,
      mode: sessionMode,
      profileId: sessionMode === 'persistent' ? profileId : undefined,
      workerId: orchestratorSession.workerId,
      expiresAt: orchestratorSession.expiresAt,
      pageTitle: title,
      currentUrl,
      step: 'launch',
      message: `Browser session launched successfully via Orchestrator (${sessionMode} mode)`,
      timestamp: new Date().toISOString(),
      vncEnabled: false,
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || String(error),
      step: 'launch',
      timestamp: new Date().toISOString(),
      sessionId: '',
      cdpUrl: '',
      orchestratorUrl,
    };
  }
}

/**
 * Launch browser using legacy Selenium Grid mode
 */
async function launchWithSelenium(
  executeFunctions: IExecuteFunctions,
  navigateUrl: string
): Promise<SessionObject> {
  const seleniumHubUrl = executeFunctions.getNodeParameter('seleniumHubUrl', 0) as string;
  const profileDir = executeFunctions.getNodeParameter('profileDir', 0) as string;
  const ignoreCertificateErrors = executeFunctions.getNodeParameter('ignoreCertificateErrors', 0) as boolean;
  const browserArgsRaw = executeFunctions.getNodeParameter('browserArgs', 0, '') as string;
  const windowSize = executeFunctions.getNodeParameter('windowSize', 0, '1920,1080') as string;
  const uniqueSession = executeFunctions.getNodeParameter('uniqueSession', 0) as boolean;

  const browserArgs = browserArgsRaw
    .split(',')
    .map((arg) => arg.trim())
    .filter((arg) => !!arg);

  return launchGoogleSession({
    seleniumHubUrl,
    profileDir,
    navigateUrl,
    ignoreCertificateErrors,
    browserArgs,
    windowSize,
    uniqueSession,
  });
}

export class LaunchBrowser implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Launch Browser',
    name: 'launchBrowser',
    icon: 'fa:chrome',
    group: ['transform'],
    version: 1,
    description: 'Launches a Playwright Chrome session via Orchestrator or Selenium Grid',
    defaults: {
      name: 'Launch Browser',
    },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'Backend',
        name: 'backend',
        type: 'options',
        options: [
          {
            name: 'Orchestrator (Recommended)',
            value: 'orchestrator',
            description: 'Use the Playwright Browser Orchestrator service',
          },
          {
            name: 'Selenium Grid (Legacy)',
            value: 'selenium',
            description: 'Use Selenium Grid with CDP (legacy mode)',
          },
        ],
        default: 'orchestrator',
        description: 'Which backend to use for browser management',
      },
      // Orchestrator settings
      {
        displayName: 'Orchestrator URL',
        name: 'orchestratorUrl',
        type: 'string',
        default: 'http://orchestrator:3000',
        required: true,
        displayOptions: {
          show: {
            backend: ['orchestrator'],
          },
        },
        description: 'URL of the Playwright Browser Orchestrator service',
      },
      {
        displayName: 'Session Mode',
        name: 'sessionMode',
        type: 'options',
        options: [
          {
            name: 'Ephemeral (Clean Browser)',
            value: 'ephemeral',
            description: 'Fresh browser session, no persistent data',
          },
          {
            name: 'Persistent (Logged-in Profile)',
            value: 'persistent',
            description: 'Reuse a browser profile with saved login state',
          },
        ],
        default: 'ephemeral',
        displayOptions: {
          show: {
            backend: ['orchestrator'],
          },
        },
        description: 'Session mode - ephemeral for clean sessions, persistent for logged-in profiles',
      },
      {
        displayName: 'Profile ID',
        name: 'profileId',
        type: 'string',
        default: '',
        displayOptions: {
          show: {
            backend: ['orchestrator'],
            sessionMode: ['persistent'],
          },
        },
        description: 'Unique profile ID for persistent sessions (e.g., "salesforce-login")',
        placeholder: 'e.g., salesforce-login',
      },
      {
        displayName: 'Session Timeout (seconds)',
        name: 'sessionTimeout',
        type: 'number',
        default: 300,
        displayOptions: {
          show: {
            backend: ['orchestrator'],
          },
        },
        description: 'Session timeout in seconds (default: 300 = 5 minutes)',
      },
      // Legacy Selenium settings
      {
        displayName: 'Selenium Hub URL',
        name: 'seleniumHubUrl',
        type: 'string',
        default: 'http://selenium-hub:4444',
        required: true,
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
      },
      {
        displayName: 'Profile Directory',
        name: 'profileDir',
        type: 'string',
        default: '/home/seluser/chrome-profiles/n8n-demo',
        required: true,
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
      },
      {
        displayName: 'Unique Session',
        name: 'uniqueSession',
        type: 'boolean',
        default: true,
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
        description: 'Generate unique profile directory for each session (legacy mode)',
      },
      // Common settings
      {
        displayName: 'Navigate To URL',
        name: 'navigateUrl',
        type: 'string',
        default: 'https://google.com',
        required: true,
        description: 'Initial URL to navigate to after browser launch',
      },
      {
        displayName: 'Ignore Certificate Errors',
        name: 'ignoreCertificateErrors',
        type: 'boolean',
        default: true,
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
        description: 'Whether to ignore SSL certificate errors (Selenium mode only)',
      },
      {
        displayName: 'Additional Browser Args',
        name: 'browserArgs',
        type: 'string',
        default: '',
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
        description: 'Comma-separated extra Chrome arguments (Selenium mode only)',
      },
      {
        displayName: 'Window Size',
        name: 'windowSize',
        type: 'string',
        default: '1920,1080',
        displayOptions: {
          show: {
            backend: ['selenium'],
          },
        },
        description: 'Resolution for the Chrome window (Selenium mode only)',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const backend = this.getNodeParameter('backend', 0) as string;
    const navigateUrl = this.getNodeParameter('navigateUrl', 0) as string;

    let session: SessionObject;

    if (backend === 'orchestrator') {
      // New Orchestrator mode
      session = await launchWithOrchestrator(this, navigateUrl);
    } else {
      // Legacy Selenium mode
      session = await launchWithSelenium(this, navigateUrl);
    }

    return [[{ json: { ...session } }]];
  }
}
