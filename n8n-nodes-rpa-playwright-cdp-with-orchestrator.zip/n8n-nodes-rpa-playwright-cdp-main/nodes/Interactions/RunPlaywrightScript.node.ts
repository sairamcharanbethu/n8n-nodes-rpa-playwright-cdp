import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page, BrowserContext } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';

/**
 * Run Playwright Script Node
 * Execute custom Playwright code for complex automation scenarios
 */
export class RunPlaywrightScript implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Run Playwright Script',
    name: 'runPlaywrightScript',
    icon: 'fa:code',
    group: ['transform'],
    version: 1,
    description: 'Execute custom Playwright script for bulk actions and complex automation. Write JavaScript code with access to page, browser, and context objects.',
    defaults: { name: 'Run Playwright Script' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser',
      },
      {
        displayName: 'Script',
        name: 'script',
        type: 'string',
        typeOptions: {
          rows: 25,
        },
        default: `// Available variables:
// - page: Playwright Page object (current page)
// - browser: Playwright Browser object
// - context: Playwright BrowserContext object
// - session: Session data from previous nodes
// - console: Logs available in output
// - sleep(ms): Helper to wait

// Example: Fill a form and click submit
// await page.fill('#username', 'myuser');
// await page.fill('#password', 'mypass');
// await page.click('button[type="submit"]');

// Example: Loop through items
// const items = ['item1', 'item2', 'item3'];
// for (const item of items) {
//   await page.fill('#search', item);
//   await page.click('#search-btn');
//   await sleep(1000);
// }

// Example: Extract data
// const rows = await page.$$('table tr');
// const data = [];
// for (const row of rows) {
//   const text = await row.textContent();
//   data.push(text);
// }
// return { extractedData: data };

// Your code here:
const title = await page.title();
const url = page.url();

return {
  title,
  url,
  message: 'Script executed successfully'
};
`,
        required: true,
        description: 'Playwright JavaScript code to execute. Use "return { ... }" to pass data to next node.',
      },
      {
        displayName: 'Timeout (seconds)',
        name: 'timeout',
        type: 'number',
        default: 60,
        description: 'Maximum time allowed for script execution',
      },
      {
        displayName: 'Continue On Error',
        name: 'continueOnError',
        type: 'boolean',
        default: false,
        description: 'If true, workflow continues even if script throws an error',
      },
      {
        displayName: 'Capture Screenshots',
        name: 'captureScreenshots',
        type: 'boolean',
        default: false,
        description: 'Capture screenshot before and after script execution',
      },
      {
        displayName: 'Log Actions',
        name: 'logActions',
        type: 'boolean',
        default: true,
        description: 'Log each action for debugging',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const script = this.getNodeParameter('script', i) as string;
      const timeout = this.getNodeParameter('timeout', i, 60) as number;
      const continueOnError = this.getNodeParameter('continueOnError', i, false) as boolean;
      const captureScreenshots = this.getNodeParameter('captureScreenshots', i, false) as boolean;
      const logActions = this.getNodeParameter('logActions', i, true) as boolean;

      const scriptResult: Record<string, unknown> = {
        startTime: new Date().toISOString(),
        logs: [] as string[],
      };

      let browser: Browser | null = null;

      const log = (message: string) => {
        if (logActions) {
          const timestamp = new Date().toISOString();
          (scriptResult.logs as string[]).push(`[${timestamp}] ${message}`);
        }
      };

      try {
        log('Connecting to browser...');
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || (await context.newPage());
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
        log(`Connected to page: ${page.url()}`);

        const context = page.context();

        // Capture screenshot before
        let screenshotBefore: string | undefined;
        if (captureScreenshots) {
          log('Capturing screenshot before script...');
          const buffer = await page.screenshot({ type: 'png' });
          screenshotBefore = buffer.toString('base64');
          scriptResult.screenshotBefore = screenshotBefore;
        }

        // Helper function for sleeping
        const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

        // Custom console for logging
        const customConsole = {
          log: (...args: any[]) => log(`console.log: ${args.map(a => JSON.stringify(a)).join(' ')}`),
          info: (...args: any[]) => log(`console.info: ${args.map(a => JSON.stringify(a)).join(' ')}`),
          warn: (...args: any[]) => log(`console.warn: ${args.map(a => JSON.stringify(a)).join(' ')}`),
          error: (...args: any[]) => log(`console.error: ${args.map(a => JSON.stringify(a)).join(' ')}`),
        };

        // Execute the script with timeout
        log('Executing script...');
        const startTime = Date.now();

        // Wrap the script in an async function
        const wrappedScript = `
          return (async () => {
            ${script}
          })();
        `;

        // Create the function with available variables
        const scriptFunction = new Function(
          'page',
          'browser',
          'context',
          'session',
          'console',
          'sleep',
          wrappedScript
        );

        // Execute with timeout
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error(`Script timeout after ${timeout} seconds`)), timeout * 1000);
        });

        const scriptPromise = scriptFunction(
          page,
          browser,
          context,
          session,
          customConsole,
          sleep
        );

        const returnValue = await Promise.race([scriptPromise, timeoutPromise]);

        const executionTime = Date.now() - startTime;
        log(`Script completed in ${executionTime}ms`);

        // Capture screenshot after
        if (captureScreenshots) {
          log('Capturing screenshot after script...');
          try {
            const buffer = await page.screenshot({ type: 'png' });
            scriptResult.screenshotAfter = buffer.toString('base64');
          } catch (e) {
            log(`Failed to capture screenshot after: ${(e as Error).message}`);
          }
        }

        // Get final page state
        scriptResult.currentUrl = page.url();
        scriptResult.pageTitle = await page.title().catch(() => '');
        scriptResult.result = 'success';
        scriptResult.executionTimeMs = executionTime;
        scriptResult.endTime = new Date().toISOString();

        // Merge return value if it's an object
        if (returnValue && typeof returnValue === 'object') {
          scriptResult.returnValue = returnValue;
        } else if (returnValue !== undefined) {
          scriptResult.returnValue = returnValue;
        }

        await browser.close();

      } catch (error: any) {
        scriptResult.result = 'error';
        scriptResult.error = error.message;
        scriptResult.errorStack = error.stack;
        scriptResult.endTime = new Date().toISOString();
        log(`Error: ${error.message}`);

        if (browser) {
          await browser.close().catch(() => {});
        }

        if (!continueOnError) {
          // Still return the result with error info
          results.push({ json: { ...session, playwrightScript: scriptResult } });
          return [results];
        }
      }

      results.push({ json: { ...session, playwrightScript: scriptResult } });
    }

    return [results];
  }
}
