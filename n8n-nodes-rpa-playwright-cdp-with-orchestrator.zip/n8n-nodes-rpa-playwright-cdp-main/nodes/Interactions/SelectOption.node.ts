import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties, findElementInFrames } from '../../utils/frameUtils';

export class SelectOption implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Select Option',
    name: 'selectOption',
    icon: 'fa:check-square-o',
    group: ['transform'],
    version: 1,
    description: 'Selects an option from a dropdown. Supports auto-detection of elements inside iframes.',
    defaults: { name: 'Select Option' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser',
      },
      ...frameHandlingProperties,
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'E.g. select#country, select[name="state"]',
        description: 'CSS selector for the select/dropdown element',
      },
      {
        displayName: 'Selection Method',
        name: 'selectionMethod',
        type: 'options',
        options: [
          { name: 'By Value', value: 'value' },
          { name: 'By Text', value: 'text' },
          { name: 'By Index', value: 'index' },
        ],
        default: 'value',
        description: 'How to select the option',
      },
      {
        displayName: 'Option Value/Text/Index',
        name: 'optionValue',
        type: 'string',
        default: '',
        required: true,
        description: 'The value, text, or index of the option to select',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        description: 'Maximum time to wait for selector to appear',
      },
      {
        displayName: 'Wait After Selection (ms)',
        name: 'waitAfter',
        type: 'number',
        default: 0,
        description: 'Wait time after selecting the option',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const selectionMethod = this.getNodeParameter('selectionMethod', i, 'value') as string;
      const optionValue = this.getNodeParameter('optionValue', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;
      const waitAfter = this.getNodeParameter('waitAfter', i, 0) as number;

      let selectResult: any = {};
      let browser: Browser | null = null;

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || (await context.newPage());
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        selectResult.currentUrl = await page.url();
        selectResult.selector = selector;
        selectResult.selectionMethod = selectionMethod;
        selectResult.requestedValue = optionValue;

        // Find element (with auto-frame detection)
        const { element: el, frame, frameInfo } = await findElementInFrames(page, selector, {
          frameHandling,
          iframeSelectorStrategy,
          iframeSelector,
          waitTimeout,
          waitState: 'visible',
        });

        // Element is guaranteed non-null by findElementInFrames
        const selectElement = el!;

        // Add frame info to result
        Object.assign(selectResult, frameInfo);

        // Verify it's a select element
        const tagName = await selectElement.evaluate((el: any) => el.tagName.toLowerCase());
        if (tagName !== 'select') {
          throw new Error(`Element is not a select element. Found: ${tagName}`);
        }

        // Get value before selection
        selectResult.valueBefore = await selectElement.evaluate((select: any) => select.value);
        selectResult.textBefore = await selectElement.evaluate((select: any) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        // Perform selection based on method
        if (selectionMethod === 'value') {
          await selectElement.selectOption({ value: optionValue });
        } else if (selectionMethod === 'text') {
          await selectElement.selectOption({ label: optionValue });
        } else if (selectionMethod === 'index') {
          const index = parseInt(optionValue, 10);
          if (isNaN(index)) {
            throw new Error(`Invalid index: ${optionValue}. Must be a number.`);
          }
          await selectElement.selectOption({ index });
        }

        // Get value after selection
        selectResult.valueAfter = await selectElement.evaluate((select: any) => select.value);
        selectResult.textAfter = await selectElement.evaluate((select: any) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        selectResult.selectionChanged = selectResult.valueBefore !== selectResult.valueAfter;

        // Wait after selection if requested
        if (waitAfter > 0) {
          const pageContext = 'page' in frame ? (frame as any).page() : frame;
          await pageContext.waitForTimeout(waitAfter);
        }

        selectResult.result = 'success';
        selectResult.selectedValue = selectResult.valueAfter;
        selectResult.selectedText = selectResult.textAfter;

        await browser.close();

      } catch (e) {
        selectResult.result = 'error';
        selectResult.error = (e as Error).message;
        selectResult.selector = selector;
        selectResult.selectionMethod = selectionMethod;
        selectResult.requestedValue = optionValue;

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      results.push({ json: { ...session, selectAction: selectResult } });
    }

    return [results];
  }
}
