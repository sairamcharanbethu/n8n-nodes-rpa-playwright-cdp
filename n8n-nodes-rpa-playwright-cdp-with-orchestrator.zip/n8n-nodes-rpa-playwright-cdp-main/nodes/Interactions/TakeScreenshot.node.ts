import {
  INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { frameHandlingProperties, findElementInFrames, getPageFromFrame } from '../../utils/frameUtils';

export class TakeScreenshot implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Screenshot',
    name: 'screenshot',
    icon: 'fa:camera',
    group: ['utilities'],
    version: 1,
    description: 'Takes a screenshot of the full page or a specific element. Supports elements inside iframes.',
    defaults: { name: 'Screenshot' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      {
        displayName: 'Screenshot Type',
        name: 'screenshotType',
        type: 'options',
        options: [
          { name: 'Full Page', value: 'fullPage' },
          { name: 'Specific Element', value: 'element' },
        ],
        default: 'fullPage',
        description: 'Take screenshot of full page or specific element',
      },
      ...frameHandlingProperties.map(prop => ({
        ...prop,
        displayOptions: {
          show: {
            screenshotType: ['element'],
            ...(prop.displayOptions?.show || {}),
          },
        },
      })),
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: false,
        displayOptions: {
          show: {
            screenshotType: ['element'],
          },
        },
        description: 'CSS selector for the element to screenshot',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        displayOptions: {
          show: {
            screenshotType: ['element'],
          },
        },
      },
      {
        displayName: 'Image Format',
        name: 'format',
        type: 'options',
        options: [
          { name: 'PNG', value: 'png' },
          { name: 'JPEG', value: 'jpeg' },
        ],
        default: 'png',
      },
      {
        displayName: 'Quality (only for JPEG, 0-100)',
        name: 'quality',
        type: 'number',
        default: 80,
        required: false,
      },
      {
        displayName: 'Filename',
        name: 'filename',
        type: 'string',
        default: 'screenshot',
        description: 'Filename for the screenshot (without extension)',
        required: false,
      },
      {
        displayName: 'Save to File',
        name: 'saveToFile',
        type: 'boolean',
        default: true,
        description: 'Whether to save the screenshot to the file system',
      },
      {
        displayName: 'Save Path',
        name: 'savePath',
        type: 'string',
        default: '/data/screenshots',
        description: 'Directory path where screenshots will be saved',
        displayOptions: {
          show: {
            saveToFile: [true],
          },
        },
      }
    ]
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const screenshotType = this.getNodeParameter('screenshotType', i, 'fullPage') as string;
      const selector = this.getNodeParameter('selector', i, '') as string;
      const format = this.getNodeParameter('format', i, 'png') as 'png' | 'jpeg';
      const quality = this.getNodeParameter('quality', i, 80) as number;
      const filename = this.getNodeParameter('filename', i, 'screenshot') as string;
      const saveToFile = this.getNodeParameter('saveToFile', i, true) as boolean;
      const savePath = this.getNodeParameter('savePath', i, '/data/screenshots') as string;

      // Get iframe params only if screenshotType is element
      const frameHandling = screenshotType === 'element'
        ? this.getNodeParameter('frameHandling', i, 'auto') as string
        : 'main';
      const iframeSelectorStrategy = screenshotType === 'element'
        ? this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string
        : 'css';
      const iframeSelector = screenshotType === 'element'
        ? this.getNodeParameter('iframeSelector', i, '') as string
        : '';
      const waitTimeout = screenshotType === 'element'
        ? this.getNodeParameter('waitTimeout', i, 5000) as number
        : 5000;

      let buffer: Buffer | undefined;
      let browser: Browser | null = null;
      let screenshotResult: any = {};

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || await context.newPage();
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        if (screenshotType === 'element' && selector) {
          // Find element (with auto-frame detection)
          const { element, frameInfo } = await findElementInFrames(page, selector, {
            frameHandling,
            iframeSelectorStrategy,
            iframeSelector,
            waitTimeout,
            waitState: 'visible',
          });

          // Element is guaranteed non-null by findElementInFrames
          const el = element!;

          Object.assign(screenshotResult, frameInfo);
          buffer = await el.screenshot({ type: format, quality: format === 'jpeg' ? quality : undefined });
        } else {
          // Full page screenshot
          buffer = await page.screenshot({ fullPage: true, type: format, quality: format === 'jpeg' ? quality : undefined });
        }

        // Save to file system if requested
        let filePath = '';
        if (saveToFile && buffer) {
          try {
            mkdirSync(savePath, { recursive: true });
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const fullFilename = `${filename}-${timestamp}.${format}`;
            filePath = join(savePath, fullFilename);
            writeFileSync(filePath, buffer);
          } catch (fileError: any) {
            console.error('Failed to save screenshot to file:', fileError.message);
          }
        }

        screenshotResult = {
          ...screenshotResult,
          screenshotType,
          selector: selector || '(full page)',
          format,
          filename: `${filename}.${format}`,
          size: buffer?.length || 0,
          result: 'success',
          savedToFile: saveToFile,
          filePath: filePath || undefined
        };

        await browser.close();

        results.push({
          json: {
            ...session,
            screenshot: screenshotResult
          },
          binary: buffer ? {
            data: {
              data: buffer.toString('base64'),
              mimeType: format === 'png' ? 'image/png' : 'image/jpeg',
              fileName: `${filename}.${format}`,
              fileExtension: format,
            }
          } : undefined
        });

      } catch (e) {
        screenshotResult = { ...screenshotResult, selector, error: (e as Error).message, result: 'error' };
        if (browser) await browser.close().catch(() => {});

        results.push({
          json: {
            ...session,
            screenshot: screenshotResult
          }
        });
      }
    }
    return [results];
  }
}
