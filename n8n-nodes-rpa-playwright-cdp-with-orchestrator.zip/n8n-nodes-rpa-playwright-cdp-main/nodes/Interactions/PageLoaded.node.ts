import {
  INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';

export class PageLoaded implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Page Loaded',
    name: 'pageLoaded',
    icon: 'fa:check-circle',
    group: ['validation'],
    version: 1,
    description: 'Waits for the page to reach the specified ready state.',
    defaults: { name: 'Page Loaded' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      {
        displayName: 'Wait Strategy',
        name: 'waitUntil',
        type: 'options',
        options: [
          { name: 'Load', value: 'load' },
          { name: 'DOMContentLoaded', value: 'domcontentloaded' },
          { name: 'Network Idle', value: 'networkidle' },
        ],
        default: 'load',
      },
      {
        displayName: 'Timeout (ms)',
        name: 'timeout',
        type: 'number',
        default: 6000,
        description: 'Max time to wait'
      }
    ]
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];
    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
			const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const waitUntil = this.getNodeParameter('waitUntil', i, 'load') as 'load'|'domcontentloaded'|'networkidle';
      const timeout = this.getNodeParameter('timeout', i, 10000) as number;

      let browser: Browser | null = null, loaded = false, errorMsg = '';
      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          page = browser.contexts()[0].pages()[0] || await browser.contexts()[0].newPage();
        }

        await page.waitForLoadState(waitUntil, { timeout });
        loaded = true;
      } catch (e) {
        errorMsg = (e as Error).message;
        if (browser) await browser.close().catch(() => {});
      }
      results.push({
        json: {
          ...session,
          pageLoaded: { loaded, waitUntil, error: errorMsg }
        }
      });
    }
    return [results];
  }
}
