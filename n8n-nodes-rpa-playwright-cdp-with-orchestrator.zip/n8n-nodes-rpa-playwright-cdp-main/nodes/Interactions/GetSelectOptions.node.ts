import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties, findElementInFrames } from '../../utils/frameUtils';

export class GetSelectOptions implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Get Select Options',
    name: 'getSelectOptions',
    icon: 'fa:list-ul',
    group: ['transform'],
    version: 1,
    description: 'Gets all options from a dropdown. Supports auto-detection of elements inside iframes.',
    defaults: { name: 'Get Select Options' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser',
      },
      ...frameHandlingProperties,
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'E.g. select#country, select[name="state"]',
        description: 'CSS selector for the select/dropdown element',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        description: 'Maximum time to wait for selector to appear',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;

      let optionsResult: any = {};
      let browser: Browser | null = null;

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || (await context.newPage());
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        optionsResult.currentUrl = await page.url();
        optionsResult.selector = selector;

        // Find element (with auto-frame detection)
        const { element: el, frameInfo } = await findElementInFrames(page, selector, {
          frameHandling,
          iframeSelectorStrategy,
          iframeSelector,
          waitTimeout,
          waitState: 'visible',
        });

        // Element is guaranteed non-null by findElementInFrames
        const selectElement = el!;

        // Add frame info to result
        Object.assign(optionsResult, frameInfo);

        // Verify it's a select element
        const tagName = await selectElement.evaluate((el: any) => el.tagName.toLowerCase());
        if (tagName !== 'select') {
          throw new Error(`Element is not a select element. Found: ${tagName}`);
        }

        // Get all options
        const options = await selectElement.evaluate((select: any) => {
          return Array.from(select.options).map((option: any) => ({
            value: option.value,
            text: option.text,
            selected: option.selected,
            disabled: option.disabled,
          }));
        });

        // Get currently selected value
        const selectedValue = await selectElement.evaluate((select: any) => select.value);
        const selectedText = await selectElement.evaluate((select: any) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        optionsResult.result = 'success';
        optionsResult.options = options;
        optionsResult.optionCount = options.length;
        optionsResult.selectedValue = selectedValue;
        optionsResult.selectedText = selectedText;
        optionsResult.availableValues = options.map((opt: any) => opt.value);
        optionsResult.availableTexts = options.map((opt: any) => opt.text);

        await browser.close();

      } catch (e) {
        optionsResult.result = 'error';
        optionsResult.error = (e as Error).message;
        optionsResult.selector = selector;

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      results.push({ json: { ...session, selectOptions: optionsResult } });
    }

    return [results];
  }
}
