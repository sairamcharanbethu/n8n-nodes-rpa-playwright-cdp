import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
  IDataObject,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { promises as fs } from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties, findElementInFrames, getPageFromFrame } from '../../utils/frameUtils';

export class DownloadFile implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Download File',
    name: 'downloadFile',
    icon: 'fa:download',
    group: ['utilities'],
    version: 1,
    description: 'Triggers a file download by clicking an element. Supports auto-detection of elements inside iframes.',
    defaults: { name: 'Download File' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      ...frameHandlingProperties,
      {
        displayName: 'Trigger Selector',
        name: 'selector',
        type: 'string',
        required: true,
        default: '',
        placeholder: 'e.g. a.download-link, button.export',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
      },
      {
        displayName: 'Download Timeout (ms)',
        name: 'downloadTimeout',
        type: 'number',
        default: 30000,
      },
      {
        displayName: 'Delete File After',
        name: 'deleteAfter',
        type: 'boolean',
        default: true,
        description: 'Remove file from /tmp after binary ingest?',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];
    const downloadDir = '/tmp/n8n-downloads';
    await fs.mkdir(downloadDir, { recursive: true });

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;
      const downloadTimeout = this.getNodeParameter('downloadTimeout', i, 30000) as number;
      const deleteAfter = this.getNodeParameter('deleteAfter', i, true) as boolean;

      let downloadResult: IDataObject = {};
      let binaryData: Buffer | undefined;
      let binaryPropertyName = 'data';
      let browser: Browser | null = null;
      let filePath: string | undefined = '';

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || await context.newPage();
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        // Find element (with auto-frame detection)
        const { element, frame, frameInfo } = await findElementInFrames(page, selector, {
          frameHandling,
          iframeSelectorStrategy,
          iframeSelector,
          waitTimeout,
          waitState: 'visible',
        });

        // Element is guaranteed non-null by findElementInFrames
        const el = element!;

        // Add frame info to result
        Object.assign(downloadResult, frameInfo);

        // Prepare a unique file name
        const uuid = uuidv4();
        let filename = 'downloaded_file_' + uuid;
        let fileExtension = '';
        let suggestedFilename = '';
        let mimeType = '';
        let downloadUrl = '';

        // Get page context for download event
        const pageContext = getPageFromFrame(frame);

        // Listen for download and set path
        const [download] = await Promise.all([
          pageContext.waitForEvent('download', { timeout: downloadTimeout }),
          el.click()
        ]);

        suggestedFilename = download.suggestedFilename() || filename;
        fileExtension = (suggestedFilename.match(/\.([^.]+)$/)?.[1] || '').toLowerCase();
        filename = suggestedFilename || filename;
        downloadUrl = download.url();

        // Minimal mimeType guess
        const extMimeMap: { [ext: string]: string } = {
          pdf: 'application/pdf',
          xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          xls: 'application/vnd.ms-excel',
          csv: 'text/csv',
          txt: 'text/plain',
          zip: 'application/zip',
          png: 'image/png',
          jpg: 'image/jpeg',
          jpeg: 'image/jpeg',
          doc: 'application/msword',
          docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        };
        mimeType = extMimeMap[fileExtension] || 'application/octet-stream';

        filePath = path.join(downloadDir, `${uuid}-${filename}`);
        await download.saveAs(filePath);

        // Read as buffer and add to binary property
        binaryData = await fs.readFile(filePath);

        downloadResult = {
          ...downloadResult,
          selector,
          filePath: String(filePath),
          suggestedFilename: String(suggestedFilename),
          fileExtension: String(fileExtension),
          mimeType: String(mimeType),
          downloadUrl: String(downloadUrl),
          size: binaryData.length.toString(),
          result: 'success',
        };

        if (deleteAfter) {
          await fs.unlink(filePath);
          downloadResult.fileRemoved = 'true';
        }

        await browser.close();
      } catch (e) {
        downloadResult = {
          ...downloadResult,
          selector,
          error: (e as Error).message,
          result: 'error',
        };
        if (browser) await browser.close().catch(() => {});
      }

      const out: INodeExecutionData = {
        json: { ...session, downloadAction: downloadResult },
      };

      // Assign n8n binary property for use in later file/email/cloud nodes
      if (binaryData && downloadResult.mimeType && downloadResult.suggestedFilename) {
        out.binary = {
          [binaryPropertyName]: {
            data: binaryData.toString('base64'),
            mimeType: downloadResult.mimeType as string,
            fileName: downloadResult.suggestedFilename as string,
            fileExtension: downloadResult.fileExtension as string,
          }
        };
      }
      results.push(out);
    }
    return [results];
  }
}
