import {
  INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties } from '../../utils/frameUtils';

export class ElementExists implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Element Exists',
    name: 'elementExists',
    icon: 'fa:crosshairs',
    group: ['validation'],
    version: 1,
    description: 'Checks if an element exists. Supports auto-detection across iframes.',
    defaults: { name: 'Element Exists' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      ...frameHandlingProperties,
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
      },
      {
        displayName: 'Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 2000,
        description: 'Maximum time to wait for element',
      }
    ]
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 2000) as number;

      let exists = false;
      let browser: Browser | null = null;
      let resultInfo: any = { selector, frameHandling };

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || await context.newPage();
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });
        resultInfo.currentUrl = await page.url();

        if (frameHandling === 'auto') {
          // Search all frames
          const allFrames = page.frames();
          resultInfo.framesSearched = allFrames.length;

          for (const frame of allFrames) {
            try {
              const el = await frame.$(selector);
              if (el) {
                exists = true;
                resultInfo.foundInFrame = { url: frame.url(), name: frame.name() || '(main)' };
                break;
              }
            } catch {
              // Continue searching
            }
          }

          // If not found immediately, try waiting briefly
          if (!exists) {
            for (const frame of allFrames) {
              try {
                await frame.waitForSelector(selector, { timeout: Math.min(waitTimeout, 1000) });
                exists = true;
                resultInfo.foundInFrame = { url: frame.url(), name: frame.name() || '(main)' };
                break;
              } catch {
                // Continue
              }
            }
          }

        } else if (frameHandling === 'specific' && iframeSelector) {
          // Find specific iframe
          let frame = null;
          if (iframeSelectorStrategy === 'index') {
            const idx = parseInt(iframeSelector, 10) || 0;
            const frames = page.frames();
            if (frames.length > idx + 1) frame = frames[idx + 1];
          } else if (iframeSelectorStrategy === 'name') {
            frame = page.frame({ name: iframeSelector });
          } else if (iframeSelectorStrategy === 'url') {
            frame = page.frame({ url: new RegExp(iframeSelector) });
          } else {
            const el = await page.$(iframeSelector);
            if (el) frame = await el.contentFrame();
          }

          if (frame) {
            exists = !!(await frame.$(selector));
            if (!exists) {
              try {
                await frame.waitForSelector(selector, { timeout: waitTimeout });
                exists = true;
              } catch { exists = false; }
            }
          }

        } else {
          // Main page only
          exists = !!(await page.$(selector));
          if (!exists) {
            try {
              await page.waitForSelector(selector, { timeout: waitTimeout });
              exists = true;
            } catch { exists = false; }
          }
        }

        await browser.close();
      } catch (e) {
        resultInfo.error = (e as Error).message;
        if (browser) await browser.close().catch(() => {});
      }

      results.push({
        json: {
          ...session,
          elementExists: { ...resultInfo, exists }
        }
      });
    }
    return [results];
  }
}
