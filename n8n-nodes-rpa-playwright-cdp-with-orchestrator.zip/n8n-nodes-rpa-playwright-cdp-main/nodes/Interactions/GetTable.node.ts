import {
  INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties, findElementInFrames } from '../../utils/frameUtils';

export class GetTable implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Get Table',
    name: 'getTable',
    icon: 'fa:table',
    group: ['data'],
    version: 1,
    description: 'Extracts HTML table as structured JSON. Supports auto-detection of tables inside iframes.',
    defaults: { name: 'Get Table' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      ...frameHandlingProperties,
      {
        displayName: 'Table Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'e.g. table.data-table, #price-table',
        description: 'CSS selector to find the table element',
      },
      {
        displayName: 'Has Header Row?',
        name: 'hasHeader',
        type: 'boolean',
        default: true,
        description: 'Whether the table has a header row to use as column names',
      },
      {
        displayName: 'Wait For Table Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        description: 'Maximum time to wait for table to appear',
      }
    ]
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const hasHeader = this.getNodeParameter('hasHeader', i, true) as boolean;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;

      let browser: Browser | null = null;
      let tableResult: any = {};

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || await context.newPage();
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        tableResult.currentUrl = await page.url();
        tableResult.selector = selector;

        // Find element (with auto-frame detection)
        const { element: el, frameInfo } = await findElementInFrames(page, selector, {
          frameHandling,
          iframeSelectorStrategy,
          iframeSelector,
          waitTimeout,
          waitState: 'attached',
        });

        // Element is guaranteed non-null by findElementInFrames
        const element = el!;

        // Add frame info to result
        Object.assign(tableResult, frameInfo);

        // Extract table data
        const tableRows = await element.evaluate((table, hasHeaderParam) => {
          const tbl = table as any;
          const rows = Array.from(tbl.querySelectorAll('tr')) as any[];
          let headers: string[] = [];

          if (hasHeaderParam) {
            const headerRow = rows.shift();
            if (headerRow) {
              const headerCells = Array.from(headerRow.querySelectorAll('th,td')) as any[];
              headers = headerCells.map((cell: any, idx: number) => cell.textContent?.trim() || `Column_${idx + 1}`);
            }
          }

          return rows.map((row: any) => {
            const cells = Array.from(row.querySelectorAll('td,th')) as any[];
            const values = cells.map((cell: any) => cell.textContent?.trim() || '');

            if (hasHeaderParam && headers.length > 0) {
              const obj: {[k: string]: string} = {};
              headers.forEach((header: string, idx: number) => {
                obj[header || `Column_${idx + 1}`] = values[idx] || '';
              });
              return obj;
            } else {
              return values;
            }
          });
        }, hasHeader);

        tableResult.rowCount = tableRows.length;
        tableResult.hasHeader = hasHeader;
        tableResult.result = 'success';
        tableResult.rows = tableRows;

        await browser.close();

      } catch (e) {
        tableResult.result = 'error';
        tableResult.error = (e as Error).message;
        tableResult.selector = selector;
        tableResult.hasHeader = hasHeader;
        tableResult.rows = [];

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      results.push({
        json: {
          ...session,
          getTableAction: tableResult
        }
      });
    }

    return [results];
  }
}
