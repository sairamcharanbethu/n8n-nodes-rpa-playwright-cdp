import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, ElementHandle, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';

// Note: DOM types are available in browser context via evaluate() callbacks
// We use 'any' casts for evaluate functions since they run in browser context

/**
 * Element info for strategy selection
 */
interface ElementInfo {
  tagName: string;
  type: string | null;
  isContentEditable: boolean;
  isDisabled: boolean;
  isReadonly: boolean;
  hasFrameworkBindings: boolean;
  hasValidation: boolean;
  inputMode: string | null;
}

/**
 * Convert user selector to Playwright-compatible selector
 */
function buildPlaywrightSelector(strategy: string, selector: string): string {
  const trimmedSelector = selector.trim();

  switch (strategy) {
    case 'css':
      return trimmedSelector;

    case 'xpath':
      return trimmedSelector.startsWith('//') || trimmedSelector.startsWith('(')
        ? `xpath=${trimmedSelector}`
        : `xpath=//${trimmedSelector}`;

    case 'id':
      return `#${trimmedSelector.replace(/^#/, '')}`;

    case 'name':
      return `[name="${trimmedSelector}"]`;

    case 'class':
      return `.${trimmedSelector.replace(/^\./, '')}`;

    case 'testid':
      return `[data-testid="${trimmedSelector}"]`;

    case 'placeholder':
      return `[placeholder="${trimmedSelector}"]`;

    case 'label':
      return `xpath=//label[contains(text(),"${trimmedSelector}")]/following::input[1] | //label[contains(text(),"${trimmedSelector}")]//input | //input[@id=//label[contains(text(),"${trimmedSelector}")]/@for]`;

    case 'aria':
      return `[aria-label="${trimmedSelector}"]`;

    case 'text':
      return `text=${trimmedSelector}`;

    case 'role':
      return `role=${trimmedSelector}`;

    case 'auto':
      return autoDetectSelector(trimmedSelector);

    default:
      return trimmedSelector;
  }
}

/**
 * Auto-detect selector type based on format
 */
function autoDetectSelector(selector: string): string {
  const s = selector.trim();

  if (s.startsWith('//') || s.startsWith('(//') || s.startsWith('xpath=')) {
    return s.startsWith('xpath=') ? s : `xpath=${s}`;
  }

  if (s.startsWith('text=') || s.startsWith('role=') || s.startsWith('css=')) {
    return s;
  }

  if (s.startsWith('#') || s.startsWith('.')) {
    return s;
  }

  if (s.startsWith('[') && s.endsWith(']')) {
    return s;
  }

  if (s.includes(' ') || s.includes('>') || s.includes('+') || s.includes('~') || s.includes(':')) {
    return s;
  }

  if (/^[a-zA-Z][a-zA-Z0-9_-]*$/.test(s)) {
    return `#${s}, [name="${s}"], .${s}`;
  }

  return s;
}

/**
 * Get element value based on element type
 */
async function getElementValue(element: ElementHandle): Promise<string> {
  return await element.evaluate((el: any) => {
    const tagName = el.tagName.toUpperCase();

    if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
      return el.value || '';
    }

    if (tagName === 'SELECT') {
      return el.value || '';
    }

    if (el.isContentEditable) {
      return el.innerText || el.textContent || '';
    }

    return el.innerText || el.textContent || '';
  });
}

/**
 * Get element info for smart strategy selection
 */
async function getElementInfo(element: ElementHandle): Promise<ElementInfo> {
  return await element.evaluate((el: any) => {
    const attrs: Array<{ name: string }> = [];
    for (let i = 0; i < el.attributes.length; i++) {
      attrs.push({ name: el.attributes[i].name });
    }

    return {
      tagName: el.tagName.toLowerCase(),
      type: el.type || null,
      isContentEditable: el.isContentEditable || false,
      isDisabled: el.disabled || false,
      isReadonly: el.readOnly || false,
      hasFrameworkBindings: attrs.some(
        (attr: { name: string }) =>
          attr.name.startsWith('ng-') ||
          attr.name.startsWith('_ng') ||
          attr.name.startsWith('data-react') ||
          attr.name.startsWith('v-') ||
          attr.name.startsWith('@') ||
          attr.name.includes('bind'),
      ),
      hasValidation:
        el.hasAttribute('required') ||
        el.hasAttribute('pattern') ||
        el.hasAttribute('min') ||
        el.hasAttribute('max') ||
        el.hasAttribute('minlength') ||
        el.hasAttribute('maxlength'),
      inputMode: el.inputMode || null,
    };
  });
}

/**
 * Determine best typing strategy based on element analysis
 */
function selectTypingStrategy(elementInfo: ElementInfo, text: string): 'fill' | 'keyboard' | 'js' {
  if (elementInfo.isContentEditable) {
    return 'keyboard';
  }

  if (elementInfo.isReadonly || elementInfo.isDisabled) {
    return 'js';
  }

  if (elementInfo.hasFrameworkBindings) {
    return 'keyboard';
  }

  if (elementInfo.hasValidation) {
    return 'keyboard';
  }

  if (elementInfo.type === 'number' || elementInfo.inputMode === 'numeric' || /^\d+$/.test(text)) {
    return 'keyboard';
  }

  const specialTypes = ['tel', 'email', 'url', 'search', 'date', 'time', 'datetime-local'];
  if (elementInfo.type && specialTypes.includes(elementInfo.type)) {
    return 'keyboard';
  }

  return 'fill';
}

/**
 * Clear element content using multiple strategies
 */
async function clearElement(page: Page, element: ElementHandle): Promise<void> {
  const strategies = [
    async () => {
      await element.click({ clickCount: 3 });
      await page.keyboard.press('Backspace');
    },
    async () => {
      await element.focus();
      await page.keyboard.press('Control+a');
      await page.keyboard.press('Delete');
    },
    async () => {
      await element.fill('');
    },
    async () => {
      await element.evaluate((el: any) => {
        const win = globalThis as any;
        const tagName = el.tagName.toUpperCase();
        if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
          el.value = '';
        } else if (el.isContentEditable) {
          el.innerHTML = '';
        }
        el.dispatchEvent(new win.Event('input', { bubbles: true }));
        el.dispatchEvent(new win.Event('change', { bubbles: true }));
      });
    },
  ];

  for (const strategy of strategies) {
    try {
      await strategy();
      const value = await getElementValue(element);
      if (!value || value.trim() === '') {
        return;
      }
    } catch {
      // Try next strategy
    }
  }
}

/**
 * Type text using fill method
 */
async function typeFill(element: ElementHandle, text: string): Promise<void> {
  await element.fill(text);
}

/**
 * Type text using keyboard simulation
 */
async function typeKeyboard(page: Page, element: ElementHandle, text: string, delay: number): Promise<void> {
  await element.focus();
  await page.keyboard.type(text, { delay: delay > 0 ? delay : undefined });
}

/**
 * Type text using JavaScript injection
 */
async function typeJS(element: ElementHandle, text: string): Promise<void> {
  await element.evaluate((el: any, value: string) => {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const win = globalThis as any;
    const tagName = el.tagName.toUpperCase();

    if (tagName === 'INPUT' || tagName === 'TEXTAREA') {
      // Try native setter for React compatibility
      const proto = tagName === 'INPUT'
        ? win.HTMLInputElement.prototype
        : win.HTMLTextAreaElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');

      if (descriptor && descriptor.set) {
        descriptor.set.call(el, value);
      } else {
        el.value = value;
      }
    } else if (el.isContentEditable) {
      el.innerText = value;
    }

    // Dispatch events
    el.dispatchEvent(new win.Event('input', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new win.Event('change', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new win.KeyboardEvent('keyup', { bubbles: true }));
    /* eslint-enable @typescript-eslint/no-explicit-any */
  }, text);
}

/**
 * Validate typed text
 */
function validateTypedText(
  actualValue: string,
  expectedText: string,
  method: string,
): { passed: boolean; message: string } {
  switch (method) {
    case 'exact':
      return {
        passed: actualValue === expectedText,
        message:
          actualValue === expectedText
            ? 'Text matches exactly'
            : `Expected: "${expectedText}", Actual: "${actualValue}"`,
      };

    case 'contains':
      return {
        passed: actualValue.includes(expectedText),
        message: actualValue.includes(expectedText)
          ? 'Text contains expected value'
          : `Expected "${expectedText}" not found in "${actualValue}"`,
      };

    case 'notEmpty':
      return {
        passed: actualValue.trim().length > 0,
        message: actualValue.trim().length > 0 ? 'Element has non-empty value' : 'Element is empty after typing',
      };

    case 'length':
      return {
        passed: actualValue.length === expectedText.length,
        message:
          actualValue.length === expectedText.length
            ? 'Text length matches'
            : `Expected length: ${expectedText.length}, Actual: ${actualValue.length}`,
      };

    default:
      return { passed: true, message: 'No validation' };
  }
}

/**
 * Unified TypeInto Node - Robust text input for any element type
 * Supports: CSS, XPath, ID, Name, Class, Data attributes, Text, and more
 */
export class TypeInto implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Type Into Element',
    name: 'typeInto',
    icon: 'fa:keyboard-o',
    group: ['transform'],
    version: 1,
    description:
      'Types text into any element using CSS, XPath, ID, Name, or other selector strategies. Handles complex forms, SPAs, and framework-based apps.',
    defaults: { name: 'Type Into' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'Chrome DevTools Protocol WebSocket URL',
      },
      {
        displayName: 'Frame Handling',
        name: 'frameHandling',
        type: 'options',
        default: 'auto',
        options: [
          {
            name: 'Auto-Detect (Recommended)',
            value: 'auto',
            description: 'Automatically search all frames to find the element',
          },
          {
            name: 'Main Page Only',
            value: 'main',
            description: 'Only search in the main page, not in iframes',
          },
          {
            name: 'Specific Iframe',
            value: 'specific',
            description: 'Manually specify which iframe to use',
          },
        ],
        description: 'How to handle iframes when searching for elements',
      },
      {
        displayName: 'Iframe Selector Strategy',
        name: 'iframeSelectorStrategy',
        type: 'options',
        default: 'css',
        displayOptions: {
          show: {
            frameHandling: ['specific'],
          },
        },
        options: [
          {
            name: 'CSS Selector',
            value: 'css',
            description: 'CSS selector for the iframe element',
          },
          {
            name: 'Frame Name',
            value: 'name',
            description: 'Name attribute of the iframe',
          },
          {
            name: 'Frame URL (contains)',
            value: 'url',
            description: 'Part of the iframe URL',
          },
          {
            name: 'Index',
            value: 'index',
            description: 'Iframe index (0 = first iframe)',
          },
        ],
        description: 'How to locate the iframe',
      },
      {
        displayName: 'Iframe Selector',
        name: 'iframeSelector',
        type: 'string',
        default: '',
        displayOptions: {
          show: {
            frameHandling: ['specific'],
          },
        },
        placeholder: 'e.g., #login-frame, main-frame, login.html, or 0',
        description: 'The iframe identifier based on chosen strategy',
      },
      {
        displayName: 'Selector Strategy',
        name: 'selectorStrategy',
        type: 'options',
        default: 'css',
        required: true,
        options: [
          {
            name: 'CSS Selector',
            value: 'css',
            description: 'Standard CSS selector (e.g., #id, .class, input[name="email"])',
          },
          {
            name: 'XPath',
            value: 'xpath',
            description: 'XPath expression (e.g., //input[@id="username"])',
          },
          {
            name: 'ID',
            value: 'id',
            description: 'Element ID (without #)',
          },
          {
            name: 'Name',
            value: 'name',
            description: 'Element name attribute',
          },
          {
            name: 'Class Name',
            value: 'class',
            description: 'Element class name (single class, without .)',
          },
          {
            name: 'Data Test ID',
            value: 'testid',
            description: 'data-testid attribute value',
          },
          {
            name: 'Placeholder',
            value: 'placeholder',
            description: 'Input placeholder text',
          },
          {
            name: 'Label Text',
            value: 'label',
            description: 'Associated label text (finds input linked to label)',
          },
          {
            name: 'ARIA Label',
            value: 'aria',
            description: 'aria-label attribute value',
          },
          {
            name: 'Text Content',
            value: 'text',
            description: 'Element containing this text (for contenteditable)',
          },
          {
            name: 'Role',
            value: 'role',
            description: 'ARIA role attribute (e.g., textbox, searchbox)',
          },
          {
            name: 'Auto-Detect',
            value: 'auto',
            description: 'Automatically detect selector type based on format',
          },
        ],
        description: 'Method to locate the target element',
      },
      {
        displayName: 'Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        description: 'The selector value based on chosen strategy',
        placeholder: 'e.g., #username, //input[@type="email"], email-input',
      },
      {
        displayName: 'Text to Type',
        name: 'text',
        type: 'string',
        default: '',
        required: true,
        description: 'Text content to type into the element (numbers auto-converted to string)',
      },
      {
        displayName: 'Typing Strategy',
        name: 'typingStrategy',
        type: 'options',
        default: 'auto',
        options: [
          {
            name: 'Auto (Recommended)',
            value: 'auto',
            description: 'Automatically choose the best method based on element and content',
          },
          {
            name: 'Fill Method (Fast)',
            value: 'fill',
            description: 'Use Playwright fill() - faster but may not trigger all events',
          },
          {
            name: 'Keyboard Typing (Compatible)',
            value: 'keyboard',
            description: 'Simulate real keystrokes - slower but works with validation',
          },
          {
            name: 'JavaScript Injection',
            value: 'js',
            description: 'Set value via JavaScript - works with hidden/readonly fields',
          },
        ],
        description: 'Strategy for entering text into the element',
      },
      {
        displayName: 'Wait For Element Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        description: 'Maximum time to wait for element to appear',
      },
      {
        displayName: 'Clear Field First',
        name: 'clearFirst',
        type: 'boolean',
        default: true,
        description: 'Clear the field before typing new text',
      },
      {
        displayName: 'Typing Delay (ms)',
        name: 'typingDelay',
        type: 'number',
        default: 0,
        description: 'Delay between keystrokes (only for keyboard strategy, 0 = instant)',
      },
      {
        displayName: 'Click Before Typing',
        name: 'clickFirst',
        type: 'boolean',
        default: true,
        description: 'Click the element before typing to ensure focus',
      },
      {
        displayName: 'Press Enter After',
        name: 'pressEnter',
        type: 'boolean',
        default: false,
        description: 'Press Enter key after typing (submit form)',
      },
      {
        displayName: 'Press Tab After',
        name: 'pressTab',
        type: 'boolean',
        default: false,
        description: 'Press Tab key after typing (move to next field)',
      },
      {
        displayName: 'Wait After Typing (ms)',
        name: 'waitAfter',
        type: 'number',
        default: 0,
        description: 'Wait time after typing is complete',
      },
      {
        displayName: 'Retry on Failure',
        name: 'retryOnFailure',
        type: 'boolean',
        default: true,
        description: 'If first typing method fails, automatically try alternative methods',
      },
      {
        displayName: 'Max Retries',
        name: 'maxRetries',
        type: 'number',
        default: 3,
        description: 'Maximum number of retry attempts',
        displayOptions: {
          show: {
            retryOnFailure: [true],
          },
        },
      },
      {
        displayName: 'Validate Input',
        name: 'validateInput',
        type: 'boolean',
        default: true,
        description: 'Verify that text was successfully typed into the element',
      },
      {
        displayName: 'Validation Method',
        name: 'validationMethod',
        type: 'options',
        default: 'contains',
        displayOptions: {
          show: {
            validateInput: [true],
          },
        },
        options: [
          {
            name: 'Exact Match',
            value: 'exact',
            description: 'Element value must exactly match the typed text',
          },
          {
            name: 'Contains',
            value: 'contains',
            description: 'Element value must contain the typed text',
          },
          {
            name: 'Not Empty',
            value: 'notEmpty',
            description: 'Element value must not be empty after typing',
          },
          {
            name: 'Length Check',
            value: 'length',
            description: 'Element value length must match typed text length',
          },
        ],
        description: 'How to validate the typed text',
      },
      {
        displayName: 'Fail on Validation Error',
        name: 'failOnValidationError',
        type: 'boolean',
        default: false,
        displayOptions: {
          show: {
            validateInput: [true],
          },
        },
        description: 'Throw an error if validation fails (otherwise just flag it)',
      },
      {
        displayName: 'Scroll Into View',
        name: 'scrollIntoView',
        type: 'boolean',
        default: true,
        description: 'Scroll the element into view before interacting',
      },
      {
        displayName: 'Wait for Element State',
        name: 'waitForState',
        type: 'options',
        default: 'visible',
        options: [
          {
            name: 'Visible',
            value: 'visible',
            description: 'Wait for element to be visible',
          },
          {
            name: 'Attached',
            value: 'attached',
            description: 'Wait for element to be in DOM',
          },
          {
            name: 'Enabled',
            value: 'enabled',
            description: 'Wait for element to be enabled (not disabled)',
          },
          {
            name: 'Editable',
            value: 'editable',
            description: 'Wait for element to be editable',
          },
        ],
        description: 'Element state to wait for before typing',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;

      // Get parameters
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selectorStrategy = this.getNodeParameter('selectorStrategy', i) as string;
      const selectorInput = this.getNodeParameter('selector', i) as string;
      const textParam = this.getNodeParameter('text', i);
      const text = String(textParam);
      const typingStrategy = this.getNodeParameter('typingStrategy', i, 'auto') as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;
      const clearFirst = this.getNodeParameter('clearFirst', i, true) as boolean;
      const typingDelay = this.getNodeParameter('typingDelay', i, 0) as number;
      const clickFirst = this.getNodeParameter('clickFirst', i, true) as boolean;
      const pressEnter = this.getNodeParameter('pressEnter', i, false) as boolean;
      const pressTab = this.getNodeParameter('pressTab', i, false) as boolean;
      const waitAfter = this.getNodeParameter('waitAfter', i, 0) as number;
      const retryOnFailure = this.getNodeParameter('retryOnFailure', i, true) as boolean;
      const maxRetries = this.getNodeParameter('maxRetries', i, 3) as number;
      const validateInput = this.getNodeParameter('validateInput', i, true) as boolean;
      const validationMethod = this.getNodeParameter('validationMethod', i, 'contains') as string;
      const failOnValidationError = this.getNodeParameter('failOnValidationError', i, false) as boolean;
      const scrollIntoView = this.getNodeParameter('scrollIntoView', i, true) as boolean;
      const waitForState = this.getNodeParameter('waitForState', i, 'visible') as string;

      const typingResult: Record<string, unknown> = {
        selectorStrategy,
        originalSelector: selectorInput,
      };

      let browser = null;

      try {
        // Build Playwright selector
        const playwrightSelector = buildPlaywrightSelector(selectorStrategy, selectorInput);
        typingResult.resolvedSelector = playwrightSelector;

        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL (LaunchBrowser creates a new context)
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        // Search all contexts for the page with matching URL
        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        // Fallback: use first non-empty page or create new one
        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        // Final fallback
        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || (await context.newPage());
        }

        // Wait for page load
        await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
        typingResult.currentUrl = page.url();

        // Handle frame detection
        let targetContext: Page | any = page;
        let element: ElementHandle | null = null;
        const selectorState = ['enabled', 'editable'].includes(waitForState) ? 'visible' : waitForState;

        typingResult.frameHandling = frameHandling;

        if (frameHandling === 'auto') {
          // AUTO-DETECT: Search through all frames to find the element
          const allFrames = page.frames();
          typingResult.framesFound = allFrames.length;
          typingResult.framesSearched = [];

          for (const frame of allFrames) {
            const frameInfo = { url: frame.url(), name: frame.name() || '(main)' };
            try {
              // Try to find element in this frame with a short timeout
              const el = await frame.waitForSelector(playwrightSelector, {
                timeout: Math.min(2000, waitTimeout / allFrames.length),
                state: selectorState as 'visible' | 'attached' | 'hidden' | 'detached',
              }).catch(() => null);

              if (el) {
                element = el;
                targetContext = frame;
                typingResult.elementFoundInFrame = frameInfo;
                (typingResult.framesSearched as any[]).push({ ...frameInfo, found: true });
                break;
              } else {
                (typingResult.framesSearched as any[]).push({ ...frameInfo, found: false });
              }
            } catch {
              (typingResult.framesSearched as any[]).push({ ...frameInfo, found: false, error: true });
            }
          }

          // If not found in quick search, do a longer wait on all frames
          if (!element) {
            for (const frame of allFrames) {
              try {
                const el = await frame.$(playwrightSelector);
                if (el) {
                  element = el;
                  targetContext = frame;
                  typingResult.elementFoundInFrame = { url: frame.url(), name: frame.name() || '(main)' };
                  break;
                }
              } catch {
                // Continue to next frame
              }
            }
          }

          if (!element) {
            const frameList = allFrames.map(f => `${f.name() || '(main)'}: ${f.url()}`).join('\n  - ');
            throw new Error(`Element not found with selector "${playwrightSelector}" in any frame.\n\nSearched ${allFrames.length} frames:\n  - ${frameList}\n\nTip: Check if the selector is correct using browser DevTools.`);
          }

        } else if (frameHandling === 'specific' && iframeSelector) {
          // SPECIFIC IFRAME: User specified which iframe to use
          typingResult.iframeStrategy = iframeSelectorStrategy;
          typingResult.iframeSelector = iframeSelector;

          let frame = null;
          switch (iframeSelectorStrategy) {
            case 'css': {
              const iframeCss = iframeSelector.startsWith('#') || iframeSelector.startsWith('.') || iframeSelector.startsWith('[')
                ? iframeSelector
                : `iframe[id="${iframeSelector}"], iframe[name="${iframeSelector}"], iframe.${iframeSelector}`;
              await page.waitForSelector(iframeCss, { timeout: waitTimeout });
              const frameElement = await page.$(iframeCss);
              if (frameElement) {
                frame = await frameElement.contentFrame();
              }
              break;
            }
            case 'name': {
              await page.waitForFunction(
                (name: string) => {
                  const win = globalThis as any;
                  const frames = win.document.querySelectorAll('iframe');
                  for (const f of frames) {
                    if (f.name === name || f.id === name) return true;
                  }
                  return false;
                },
                iframeSelector,
                { timeout: waitTimeout }
              );
              frame = page.frame({ name: iframeSelector });
              break;
            }
            case 'url': {
              await page.waitForFunction(
                (urlPart: string) => {
                  const win = globalThis as any;
                  const frames = win.document.querySelectorAll('iframe');
                  for (const f of frames) {
                    if (f.src && f.src.includes(urlPart)) return true;
                  }
                  return false;
                },
                iframeSelector,
                { timeout: waitTimeout }
              );
              frame = page.frame({ url: new RegExp(iframeSelector) });
              break;
            }
            case 'index': {
              const index = parseInt(iframeSelector, 10) || 0;
              const frames = page.frames();
              if (frames.length > index + 1) {
                frame = frames[index + 1];
              }
              break;
            }
          }

          if (!frame) {
            throw new Error(`Iframe not found with ${iframeSelectorStrategy}: ${iframeSelector}. Available frames: ${page.frames().map(f => f.url()).join(', ')}`);
          }

          targetContext = frame;
          typingResult.iframeUrl = frame.url();
          typingResult.iframeFound = true;

          // Now find element in the specified iframe
          await targetContext.waitForSelector(playwrightSelector, {
            timeout: waitTimeout,
            state: selectorState as 'visible' | 'attached' | 'hidden' | 'detached',
          });
          element = await targetContext.$(playwrightSelector);

        } else {
          // MAIN PAGE ONLY
          await page.waitForSelector(playwrightSelector, {
            timeout: waitTimeout,
            state: selectorState as 'visible' | 'attached' | 'hidden' | 'detached',
          });
          element = await page.$(playwrightSelector);
        }

        if (!element) {
          throw new Error(`Element not found with selector: ${playwrightSelector}`);
        }

        // Additional state checks
        if (waitForState === 'enabled') {
          await element.waitForElementState('enabled', { timeout: waitTimeout });
        } else if (waitForState === 'editable') {
          await element.waitForElementState('editable', { timeout: waitTimeout });
        }

        // Get element info
        const elementInfo = await getElementInfo(element);
        typingResult.elementInfo = elementInfo;
        typingResult.valueBefore = await getElementValue(element);

        // Scroll into view
        if (scrollIntoView) {
          await element.scrollIntoViewIfNeeded();
        }

        // Click to focus
        if (clickFirst) {
          await element.click();
          await page.waitForTimeout(50);
        }

        // Clear field
        if (clearFirst) {
          await clearElement(page, element);
        }

        // Determine typing strategy
        let selectedStrategy = typingStrategy;
        if (selectedStrategy === 'auto') {
          selectedStrategy = selectTypingStrategy(elementInfo, text);
        }
        typingResult.selectedStrategy = selectedStrategy;

        // Typing methods in order of preference for retry
        const typingMethods: Array<{ name: string; fn: () => Promise<void> }> = [
          {
            name: selectedStrategy,
            fn: async () => {
              switch (selectedStrategy) {
                case 'fill':
                  await typeFill(element, text);
                  break;
                case 'keyboard':
                  await typeKeyboard(page, element, text, typingDelay);
                  break;
                case 'js':
                  await typeJS(element, text);
                  break;
              }
            },
          },
          { name: 'keyboard', fn: () => typeKeyboard(page, element, text, typingDelay) },
          { name: 'fill', fn: () => typeFill(element, text) },
          { name: 'js', fn: () => typeJS(element, text) },
        ];

        // Remove duplicates while preserving order
        const uniqueMethods = typingMethods.filter(
          (method, index, self) => index === self.findIndex((m) => m.name === method.name),
        );

        // Try typing with retries
        let typingSuccess = false;
        let lastError: Error | null = null;
        const attemptedMethods: string[] = [];

        const maxAttempts = retryOnFailure ? Math.min(maxRetries, uniqueMethods.length) : 1;

        for (let attempt = 0; attempt < maxAttempts && !typingSuccess; attempt++) {
          const method = uniqueMethods[attempt];
          attemptedMethods.push(method.name);

          try {
            // Re-clear if retrying
            if (attempt > 0 && clearFirst) {
              await clearElement(page, element);
            }

            await method.fn();

            // Brief pause to let value settle
            await page.waitForTimeout(50);

            // Quick validation check
            const currentValue = await getElementValue(element);
            if (currentValue.includes(text) || currentValue === text || text === '') {
              typingSuccess = true;
              typingResult.successfulMethod = method.name;
            } else if (!retryOnFailure) {
              typingSuccess = true;
              typingResult.successfulMethod = method.name;
            }
          } catch (e) {
            lastError = e as Error;
            typingResult[`attempt${attempt + 1}Error`] = (e as Error).message;
          }
        }

        typingResult.attemptedMethods = attemptedMethods;

        if (!typingSuccess && lastError) {
          throw lastError;
        }

        // Press Enter if requested
        if (pressEnter) {
          await page.keyboard.press('Enter');
          typingResult.pressedEnter = true;
        }

        // Press Tab if requested
        if (pressTab) {
          await page.keyboard.press('Tab');
          typingResult.pressedTab = true;
        }

        // Wait after typing
        if (waitAfter > 0) {
          await page.waitForTimeout(waitAfter);
        }

        // Get final value and validate (wrapped to handle navigation after Enter)
        try {
          const valueAfter = await getElementValue(element);
          typingResult.valueAfter = valueAfter;
          typingResult.textTyped = text;

          // Validate input
          if (validateInput) {
            const validation = validateTypedText(valueAfter, text, validationMethod);
            typingResult.validation = {
              enabled: true,
              method: validationMethod,
              passed: validation.passed,
              message: validation.message,
              expectedText: text,
              actualValue: valueAfter,
            };

            if (!validation.passed) {
              if (failOnValidationError) {
                throw new Error(`Validation failed: ${validation.message}`);
              }
              typingResult.result = 'validation_failed';
            } else {
              typingResult.result = 'success';
            }
          } else {
            typingResult.validation = { enabled: false };
            typingResult.result = 'success';
          }
        } catch (navError: any) {
          // If Enter/Tab caused navigation, the element context is destroyed
          // This is expected behavior - treat as success
          if (navError.message?.includes('Execution context was destroyed') ||
              navError.message?.includes('Target closed') ||
              navError.message?.includes('navigating')) {
            typingResult.textTyped = text;
            typingResult.result = 'success';
            typingResult.message = 'Typing completed. Page navigated (validation skipped).';
            typingResult.validation = {
              enabled: false,
              skipped: true,
              reason: 'Page navigated after Enter/Tab'
            };
          } else {
            throw navError; // Re-throw if it's a different error
          }
        }

        await browser.close();
      } catch (e) {
        const errorMsg = (e as Error).message;

        typingResult.result = 'error';
        typingResult.error = errorMsg;

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      // Return result with session data preserved
      results.push({ json: { ...session, typeAction: typingResult } });
    }

    return [results];
  }
}
