import {
  INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import { frameHandlingProperties, findElementInFrames } from '../../utils/frameUtils';

export class GetText implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Get Text',
    name: 'getText',
    icon: 'fa:font',
    group: ['transform'],
    version: 1,
    description: 'Extracts text from an element. Supports auto-detection of elements inside iframes.',
    defaults: { name: 'Get Text' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      ...frameHandlingProperties,
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'e.g. .result-title, #main-text',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 5000,
        description: 'Maximum time to wait for selector to appear',
      },
      {
        displayName: 'Trim Whitespace',
        name: 'trimWhitespace',
        type: 'boolean',
        default: true,
      }
    ]
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const frameHandling = this.getNodeParameter('frameHandling', i, 'auto') as string;
      const iframeSelectorStrategy = this.getNodeParameter('iframeSelectorStrategy', i, 'css') as string;
      const iframeSelector = this.getNodeParameter('iframeSelector', i, '') as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;
      const trimWhitespace = this.getNodeParameter('trimWhitespace', i, true) as boolean;

      let browser: Browser | null = null;
      let getTextResult: any = {};

      try {
        // Connect to browser via CDP (works for both orchestrator and Selenium)
        browser = await chromium.connectOverCDP(cdpUrl);

        // Find the correct page by URL
        let page: Page | null = null;
        const targetUrl = session.currentUrl;

        for (const ctx of browser.contexts()) {
          for (const p of ctx.pages()) {
            const pageUrl = p.url();
            if (targetUrl && (pageUrl === targetUrl || pageUrl.startsWith(targetUrl.split('?')[0]))) {
              page = p;
              break;
            }
          }
          if (page) break;
        }

        if (!page) {
          for (const ctx of browser.contexts()) {
            for (const p of ctx.pages()) {
              if (!p.url().startsWith('chrome://') && !p.url().startsWith('about:')) {
                page = p;
                break;
              }
            }
            if (page) break;
          }
        }

        if (!page) {
          const context = browser.contexts()[0];
          page = context.pages()[0] || await context.newPage();
        }

        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        getTextResult.currentUrl = await page.url();
        getTextResult.selector = selector;

        // Find element (with auto-frame detection)
        const { element: el, frameInfo } = await findElementInFrames(page, selector, {
          frameHandling,
          iframeSelectorStrategy,
          iframeSelector,
          waitTimeout,
          waitState: 'attached',
        });

        // Element is guaranteed non-null by findElementInFrames
        const element = el!;

        // Add frame info to result
        Object.assign(getTextResult, frameInfo);

        // Get text content
        const textContent = await element.evaluate((el: any) => el.textContent || '');

        getTextResult.text = trimWhitespace ? textContent.trim() : textContent;
        getTextResult.result = 'success';

        await browser.close();
      } catch (e) {
        getTextResult.result = 'error';
        getTextResult.error = (e as Error).message;
        getTextResult.selector = selector;
        if (browser) await browser.close().catch(() => {});
      }

      results.push({ json: { ...session, getText: getTextResult } });
    }
    return [results];
  }
}
