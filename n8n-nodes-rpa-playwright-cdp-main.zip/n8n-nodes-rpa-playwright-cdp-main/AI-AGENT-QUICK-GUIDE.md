# AI Agent Quick Reference Guide

## 🚀 Quick Start

### Basic Workflow Pattern
```
1. Launch Browser → Get CDP URL
2. Find Element → Get selector  
3. Interact (Type/Click/Select) → Use selector
4. Close Browser
```

## 🛠️ Available Element Types

When using **Find Element**, specify one of these types:

| Type | Use For | Example |
|------|---------|---------|
| `input` | Single-line text input fields (NOT buttons!) | Email field, username, password |
| `textarea` | Multi-line text areas | Comments, descriptions, **Google search box** |
| `button` | Clickable buttons (including submit) | Submit, Login, Search button |
| `select` | Dropdown menus | Country selector, language picker |
| `checkbox` | Checkbox inputs | Terms & conditions, newsletter |
| `radio` | Radio button inputs | Gender selection, payment method |
| `textarea` | Multi-line text areas | Comments, descriptions, messages |
| `a` | Links | Navigation links, "Read more" |
| `div` | Container elements | Cards, sections, panels |
| `span` | Inline text elements | Labels, badges, inline text |
| `p` | Paragraphs | Text blocks |
| `h1,h2,h3,h4,h5,h6` | Headings | Page titles, section headers |
| `table` | Tables | Data tables, grids |
| `img` | Images | Logos, photos, icons |
| `*` | Any element | When type is unknown |

## 📋 Common Workflows

### 🔍 Search a Website (e.g., Google)
```
1. Launch Browser(url)
2. Find Element(description="search box", type="textarea")  ⚠️ Google uses textarea!
   OR Find Element(description="search box", type="*")  ← Use "*" if unsure
3. Type Into(selector=<from step 2>, text="query", pressEnter=true)
4. Page Loaded()
5. Close Browser()
```

**⚠️ Important**: Google's search box is a `<textarea>`, not an `<input>`! Use `type="textarea"` or `type="*"` (any type).

### 📝 Fill a Form
```
1. Launch Browser(url)
2. Find Element(description="name field", type="input")
3. Type Into(selector=<from step 2>, text="John")
4. Find Element(description="email field", type="input")  
5. Type Into(selector=<from step 4>, text="john@test.com")
6. Find Element(description="submit button", type="button")
7. Click Element(selector=<from step 6>)
8. Close Browser()
```

### 🎯 Select from Dropdown
```
1. Launch Browser(url)
2. Find Element(description="country dropdown", type="select")
3. Get Select Options(selector=<from step 2>)
   → Returns available options
4. Select Option(selector=<from step 2>, method="text", value="United States")
5. Close Browser()
```

### 📊 Extract Data
```
1. Launch Browser(url)
2. Find Element(description="product price", type="span")
3. Get Text(selector=<from step 2>)
   → Returns text content
4. Close Browser()
```

## ⚙️ Selection Methods (for Select Option tool)

| Method | When to Use | Example |
|--------|-------------|---------|
| `value` | When you know the option's value attribute | `value="us"` |
| `text` | When you know the visible text | `text="United States"` |
| `index` | When you know the position (0-based) | `index=0` (first option) |

## ⚠️ Common Mistakes to Avoid

❌ **DON'T**: Use elementType="input" for Google search
```
Find Element(description="search box", elementType="input")  # WRONG for Google!
```

✅ **DO**: Use elementType="textarea" or "*" for Google search
```
Find Element(description="search box", elementType="textarea")  # CORRECT!
OR
Find Element(description="search box", elementType="*")  # Also works!
```

---

❌ **DON'T**: Type into select elements
```
Type Into(selector="select#country", text="USA")  # WRONG!
```

✅ **DO**: Use Select Option for dropdowns
```
Select Option(selector="select#country", method="text", value="USA")  # CORRECT!
```

---

❌ **DON'T**: Skip Find Element
```
Type Into(selector="input", text="test")  # Too generic!
```

✅ **DO**: Use Find Element first
```
Find Element(description="email field", type="input")
→ Get specific selector like "input#email"
Type Into(selector="input#email", text="test@example.com")
```

---

❌ **DON'T**: Forget to pass CDP URL
```
Type Into(selector="input#email", text="test")  # Missing CDP URL!
```

✅ **DO**: Always include CDP URL from Launch Browser
```
Launch Browser() → cdpUrl="ws://localhost:9222/..."
Type Into(CDP_URL="ws://localhost:9222/...", selector="input#email", text="test")
```

## 🎯 Best Practices

### 1. Always Use Page Loaded After Navigation
```
Launch Browser(url)
→ Page Loaded()  # Wait for page to be ready
→ Find Element(...)
```

### 2. Get Selector from Top Level
When Find Element returns:
```json
{
  "selector": "input#email",  ← USE THIS (top level)
  "findElementResult": {
    "selector": "input#email",  ← Not this (nested)
    "confidence": 0.95
  }
}
```

### 3. Check Dropdown Options First
```
Find Element(type="select")
→ Get Select Options()  # See what's available
→ Select Option()  # Choose the right one
```

### 4. Use Screenshots for Debugging
```
If something fails:
→ Take Screenshot()  # See what's on the page
→ Analyze and retry
```

### 5. Always Close Browser
```
try:
  Launch Browser()
  ... do work ...
finally:
  Close Browser()  # Even if errors occur
```

## 🔧 Troubleshooting

### Element Not Found
```
Try:
1. Use elementType="*" (any type) - works for all elements
2. Try different element type:
   - If looking for Google search: use "textarea" not "input"
   - If looking for text field: try both "input" and "textarea"
3. Make simpler description (e.g., "search box" instead of "main search input field")
4. Wait for page to load first (Page Loaded)
5. Take screenshot to see page state
```

### Type Into Not Working
```
If error says "Cannot type into input with type=submit/button":
→ You found a BUTTON, not a text field!
→ Use Find Element again with elementType="textarea" or "*"

Other fixes:
1. Set clickFirst=true
2. Increase waitTimeout
3. Verify element is an input/textarea (not select or button!)
4. Check if element is visible and enabled
5. For Google search, use elementType="textarea" not "input"
```

### Click Not Working
```
Try:
1. Set scrollIntoView=true
2. Set forceClick=true
3. Increase waitTimeout
4. Check if element is clickable
```

### Dropdown Not Working
```
Make sure you're using:
1. Find Element with type="select"
2. Select Option tool (NOT Type Into)
3. Correct selection method (value/text/index)
```

## 📚 Tool Parameters Reference

### Launch Browser
- `navigateUrl`: URL to visit (default: https://google.com)

### Find Element
- `CDP_URL`: Required, from Launch Browser
- `description`: Natural language description
- `elementType`: See element types table above

### Type Into
- `CDP_URL`: Required
- `CSS_Selector`: From Find Element
- `Text_to_Type`: Text to enter
- Options: `clearFirst`, `pressEnter`, `clickFirst`, `typingDelay`

### Click Element
- `CDP_URL`: Required
- `CSS_Selector`: From Find Element
- Options: `scrollIntoView`, `forceClick`, `waitForNavigation`

### Get Select Options
- `CDP_URL`: Required
- `CSS_Selector`: From Find Element (must be select element)

### Select Option
- `CDP_URL`: Required
- `CSS_Selector`: From Find Element (must be select element)
- `selectionMethod`: "value", "text", or "index"
- `optionValue`: The value/text/index to select

### Page Loaded
- `CDP_URL`: Required
- `waitUntil`: "load", "domcontentloaded", or "networkidle"

### Get Text
- `CDP_URL`: Required
- `CSS_Selector`: From Find Element

### Take Screenshot
- `CDP_URL`: Required
- `selector`: Optional (empty for full page)

### Close Browser
- `CDP_URL`: Required

---

**Remember**: 
- CDP URL is the connection string to your browser
- Always get it from Launch Browser
- Pass it to EVERY other tool
- Close browser when done!

