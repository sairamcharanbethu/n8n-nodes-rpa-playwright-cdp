# RPA Tools Quick Reference Card

## Tool Calling Template

```
Every tool (except Launch Browser) requires CDP URL!

Launch Browser → Returns: { cdpUrl: "ws://..." }
↓ Save CDP URL ↓
All other tools → Require: cdpUrl parameter
```

## Tools at a Glance

| Tool | Use Case | Required Params | Returns |
|------|----------|----------------|---------|
| **Launch Browser** | Start automation | seleniumHubUrl, navigateUrl | **cdpUrl** (save this!) |
| **Navigate** | Change page | cdpUrl, navigateUrl | Session with new URL |
| **Close Browser** | Clean up | cdpUrl | Cleanup confirmation |
| **Find Element By Description** | Find by AI | cdpUrl, description, elementType | **CSS selector** |
| **Type Into Element** | Fill forms | cdpUrl, selector, text | Typing result |
| **Click Element** | Click anything | cdpUrl, selector | Click result |
| **Get Text** | Read text | cdpUrl, selector | Text content |
| **Get Table** | Scrape tables | cdpUrl, selector | JSON array |
| **Take Screenshot** | Capture image | cdpUrl | Base64 image |
| **Page Loaded** | Wait for ready | cdpUrl, waitUntil | Load status |
| **Element Exists** | Check presence | cdpUrl, selector | Boolean |
| **Download File** | Get files | cdpUrl, selector | Binary + metadata |

## Common Workflows

### 🔍 Search & Extract
```
1. Launch Browser(navigateUrl: "google.com") → cdpUrl
2. Page Loaded(cdpUrl, "load")
3. Type Into Element(cdpUrl, "input[name='q']", "search term")
4. Click Element(cdpUrl, "input[value='Google Search']")
5. Page Loaded(cdpUrl, "networkidle")
6. Get Text(cdpUrl, "h3")
7. Close Browser(cdpUrl)
```

### 📝 Form Filling
```
1. Launch Browser(navigateUrl: "site.com/form") → cdpUrl
2. Page Loaded(cdpUrl, "domcontentloaded")
3. Find Element By Description(cdpUrl, "email field", "input") → selector1
4. Type Into Element(cdpUrl, selector1, "user@email.com")
5. Find Element By Description(cdpUrl, "submit button", "button") → selector2
6. Click Element(cdpUrl, selector2, waitForNavigation: true)
7. Screenshot(cdpUrl) for verification
8. Close Browser(cdpUrl)
```

### 📊 Data Scraping
```
1. Launch Browser(navigateUrl: "data-site.com") → cdpUrl
2. Page Loaded(cdpUrl, "networkidle")
3. Get Table(cdpUrl, "table.data", hasHeader: true) → data[]
4. Close Browser(cdpUrl)
5. Return data
```

### 🔐 Login Automation
```
1. Launch Browser(navigateUrl: "site.com/login") → cdpUrl
2. Page Loaded(cdpUrl)
3. Element Exists(cdpUrl, "#username") → check if login form ready
4. Type Into Element(cdpUrl, "#username", "user")
5. Type Into Element(cdpUrl, "#password", "pass")
6. Click Element(cdpUrl, "button[type='submit']", waitForNavigation: true)
7. Page Loaded(cdpUrl)
8. Get Text(cdpUrl, ".welcome-message") → verify success
9. Close Browser(cdpUrl)
```

## Decision Tree

```
Need to automate browser task?
│
├─ YES → Start with Launch Browser
│         ↓
│         Save CDP URL (critical!)
│         ↓
│         Know exact CSS selector?
│         ├─ YES → Use selector directly in tools
│         └─ NO → Use Find Element By Description first
│                 ↓
│                 Get selector from AI
│                 ↓
│                 Use selector in Type/Click/GetText tools
│         ↓
│         Task complete?
│         └─ YES → Close Browser (required!)
│
└─ NO → Use other n8n nodes
```

## Parameter Quick Reference

### Launch Browser
```javascript
{
  seleniumHubUrl: "http://selenium-hub:4444",
  profileDir: "/home/seluser/chrome-profiles/default",
  navigateUrl: "https://example.com",
  browserArgs: "",  // optional: "--headless,--disable-gpu"
  windowSize: "1920,1080"
}
// Returns: { cdpUrl: "ws://...", sessionId: "...", ... }
```

### Find Element By Description
```javascript
{
  cdpUrl: "<from Launch Browser>",
  description: "blue submit button in the login form",
  elementType: "button",  // input|button|select|checkbox|radio|textarea|div|a|img|span|p|h1-h6|table|*
  aiProvider: "openai",   // openai|openrouter|gemini
  openAiModel: "gpt-4o",  // or gpt-4o-mini
  maxAttempts: 3
}
// Returns: { selector: "button#submit", confidence: 0.95, ... }
```

### Type Into Element
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "input#email",
  text: "user@example.com",
  waitTimeout: 5000,
  clearFirst: true,        // clear existing text
  typingDelay: 0,          // ms between keystrokes
  clickFirst: false,       // click to focus first
  pressEnter: false,       // press Enter after typing
  pressTab: false,         // press Tab after typing
  waitAfter: 0             // wait ms after typing
}
```

### Click Element
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "button#submit",
  clickType: "single",           // single|double|right
  waitTimeout: 5000,
  scrollIntoView: true,          // scroll element into view
  forceClick: false,             // click even if obscured
  waitBefore: 0,                 // wait before click
  waitAfter: 0,                  // wait after click
  waitForNavigation: false,      // wait for page navigation
  navigationTimeout: 30000,
  clickPosition: "center"        // center|top-left|top-right|bottom-left|bottom-right
}
```

### Get Text
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "h1.title",
  trimWhitespace: true
}
// Returns: { text: "Page Title", ... }
```

### Get Table
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "table.data-table",
  hasHeader: true,
  waitTimeout: 5000
}
// Returns: { rows: [{col1: "val1", col2: "val2"}, ...] }
```

### Take Screenshot
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "",              // empty for full page, or specific element
  format: "png",             // png|jpeg
  quality: 80,               // 0-100 for jpeg
  base64: true               // return base64 encoded
}
// Returns: { data: "base64string...", ... }
```

### Page Loaded
```javascript
{
  cdpUrl: "<from Launch Browser>",
  waitUntil: "load",         // load|domcontentloaded|networkidle
  timeout: 10000
}
// load = fully loaded
// domcontentloaded = DOM ready (faster)
// networkidle = no network activity
```

### Element Exists
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "#login-form",
  waitTimeout: 1000
}
// Returns: { exists: true/false }
```

### Download File
```javascript
{
  cdpUrl: "<from Launch Browser>",
  selector: "a.download-link",
  waitTimeout: 5000,
  downloadTimeout: 30000,
  deleteAfter: true          // delete temp file after
}
// Returns: { filePath: "...", mimeType: "...", binary data }
```

### Navigate
```javascript
{
  cdpUrl: "<from Launch Browser>",
  navigateUrl: "https://example.com/next-page"
}
```

### Close Browser
```javascript
{
  cdpUrl: "<from Launch Browser>"
}
```

## CSS Selector Examples

| Element Type | Selector Example | Description |
|-------------|------------------|-------------|
| By ID | `#username` | Element with id="username" |
| By Class | `.btn-primary` | Element with class="btn-primary" |
| By Name | `input[name="email"]` | Input with name attribute |
| By Type | `input[type="password"]` | Input of specific type |
| By Text | `button:has-text("Submit")` | Button containing text (Playwright) |
| Nested | `.form input#email` | Input inside form class |
| First Match | `button:first-of-type` | First button |
| Nth Child | `tr:nth-child(2)` | Second table row |
| Attribute | `a[href*="login"]` | Link with "login" in href |

## Common Mistakes to Avoid

❌ **Forgetting CDP URL**
```javascript
// WRONG
Click Element({ selector: "button" })  // Missing cdpUrl!

// CORRECT
Click Element({ cdpUrl: savedCdpUrl, selector: "button" })
```

❌ **Not saving CDP URL**
```javascript
// WRONG
Launch Browser(...)
// Didn't save the result!

// CORRECT
const result = Launch Browser(...)
const cdpUrl = result.cdpUrl  // Save this!
```

❌ **Not waiting for page**
```javascript
// WRONG (elements might not exist yet)
Launch Browser(...)
Click Element(...)

// CORRECT
Launch Browser(...)
Page Loaded(...)
Click Element(...)
```

❌ **Forgetting to close**
```javascript
// WRONG (resource leak!)
Launch Browser(...)
... do stuff ...
// No Close Browser!

// CORRECT
Launch Browser(...)
... do stuff ...
Close Browser(...)  // Always close!
```

❌ **Using wrong selector format**
```javascript
// WRONG (XPath not supported)
selector: "//button[@id='submit']"

// CORRECT (CSS selector)
selector: "button#submit"
```

## Tips & Tricks

💡 **Fast Element Finding**
- Know the selector? Use it directly
- Don't know? Use Find Element By Description

💡 **Reliable Clicking**
- Element not visible? Use `scrollIntoView: true`
- Element obscured? Use `forceClick: true`
- Page navigates after click? Use `waitForNavigation: true`

💡 **Smart Waiting**
- Fast page? `domcontentloaded`
- AJAX heavy? `networkidle`
- Standard page? `load`

💡 **Debugging**
- Something wrong? Take a screenshot to see current state
- Element not found? Check if page is loaded
- Timing issues? Increase timeouts

💡 **Performance**
- Use `domcontentloaded` instead of `networkidle` when possible
- Set `typingDelay: 0` for fast typing
- Don't take screenshots unless needed

## Error Messages & Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "CDP URL not found" | Forgot to launch browser | Call Launch Browser first |
| "Selector not found" | Element doesn't exist | Check selector, wait for page, use Find Element |
| "Timeout waiting for selector" | Element slow to appear | Increase waitTimeout |
| "Element not visible" | Element off-screen | Use scrollIntoView: true |
| "Navigation timeout" | Page slow to load | Increase navigationTimeout or use different waitUntil |

## Need Help?

1. Check if CDP URL is passed correctly
2. Verify page is loaded before interacting
3. Take screenshot to see current page state
4. Increase timeouts if elements are slow
5. Use Find Element By Description if selector is wrong
6. Read full documentation in AI-AGENT-WORKFLOW-GUIDE.md

---

**Remember**: Launch Browser → Get CDP URL → Use in all tools → Close Browser!

