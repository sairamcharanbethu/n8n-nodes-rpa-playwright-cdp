# AI Agent RPA Workflow Guide

## Overview

All RPA nodes in this package now support `usableAsTool: true`, which means they can be used as tools by n8n's AI Agent node. This enables AI-powered browser automation where the agent can intelligently decide which tools to use based on natural language instructions.

## Available Tools

### Browser Control Tools

1. **Launch Browser** (`CUSTOM.launchBrowser`)
   - Launches a Chrome browser session via Selenium Grid
   - Returns session info including CDP URL for subsequent operations
   - Parameters: Selenium Hub URL, Profile Directory, Navigate URL, Browser Args, Window Size

2. **Navigate** (`CUSTOM.navigate`)
   - Navigates to a URL using an existing browser session
   - Parameters: Navigate URL

3. **Close Browser** (`CUSTOM.closeBrowser`)
   - Closes the browser session
   - Parameters: CDP URL

### Element Interaction Tools

4. **Find Element By Description (AI)** (`CUSTOM.findElementByDescription`)
   - Uses LLM to find CSS selectors based on natural language descriptions
   - Parameters: CDP URL, Element Description, Element Type, AI Provider, Model, Max Attempts

5. **Type Into Element** (`CUSTOM.typeInto`)
   - Types text into an element found by CSS selector
   - Parameters: CDP URL, CSS Selector, Text, Clear First, Typing Delay, Press Enter/Tab options

6. **Click Element** (`CUSTOM.click`)
   - Clicks an element specified by CSS selector
   - Parameters: CDP URL, CSS Selector, Click Type (single/double/right), Wait options, Force Click, Navigation options

7. **Get Text** (`CUSTOM.getText`)
   - Extracts text content from an element
   - Parameters: CDP URL, CSS Selector, Trim Whitespace

8. **Take Screenshot** (`CUSTOM.screenshot`)
   - Captures screenshot of full page or specific element
   - Parameters: CDP URL, CSS Selector (optional), Format (PNG/JPEG), Quality, Base64 Output

### Validation & Data Extraction Tools

9. **Page Loaded** (`CUSTOM.pageLoaded`)
   - Waits for page to reach specified ready state
   - Parameters: CDP URL, Wait Strategy (load/domcontentloaded/networkidle), Timeout

10. **Element Exists** (`CUSTOM.elementExists`)
    - Checks if an element exists on the page
    - Parameters: CDP URL, CSS Selector, Timeout

11. **Get Table** (`CUSTOM.getTable`)
    - Extracts HTML table as structured JSON
    - Parameters: CDP URL, Table Selector, Has Header Row, Wait Timeout

12. **Download File** (`CUSTOM.downloadFile`)
    - Triggers file download and stores as n8n binary
    - Parameters: Trigger Selector, Wait Timeout, Download Timeout, Delete After

## Workflow Setup

### Import the Workflow

1. Copy the contents of `workflow-rpa-ai-agent.json`
2. In n8n, go to **Workflows** → **Import from File** or **Import from URL**
3. Paste the JSON content
4. The workflow will create:
   - A Chat Trigger node to receive messages
   - An AI Agent node configured with all RPA tools
   - All 13 RPA tool nodes connected to the AI Agent

### Configure the AI Agent

1. **Add LLM Connection**: Connect an OpenAI, Anthropic, or other LLM node to the AI Agent
2. **Set System Prompt** (recommended):

```
You are an RPA automation assistant. You have access to browser automation tools.

When automating browser tasks:
1. Always start by launching a browser
2. Use Find Element By Description when you need to locate elements by natural language
3. Use direct CSS selectors when you know the exact element location
4. Take screenshots to verify actions when needed
5. Always close the browser when done

Available tools:
- Launch Browser: Start a new browser session
- Navigate: Go to a URL
- Find Element By Description: Use AI to find elements by description
- Type Into Element: Enter text into input fields
- Click Element: Click buttons, links, or any clickable element
- Get Text: Extract text from elements
- Take Screenshot: Capture the page or element
- Page Loaded: Wait for page to be ready
- Element Exists: Check if an element is present
- Get Table: Extract table data as JSON
- Download File: Download files from the page
- Close Browser: Clean up the browser session

Remember to pass the CDP URL from Launch Browser to all subsequent tool calls.
```

### Configure Prerequisites

Before using the workflow:

1. **Selenium Grid Setup**: Ensure you have Selenium Grid running (see docker-compose.yml)
2. **AI Provider Credentials**: Add credentials for OpenAI/OpenRouter/Gemini if using Find Element By Description
3. **LLM Configuration**: Connect and configure your preferred LLM for the AI Agent

## Example Usage

### Example 1: Simple Google Search

**User Message:**
```
Search Google for "n8n automation" and tell me the first result title
```

**AI Agent Actions:**
1. Launches browser with Google.com
2. Finds the search input field
3. Types "n8n automation"
4. Clicks the search button
5. Waits for page to load
6. Gets text from the first result title
7. Closes browser
8. Returns the result

### Example 2: Form Filling

**User Message:**
```
Go to example.com/signup and fill in the form with name "John Doe" and email "john@example.com"
```

**AI Agent Actions:**
1. Launches browser
2. Navigates to example.com/signup
3. Finds name input field (using AI description or CSS)
4. Types "John Doe"
5. Finds email input field
6. Types "john@example.com"
7. Takes screenshot for verification
8. Finds and clicks submit button
9. Closes browser

### Example 3: Data Extraction

**User Message:**
```
Go to example.com/products and extract the pricing table
```

**AI Agent Actions:**
1. Launches browser
2. Navigates to example.com/products
3. Waits for page to load
4. Uses Get Table to extract the pricing table
5. Returns structured JSON data
6. Closes browser

## Best Practices

### Session Management

- The **CDP URL** returned by Launch Browser must be passed to all subsequent tool calls
- Always close the browser at the end of automation to free resources
- Use separate browser sessions for parallel automation tasks

### Element Location Strategies

1. **AI-Powered (Recommended for reliability)**:
   - Use Find Element By Description with natural language
   - Example: "blue submit button in the login form"

2. **Direct CSS Selectors (Faster when known)**:
   - Use when you know the exact selector
   - Example: `#submit-btn`, `.login-form button[type="submit"]`

### Error Handling

- The AI Agent will automatically retry failed actions
- Each tool returns success/error status in the response
- Use Element Exists to check for elements before interacting
- Use Page Loaded to ensure page is ready before actions

### Performance Optimization

- Use Page Loaded with 'domcontentloaded' instead of 'networkidle' when possible
- Minimize screenshot usage (only when verification is needed)
- Use Element Exists for quick checks instead of waiting for selectors

## Advanced Configuration

### Custom System Prompts

Customize the AI Agent's behavior by modifying the system prompt:

- Add domain-specific instructions
- Define custom workflows or patterns
- Add safety constraints or validation rules

### Tool Parameter Defaults

Modify the tool nodes in the workflow to set better defaults for your use case:

- Selenium Hub URL
- Default timeouts
- Browser arguments
- Window sizes

### Parallel Automation

Create multiple AI Agent workflows for parallel browser automation:

1. Clone the workflow
2. Use different Chat Trigger webhook IDs
3. Each agent maintains its own browser session
4. Coordinate via n8n's workflow orchestration

## Troubleshooting

### "CDP URL not found" Error

- Ensure Launch Browser was called first
- Verify the CDP URL is being passed correctly to subsequent tools
- Check that Selenium Grid is running and accessible

### "Element not found" Errors

- Increase wait timeouts in tool parameters
- Use Page Loaded before element interactions
- Try Find Element By Description for dynamic elements
- Verify the page has fully loaded

### Browser Session Issues

- Ensure Selenium Grid has available browser instances
- Check browser profile directory permissions
- Verify network connectivity to Selenium Hub
- Close unused browser sessions promptly

## Additional Resources

- **n8n AI Agent Documentation**: [n8n.io/docs](https://docs.n8n.io)
- **Playwright Documentation**: [playwright.dev](https://playwright.dev)
- **Selenium Grid Setup**: See `docker-compose.yml` in this repository

## Support

For issues or questions:
1. Check the n8n community forum
2. Review Playwright documentation for selector strategies
3. Examine the node source code in `nodes/` directory

