import playwright, { Browser } from 'playwright';
import http, { RequestOptions, IncomingMessage } from 'http';
import { URL } from 'url';
import { SessionObject } from './SessionObject';

export interface LaunchBrowserParams {
  seleniumHubUrl: string;
  profileDir: string;
  navigateUrl: string;
  ignoreCertificateErrors?: boolean;
  browserArgs?: string[];
  windowSize?: string; // e.g. "1920,1080"
}

function parseUrl(url: string): URL {
  return new URL(url);
}

function reqJSON(
  method: string,
  url: string,
  body?: any
): Promise<{ status: number; data: any; raw?: string }> {
  return new Promise((resolve, reject) => {
    const urlObj = parseUrl(url);
    const options: RequestOptions = {
      method,
      hostname: urlObj.hostname,
      port: parseInt(urlObj.port) || (urlObj.protocol === 'https:' ? 443 : 80),
      path: urlObj.pathname,
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000,
    };

    const req = http.request(options, (res: IncomingMessage) => {
      let data = '';
      res.on('data', (chunk: Buffer) => {
        data += chunk.toString();
      });
      res.on('end', () => {
        try {
          resolve({
            status: res.statusCode || 500,
            data: data ? JSON.parse(data) : {},
          });
        } catch (e) {
          resolve({ status: res.statusCode || 500, data: {}, raw: data });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('Request timeout')));

    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

export async function launchGoogleSession(params: LaunchBrowserParams): Promise<SessionObject> {
  let sessionId: string | null = null;
  let browser: Browser | null = null;

  try {
    // Anti-detection browser arguments
    const browserArgs = [
      `--user-data-dir=${params.profileDir}`,
      '--profile-directory=Default',
      '--no-sandbox',
      '--disable-dev-shm-usage',
      ...(params.ignoreCertificateErrors ? ['--ignore-certificate-errors'] : []),
      ...(params.windowSize ? [`--window-size=${params.windowSize}`] : []),
      // Disable automation flags
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      // Additional stealth settings
      '--disable-web-security',
      '--disable-features=VizDisplayCompositor',
      '--disable-gpu',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-infobars',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--disable-background-timer-throttling',
      '--disable-breakpad',
      '--disable-client-side-phishing-detection',
      '--disable-component-update',
      '--disable-default-apps',
      '--disable-hang-monitor',
      '--disable-popup-blocking',
      '--disable-prompt-on-repost',
      '--disable-sync',
      '--disable-translate',
      '--metrics-recording-only',
      '--safebrowsing-disable-auto-update',
      '--enable-automation=false',
      '--password-store=basic',
      '--use-mock-keychain',
      ...(params.browserArgs || []),
      '--remote-debugging-port=0',
    ];

    const sessionResp = await reqJSON('POST', `${params.seleniumHubUrl}/session`, {
      capabilities: {
        alwaysMatch: {
          browserName: 'chrome',
          'goog:chromeOptions': {
            args: browserArgs,
            excludeSwitches: ['enable-automation', 'enable-logging'],
            useAutomationExtension: false,
          },
        },
        firstMatch: [{}],
      },
    });

    sessionId = sessionResp.data.value?.sessionId;
    const capabilities = sessionResp.data.value?.capabilities || {};
    const cdpUrl = capabilities['se:cdp'] as string;

    browser = await playwright.chromium.connectOverCDP(cdpUrl);
  	const context = browser.contexts()[0] || (await browser.newContext());
   	const page = context.pages().length > 0 ? context.pages()[0] : await context.newPage();

    // Additional stealth configurations via CDP
    const client = await context.newCDPSession(page);
    
    // Override navigator.webdriver
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });
    });

    // Set realistic user agent
    await page.evaluate(() => {
      Object.defineProperty(navigator, 'platform', {
        get: () => 'Win32',
      });
      Object.defineProperty(navigator, 'vendor', {
        get: () => 'Google Inc.',
      });
      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
      });
    });

    // Set permissions
    await context.grantPermissions(['geolocation', 'notifications']);

    await page.goto(params.navigateUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 15000,
    });

    const title = await page.title();
    await browser.close();

    return {
      success: true,
      sessionId: sessionId || '',
      cdpUrl: cdpUrl || '',
      seleniumHubUrl: params.seleniumHubUrl,
      pageTitle: title,
      currentUrl: page.url(),
      step: 'launch',
      message: 'Website session launched successfully',
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    if (browser) await browser.close().catch(() => {});
    if (sessionId) {
      await reqJSON('DELETE', `${params.seleniumHubUrl}/session/${sessionId}`).catch(() => {});
    }
    return {
      success: false,
      error: error.message || String(error),
      step: 'launch',
      timestamp: new Date().toISOString(),
      sessionId: sessionId || '',
      cdpUrl: '',
    };
  }
}

export async function navigateWithSession(
  session: SessionObject,
  navigateUrl: string
): Promise<SessionObject> {
  let browser: Browser | null = null;
  try {
    browser = await playwright.chromium.connectOverCDP(session.cdpUrl);
    const context = browser.contexts()[0] || (await browser.newContext());
    const page = context.pages().length ? context.pages()[0] : await context.newPage();

    // Apply stealth scripts
    await page.addInitScript(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });
    });

    await page.goto(navigateUrl, {
      waitUntil: 'networkidle',
      timeout: 30000,
    });

    const title = await page.title();
    await browser.close();

    return {
      ...session,
      currentUrl: page.url(),
      pageTitle: title,
      success: true,
      step: 'navigate',
      message: `Navigation to ${navigateUrl} successful`,
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    if (browser) await browser.close().catch(() => {});
    return {
      ...session,
      success: false,
      error: error.message || String(error),
      step: 'navigate',
      timestamp: new Date().toISOString(),
    };
  }
}

export async function closeSession(session: SessionObject): Promise<SessionObject> {
  try {
    if (!session.seleniumHubUrl || !session.sessionId) {
      throw new Error('Missing seleniumHubUrl or sessionId. These are required to close the session.');
    }

    // Ensure seleniumHubUrl doesn't have trailing slash
    const hubUrl = session.seleniumHubUrl.replace(/\/$/, '');
    const closeUrl = `${hubUrl}/session/${session.sessionId}`;

    await reqJSON('DELETE', closeUrl);
    return {
      ...session,
      success: true,
      step: 'close',
      message: 'Session closed successfully',
      timestamp: new Date().toISOString(),
    };
  } catch (error: any) {
    return {
      ...session,
      success: false,
      error: error.message || String(error),
      step: 'close',
      timestamp: new Date().toISOString(),
    };
  }
}
