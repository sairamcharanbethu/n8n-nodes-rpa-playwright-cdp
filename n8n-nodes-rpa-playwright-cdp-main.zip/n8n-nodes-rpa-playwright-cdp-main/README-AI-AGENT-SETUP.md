# AI Agent Setup Guide for RPA Browser Automation

## 🚀 Quick Start (3 Steps)

### Step 1: Import the Workflow
1. Open n8n
2. Go to **Workflows** → **Import from File**
3. Import `workflow-rpa-ai-agent.json`
4. The workflow includes all 13 RPA tools connected to an AI Agent

### Step 2: Add System Prompt
1. Open the **AI Agent** node in the imported workflow
2. Find the **System Message** field
3. Copy the entire contents of `system-prompt-ready-to-use.txt`
4. Paste into the System Message field
5. Save the node

### Step 3: Configure & Test
1. Connect an LLM node (OpenAI, Anthropic, etc.) to the AI Agent
2. Ensure Selenium Grid is running (see docker-compose.yml)
3. Test with: "Search Google for n8n automation"

**That's it!** Your AI Agent can now automate browsers! 🎉

---

## 📚 Documentation Files

| File | Purpose | When to Use |
|------|---------|-------------|
| **system-prompt-ready-to-use.txt** | Ready-to-paste system prompt | Copy directly into n8n AI Agent node |
| **AI-AGENT-SYSTEM-PROMPT.md** | Detailed system prompt with explanations | Learn how the system prompt works, customize it |
| **QUICK-REFERENCE-TOOLS.md** | Tool parameters & examples | Quick lookup while developing workflows |
| **AI-AGENT-WORKFLOW-GUIDE.md** | Complete usage guide | Learn best practices, patterns, troubleshooting |
| **CHANGELOG-AI-TOOLS.md** | What changed in this update | Understand modifications made |
| **workflow-rpa-ai-agent.json** | Complete n8n workflow | Import into n8n to get started |

---

## 🎯 What You Get

### All 13 RPA Tools Available to AI Agent

**Browser Control (3 tools)**
- 🚀 Launch Browser - Start automation
- 🧭 Navigate - Change pages
- 🛑 Close Browser - Clean up

**Element Interaction (4 tools)**
- 🔍 Find Element By Description - AI-powered element finding
- ⌨️ Type Into Element - Fill forms
- 🖱️ Click Element - Click anything
- 📖 Get Text - Extract text

**Data & Validation (5 tools)**
- 📊 Get Table - Extract tables as JSON
- 📸 Take Screenshot - Capture visuals
- ⏳ Page Loaded - Wait for readiness
- ✅ Element Exists - Check presence
- 📥 Download File - Capture downloads

---

## 💬 Example Conversations

### Example 1: Simple Search
```
User: Search Google for "n8n automation"

AI Agent: I'll search Google for "n8n automation" for you.

Step 1: Launching Chrome browser with Google...
✓ Browser launched, CDP URL obtained

Step 2: Waiting for page to load...
✓ Google homepage ready

Step 3: Finding search input...
✓ Found: input[name="q"]

Step 4: Typing "n8n automation"...
✓ Text entered

Step 5: Clicking search button...
✓ Search initiated

Step 6: Waiting for results...
✓ Results loaded

Step 7: Extracting top results...
✓ Results found:
1. n8n.io - Workflow Automation Tool
2. n8n Documentation - Getting Started
3. n8n GitHub Repository

Step 8: Closing browser...
✓ Browser closed

Task completed! Found 3 top results for "n8n automation".
```

### Example 2: Form Filling
```
User: Go to example.com/contact and fill in:
- Name: John Doe  
- Email: john@example.com
- Message: Hello!

AI Agent: I'll fill out the contact form on example.com.

Step 1: Launching browser and navigating to example.com/contact...
✓ Browser launched

Step 2: Waiting for page to load...
✓ Contact form page ready

Step 3: Using AI to find form fields...
✓ Found name field: input#contact-name
✓ Found email field: input#contact-email  
✓ Found message field: textarea#message

Step 4: Filling in form data...
✓ Name: "John Doe" entered
✓ Email: "john@example.com" entered
✓ Message: "Hello!" entered

Step 5: Taking screenshot for verification...
✓ Screenshot captured

Step 6: Finding submit button...
✓ Found: button[type="submit"]

Step 7: Submitting form...
✓ Form submitted successfully

Step 8: Verifying submission...
✓ Success message detected: "Thank you for contacting us!"

Step 9: Closing browser...
✓ Browser closed

Contact form filled and submitted successfully! 
I've captured a screenshot showing the completed form.
```

### Example 3: Data Extraction
```
User: Extract the pricing table from example.com/pricing

AI Agent: I'll extract the pricing table data for you.

Step 1: Launching browser and navigating to example.com/pricing...
✓ Browser launched

Step 2: Waiting for page to load completely...
✓ Pricing page ready

Step 3: Finding pricing table...
✓ Found table: table.pricing-table

Step 4: Extracting table data...
✓ Extracted 3 pricing plans:

Plan 1:
- Name: Basic
- Price: $9/month
- Features: 100 workflows, Email support

Plan 2:
- Name: Pro
- Price: $29/month  
- Features: Unlimited workflows, Priority support, Advanced features

Plan 3:
- Name: Enterprise
- Price: Custom
- Features: Everything + Dedicated support, SLA

Step 5: Closing browser...
✓ Browser closed

Successfully extracted pricing data for 3 plans!
```

---

## 🔧 Configuration Checklist

### Before First Use

- [ ] Selenium Grid is running
  - Run: `docker-compose up -d selenium-hub chrome`
  - Verify: http://localhost:4444

- [ ] n8n has the custom nodes installed
  - Should see all CUSTOM.* nodes in node panel
  - Rebuild with: `npm run build`

- [ ] LLM is connected to AI Agent
  - OpenAI, Anthropic, or other LLM node
  - API credentials configured

- [ ] System prompt is added to AI Agent
  - Copy from `system-prompt-ready-to-use.txt`
  - Paste into AI Agent "System Message" field

- [ ] (Optional) AI Provider credentials for Find Element tool
  - Add OpenAI/Gemini credentials
  - Configure in credentials panel

### Test Your Setup

1. **Basic Test**: "Search Google for test"
2. **Navigation Test**: "Go to example.com and tell me the page title"
3. **Interaction Test**: "Find the search box on google.com"
4. **Data Test**: "Get the text from the main heading on example.com"

---

## 🎨 Customizing the System Prompt

The system prompt in `system-prompt-ready-to-use.txt` can be customized:

### Add Domain-Specific Instructions
```
Additional Context:
- Our company website is: mycompany.com
- Standard login page is: /account/login
- Common task: Check inventory at /admin/inventory
```

### Add Safety Rules
```
Safety Rules:
- Never submit forms without explicit user confirmation
- Always verify URLs before navigation
- Take screenshots before sensitive operations
```

### Modify Response Style
```
Response Style:
- Be concise in step descriptions
- Always provide timestamps
- Include emoji for visual clarity
```

---

## 🐛 Troubleshooting

### Problem: "CDP URL not found"
**Solution**: Ensure Launch Browser is called first and CDP URL is saved

### Problem: "Element not found"
**Solution**: 
- Increase waitTimeout
- Use Page Loaded before interacting
- Try Find Element By Description for better results

### Problem: "Browser not launching"
**Solution**:
- Check Selenium Grid is running: `docker ps`
- Verify network connectivity to selenium-hub
- Check selenium-hub logs: `docker logs selenium-hub`

### Problem: AI doesn't pass CDP URL correctly
**Solution**:
- Emphasize in system prompt: "ALWAYS pass CDP URL"
- Check LLM is following instructions (may need better model)
- Review AI Agent execution log for tool calls

### Problem: Tools not appearing in AI Agent
**Solution**:
- Ensure all tool nodes have `usableAsTool: true`
- Verify nodes are connected with `ai_tool` connection type
- Rebuild project: `npm run build`
- Restart n8n

---

## 📖 Further Reading

### Learn More About:
- **Tool Usage**: See `QUICK-REFERENCE-TOOLS.md`
- **Best Practices**: See `AI-AGENT-WORKFLOW-GUIDE.md`
- **System Prompt Details**: See `AI-AGENT-SYSTEM-PROMPT.md`
- **Changes Made**: See `CHANGELOG-AI-TOOLS.md`

### n8n Resources:
- [n8n AI Agent Documentation](https://docs.n8n.io)
- [n8n Community Forum](https://community.n8n.io)
- [n8n GitHub](https://github.com/n8n-io/n8n)

### Playwright Resources:
- [Playwright Documentation](https://playwright.dev)
- [Playwright Selectors](https://playwright.dev/docs/selectors)
- [Playwright Best Practices](https://playwright.dev/docs/best-practices)

---

## 🚀 Next Steps

1. **Start Simple**: Test with basic searches and navigation
2. **Build Complexity**: Try form filling and data extraction
3. **Create Workflows**: Combine multiple operations
4. **Share**: Document your automation patterns
5. **Optimize**: Fine-tune timeouts and strategies for your use case

---

## 💡 Pro Tips

1. **Use Find Element By Description** for reliability on dynamic sites
2. **Always take screenshots** after critical actions for debugging
3. **Increase timeouts** for slow-loading pages (better than fixed delays)
4. **Test incrementally** - verify each step works before adding more
5. **Monitor CDP URLs** - ensure they're being passed correctly
6. **Close browsers** - always clean up to avoid resource leaks

---

## 🎯 Success Metrics

You'll know it's working when:
- ✅ AI Agent correctly launches browser first
- ✅ CDP URL is passed to all subsequent tools
- ✅ Elements are found reliably (directly or via AI)
- ✅ Actions complete without manual intervention
- ✅ Data is extracted accurately
- ✅ Browser is closed at the end

---

## 🆘 Need Help?

1. Check the [Quick Reference](QUICK-REFERENCE-TOOLS.md) for tool parameters
2. Review the [Workflow Guide](AI-AGENT-WORKFLOW-GUIDE.md) for patterns
3. Read the [System Prompt](AI-AGENT-SYSTEM-PROMPT.md) for behavior details
4. Check [Changelog](CHANGELOG-AI-TOOLS.md) for recent changes
5. Ask in n8n community forum with "RPA" and "AI Agent" tags

---

**Happy Automating! 🤖✨**

