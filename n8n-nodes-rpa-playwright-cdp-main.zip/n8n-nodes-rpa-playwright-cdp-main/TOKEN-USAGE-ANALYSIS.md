# Token Usage Analysis: 208k Tokens Issue

## Problem

You reported **208k tokens** being used for a simple task. This is extremely high and indicates a serious issue.

## Expected vs Actual

### Expected Token Usage (Simple Google Search)
```
System Prompt:            850 tokens
Find Element Call:      4,500 tokens (HTML)
  - AI Prompt:            150 tokens
  - HTML Chunk:         4,500 tokens
  - Response:             200 tokens
Type Into Call:            50 tokens
Chat Memory:            1,000 tokens
--------------------------------------
Total Expected:        ~6,500 tokens
```

### Actual Reported
```
Total: 208,000 tokens (32x higher!)
```

## Possible Causes

### 1. Multiple HTML Chunks Being Processed
**Most Likely Cause**

If FindElement processes multiple chunks with retries:
- 18KB HTML = 4,500 tokens
- 2 attempts × 3-4 chunks = 27,000 tokens per FindElement call
- If AI retries happen: multiply by retry count

**Calculation**:
```
Single FindElement with worst case:
- 4 chunks × 2 attempts = 8 AI calls
- 8 × 4,500 tokens = 36,000 tokens (just HTML!)
- Plus prompts: 8 × 150 = 1,200 tokens
- Plus responses: 8 × 200 = 1,600 tokens
Total: ~39,000 tokens for ONE FindElement call
```

If you have 5 FindElement calls: 5 × 39,000 = **195,000 tokens**!

### 2. Large HTML Pages
If pages have massive HTML (100KB+):
- Body HTML could be 100KB+ before chunking
- Even after chunking to 18KB, multiple chunks sent
- Each chunk = 4,500 tokens

### 3. Conversation History Accumulating
If chat memory isn't working:
- Previous interactions building up
- Each response adds to context
- Could reach 50,000+ tokens over long sessions

### 4. Multiple Tasks in One Session
If you're running multiple automation tasks:
- Each task adds tokens
- History accumulates
- 208k could be across 5-10 tasks

## Diagnosis Questions

To identify the exact cause, check:

1. **How many FindElement calls are you making?**
   - 1-2 calls: Problem is elsewhere
   - 5+ calls: This explains high usage

2. **What page are you automating?**
   - Google.com: Should be small (~20KB HTML)
   - Complex SPA: Could be 100KB+ HTML
   - Admin dashboard: Often huge HTML

3. **Are you seeing multiple retries?**
   - Check n8n execution logs
   - Look for "attempts" in FindElement output
   - If attempts > 1, retries are happening

4. **How long is your chat history?**
   - New chat: History should be small
   - Continuing conversation: Could have 20+ exchanges

## Recommended Solutions

### Immediate Fixes

#### 1. Reduce HTML Chunk Size Further
If pages are complex, reduce from 18KB to 12KB:

```typescript
// In FindElementByDescription.node.ts
bodyHTML = getRelevantHTMLByType(bodyHTML, elementType, 12000);  // Was 18000
const chunkSize = 12000;  // Was 18000
```

**Impact**: Reduces tokens per chunk from 4,500 to 3,000 (33% reduction)

#### 2. Limit Chunks Processed
Add a max chunks limit:

```typescript
// Process max 2 chunks instead of all
const htmlChunks: string[] = [];
for (let start = 0; start < Math.min(bodyHTML.length, chunkSize * 2); start += chunkSize) {
  htmlChunks.push(bodyHTML.slice(start, start + chunkSize));
}
```

**Impact**: Cap at 2 chunks max = max 16,000 tokens per FindElement

#### 3. Use Ollama for FindElement
Switch to local model (FREE):
- No token costs
- Faster (no network latency)
- Unlimited usage

**Impact**: Eliminates cloud token usage for FindElement entirely

#### 4. Clear Chat History Frequently
Add a step to clear memory after each task:
- Prevents unbounded growth
- Keeps context focused

### Strategic Solutions

#### 1. Skip FindElement When Possible
Add direct CSS selector option:
- If you know the selector, skip AI
- Saves all FindElement tokens
- Instant (no AI call needed)

**Example**: Instead of FindElement("search box"), use `textarea[name='q']` directly

#### 2. Cache Selectors
Store found selectors:
- First time: Use FindElement
- Subsequent times: Reuse cached selector
- Saves tokens on repeated tasks

#### 3. Pre-process HTML
Filter HTML before sending to AI:
- Remove non-interactive elements
- Keep only form elements
- Could reduce HTML by 80%

## Token Usage Breakdown Tool

To diagnose exactly where tokens are going, check n8n execution:

1. **Open n8n execution log**
2. **Look at each node's input/output**
3. **Check FindElement node specifically**:
   - How many "attempts"?
   - How many chunks processed?
   - What's the HTML size?

## Recommendations

### Short Term (Do Now)

1. **Switch to Ollama** for FindElement
   - Install Ollama: `curl -fsSL https://ollama.com/install.sh | sh`
   - Pull model: `ollama pull llama3.2`
   - Configure FindElement to use Ollama
   - **Result**: FREE + FAST element finding

2. **Reduce chunk size** to 12KB
   - Edit FindElementByDescription.node.ts
   - Change 18000 to 12000
   - **Result**: 33% token reduction

3. **Limit maxAttempts** to 1
   - Change default from 2 to 1
   - Trust first attempt
   - **Result**: 50% fewer AI calls

### Medium Term (This Week)

1. **Add direct selector option**
   - Skip AI when selector is known
   - Instant execution
   - **Result**: Near-zero tokens for known elements

2. **Implement selector caching**
   - Store selectors in workflow
   - Reuse across executions
   - **Result**: Only pay once per unique element

3. **Add HTML size reporting**
   - Log HTML size before processing
   - Identify problematic pages
   - **Result**: Visibility into token usage

### Long Term (This Month)

1. **Pre-train on common sites**
   - Google, Facebook, LinkedIn patterns
   - Store as templates
   - **Result**: Instant recognition

2. **Smart chunking**
   - Prioritize visible viewport HTML
   - Ignore hidden elements
   - **Result**: 60-80% smaller HTML

## Expected Results After Fixes

### With Ollama (Recommended)
```
Find Element: 0 tokens (local!)
Type Into: 50 tokens
System Prompt: 850 tokens
Memory: 1,000 tokens
--------------------------
Total: ~2,000 tokens (99% reduction!)
```

### With Reduced Chunks
```
Find Element: 3,000 tokens (was 4,500)
× 2 attempts = 6,000 tokens
× 2 elements = 12,000 tokens
System Prompt: 850 tokens
Memory: 1,000 tokens
--------------------------
Total: ~14,000 tokens (93% reduction from 208k)
```

### With Direct Selectors
```
Find Element: SKIPPED (0 tokens)
Type Into: 50 tokens
System Prompt: 850 tokens
Memory: 1,000 tokens
--------------------------
Total: ~2,000 tokens (99% reduction!)
```

## Action Items

**Priority 1 (Do First)**:
- [ ] Install Ollama
- [ ] Configure FindElement to use Ollama
- [ ] Test with your workflow

**Priority 2 (Quick Wins)**:
- [ ] Reduce chunk size to 12KB
- [ ] Set maxAttempts to 1
- [ ] Clear chat history between tasks

**Priority 3 (Optimization)**:
- [ ] Add direct selector option
- [ ] Implement caching
- [ ] Add HTML size logging

## Conclusion

**208k tokens is NOT normal** and indicates:
- Multiple FindElement calls with retries
- Large HTML pages being processed
- Possible conversation history buildup

**Solutions**:
1. **Use Ollama** (eliminates cloud token costs)
2. **Reduce chunk size** (33% savings)
3. **Add direct selector option** (skip AI entirely)

**Target**: Reduce from 208k → 2,000 tokens (99% reduction)

With these fixes, your simple task should use **~2,000 tokens instead of 208,000**!

