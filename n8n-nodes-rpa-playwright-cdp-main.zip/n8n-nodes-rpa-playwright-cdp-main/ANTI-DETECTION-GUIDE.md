# Anti-Detection Guide for Google Search & Web Automation

## Problem
When automating browsers with Playwright/Selenium, websites like Google can detect automation and show a "Robot page" or CAPTCHA verification.

## Solution Implemented

### ✅ Browser Stealth Features Added

The following anti-detection measures have been implemented in `utils/sessionManager.ts`:

#### 1. **Automation Flags Disabled**
```javascript
--disable-blink-features=AutomationControlled
--enable-automation=false
excludeSwitches: ['enable-automation', 'enable-logging']
useAutomationExtension: false
```

#### 2. **WebDriver Property Hidden**
```javascript
Object.defineProperty(navigator, 'webdriver', {
  get: () => undefined,
});
```

#### 3. **Navigator Properties Spoofed**
- Platform set to 'Win32'
- Vendor set to 'Google Inc.'
- Languages set to ['en-US', 'en']

#### 4. **Additional Chrome Flags**
- Disabled features that indicate automation
- Removed infobars and default browser checks
- Disabled background throttling
- Disabled phishing detection (automation indicator)
- Disabled component updates during session

## Usage

### Basic Setup
1. Launch browser with a **user profile directory** (crucial for persistence)
2. Navigate to your target URL
3. The stealth features are automatically applied

### Configuration in n8n

In your "Launch Browser" node:

- **Profile Directory**: `/home/seluser/chrome-profiles/n8n-demo`
  - This persists cookies, localStorage, and session data
  - Google will "remember" the browser as legitimate over time

- **Window Size**: `1920,1080`
  - Use realistic window sizes
  - Match common screen resolutions

- **Additional Browser Args**: (optional)
  - Add custom arguments if needed
  - Example: `--lang=en-US,--start-maximized`

## Additional Recommendations

### 1. **Use Persistent Profiles**
Always use the same profile directory for repeated Google searches. This allows:
- Cookie persistence
- Login session retention
- Building browser "reputation" with Google

### 2. **Add Random Delays**
Between actions, add delays to simulate human behavior:
```
Wait 2-5 seconds between searches
Wait 1-3 seconds before clicking
```

### 3. **Avoid Headless Mode**
If possible, run with a visible browser (`--headless=false`). Headless browsers are easier to detect.

### 4. **Rotate User Agents** (Advanced)
For different sessions, consider rotating user agents:
```
--user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
```

### 5. **Use Residential Proxies** (If Needed)
For heavy automation, use residential proxies instead of datacenter IPs:
- Google can detect datacenter IP ranges
- Residential IPs appear as regular users

### 6. **Limit Request Rate**
- Don't send too many requests in a short time
- Space out Google searches by at least 5-10 seconds
- Vary the timing (don't use exact intervals)

## Testing

### Quick Test
1. Launch browser with the updated code
2. Navigate to: `https://www.google.com/search?q=test`
3. Check if you see search results (not a CAPTCHA)

### Verify Stealth
Navigate to: `https://bot.sannysoft.com/`
- This site shows what automation indicators are visible
- All checks should be green/hidden

## Troubleshooting

### Still Getting Robot Page?

1. **Clear Profile Data**
   - Delete the profile directory
   - Start fresh with a new profile
   - Sometimes old profiles get flagged

2. **Check Your IP**
   - VPN/proxy IPs might be blacklisted
   - Try from a residential IP

3. **Reduce Frequency**
   - Wait longer between requests
   - Don't run multiple parallel sessions

4. **Manual Verification**
   - Sometimes you need to solve ONE CAPTCHA manually
   - After that, the profile is trusted

### Advanced: CDP Session Initialization

The code now uses CDP (Chrome DevTools Protocol) to inject stealth scripts before page load:
```javascript
await page.addInitScript(() => {
  Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined,
  });
});
```

This ensures the stealth properties are set BEFORE any website JavaScript runs.

## Success Metrics

After implementing these changes, you should see:
- ✅ No robot/CAPTCHA pages on Google Search
- ✅ Normal search results loading
- ✅ Ability to perform multiple searches in a session
- ✅ Profile persistence across browser restarts

## Notes

- These techniques are for **legitimate automation** purposes (testing, data collection, etc.)
- Always respect website Terms of Service and robots.txt
- Add appropriate delays to avoid overloading servers
- Some websites may still detect automation despite these measures

## Version History

- **v1.0** (2024-11-21): Initial anti-detection implementation
  - Added 30+ stealth browser arguments
  - Implemented navigator property spoofing
  - Added CDP-based script injection

