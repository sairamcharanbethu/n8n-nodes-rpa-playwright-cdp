# n8n Node Icon Generation Prompts

This document contains AI image generation prompts for all n8n RPA Playwright nodes.

**Recommended Settings:**
- Size: 512x512 or 1024x1024
- Format: PNG with transparency or SVG
- Style: Flat Design 2.0, minimalist
- AI Tools: DALL-E 3, Midjourney, Stable Diffusion, Leonardo.ai

---

## 🌐 Browser Nodes (3)

### Launch Browser
**Colors:** `#4FC3F7` (Light Blue), `#66BB6A` (Green)

**Basic Prompt:**
```
Minimalist flat icon of a web browser window opening with a green play button or rocket launching from it, simple geometric shapes, light blue and green gradient, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a web browser window opening with a green play button, professional software icon, clean geometric shapes, light blue (#4FC3F7) and green (#66BB6A) gradient, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Close Browser
**Colors:** `#EF5350` (Red), `#78909C` (Gray)

**Basic Prompt:**
```
Minimalist flat icon of a web browser window with a red X or close button, simple geometric shapes, red and gray colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a web browser window with a red X button, professional software icon, clean geometric shapes, red (#EF5350) and gray (#78909C) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Navigate
**Colors:** `#1E88E5` (Blue), `#7E57C2` (Purple)

**Basic Prompt:**
```
Minimalist flat icon of a compass needle or arrow pointing forward on a browser window, simple geometric shapes, blue and purple gradient, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a compass needle on a browser window, professional software icon, clean geometric shapes, blue (#1E88E5) and purple (#7E57C2) gradient, white background, 512x512, vector style, no text, flat design 2.0
```

---

## 🎯 Interaction Nodes (10)

### Click
**Colors:** `#FF9800` (Orange), `#FFC107` (Yellow)

**Basic Prompt:**
```
Minimalist flat icon of a cursor pointer clicking with radiating circles showing action, simple geometric shapes, orange and yellow colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a cursor pointer clicking with ripple effect, professional software icon, clean geometric shapes, orange (#FF9800) and yellow (#FFC107) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Type Into
**Colors:** `#26A69A` (Teal), `#42A5F5` (Blue)

**Basic Prompt:**
```
Minimalist flat icon of a keyboard or text input field with typing cursor blinking, simple geometric shapes, teal and blue colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a text input field with blinking cursor, professional software icon, clean geometric shapes, teal (#26A69A) and blue (#42A5F5) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Type Into Advanced
**Colors:** `#9C27B0` (Purple), `#5E35B1` (Deep Purple)

**Basic Prompt:**
```
Minimalist flat icon of a keyboard with stars or sparkles above it showing advanced features, simple geometric shapes, purple and blue gradient, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a keyboard with sparkles showing advanced features, professional software icon, clean geometric shapes, purple (#9C27B0) and blue (#5E35B1) gradient, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Find Element By Description
**Colors:** `#00BCD4` (Cyan), `#AB47BC` (Purple)

**Basic Prompt:**
```
Minimalist flat icon of a magnifying glass with AI brain or sparkles inside searching through webpage elements, simple geometric shapes, cyan and purple gradient, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a magnifying glass with AI sparkles searching webpage elements, professional software icon, clean geometric shapes, cyan (#00BCD4) and purple (#AB47BC) gradient, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Take Screenshot
**Colors:** `#EC407A` (Pink), `#BA68C8` (Purple)

**Basic Prompt:**
```
Minimalist flat icon of a camera lens or camera shutter button over a browser window, simple geometric shapes, pink and purple colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a camera shutter button over browser window, professional software icon, clean geometric shapes, pink (#EC407A) and purple (#BA68C8) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Get Text
**Colors:** `#66BB6A` (Green), `#42A5F5` (Blue)

**Basic Prompt:**
```
Minimalist flat icon of text lines being extracted from a document with an arrow pulling them out, simple geometric shapes, green and blue colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of text lines being extracted from document, professional software icon, clean geometric shapes, green (#66BB6A) and blue (#42A5F5) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Get Table
**Colors:** `#26A69A` (Emerald), `#00897B` (Teal)

**Basic Prompt:**
```
Minimalist flat icon of a spreadsheet grid or table with data rows being extracted, simple geometric shapes, emerald green colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a spreadsheet grid with data rows, professional software icon, clean geometric shapes, emerald green (#26A69A) and teal (#00897B) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Element Exists
**Colors:** `#66BB6A` (Green), `#90A4AE` (Gray)

**Basic Prompt:**
```
Minimalist flat icon of a checkbox with a magnifying glass checking for presence, simple geometric shapes, green and gray colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a checkbox with magnifying glass, professional software icon, clean geometric shapes, green (#66BB6A) and gray (#90A4AE) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Page Loaded
**Colors:** `#66BB6A` (Green), `#42A5F5` (Blue)

**Basic Prompt:**
```
Minimalist flat icon of a webpage with a green checkmark or loading circle completing, simple geometric shapes, green and blue colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a webpage with completion checkmark, professional software icon, clean geometric shapes, green (#66BB6A) and blue (#42A5F5) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Download File
**Colors:** `#1E88E5` (Blue), `#3949AB` (Indigo)

**Basic Prompt:**
```
Minimalist flat icon of a downward arrow into a folder or document being downloaded, simple geometric shapes, blue and indigo colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of downward arrow into folder, professional software icon, clean geometric shapes, blue (#1E88E5) and indigo (#3949AB) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

## 📋 Select/Dropdown Nodes (2)

### Get Select Options
**Colors:** `#FF9800` (Orange), `#FFA726` (Light Orange)

**Basic Prompt:**
```
Minimalist flat icon of a dropdown menu list showing multiple options, simple geometric shapes, orange and yellow colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a dropdown menu with multiple options, professional software icon, clean geometric shapes, orange (#FF9800) and yellow (#FFA726) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

### Select Option
**Colors:** `#42A5F5` (Blue), `#66BB6A` (Green)

**Basic Prompt:**
```
Minimalist flat icon of a dropdown menu with one item being selected with a checkmark, simple geometric shapes, blue and green colors, white background, 512x512, vector style, no text
```

**Enhanced Prompt:**
```
Modern UI icon design, minimalist flat icon of a dropdown menu with selected item and checkmark, professional software icon, clean geometric shapes, blue (#42A5F5) and green (#66BB6A) colors, white background, 512x512, vector style, no text, flat design 2.0
```

---

## 🎨 Generation Tips

### For Best Results:
1. **Use "Enhanced" prompts** for production-quality icons
2. **Generate at 1024x1024** then downscale to 512x512 for better quality
3. **Request transparent background** if your AI tool supports it
4. **Generate 3-5 variations** and pick the best one
5. **Post-process** in tools like Figma or Photoshop to ensure consistency

### AI Tool Recommendations:
- **DALL-E 3** (via ChatGPT Plus): Best for following detailed prompts
- **Midjourney v6**: Best for artistic, high-quality icons
- **Stable Diffusion XL**: Best for local generation and customization
- **Leonardo.ai**: Best for consistent style across multiple icons

### n8n Icon Requirements:
- File format: PNG with transparency (24-bit)
- Size: 60x60 pixels minimum, but generate at 512x512 and resize
- File naming: `nodeName.svg` or `nodeName.png`
- Location: `nodes/[NodeName]/icon.png` or use base64 in node definition

---

## 📊 Quick Reference

| Node Name | Category | Primary Color | Icon Concept |
|-----------|----------|---------------|--------------|
| Launch Browser | Browser | #4FC3F7 | Browser + Play/Rocket |
| Close Browser | Browser | #EF5350 | Browser + X |
| Navigate | Browser | #1E88E5 | Compass/Arrow |
| Click | Interaction | #FF9800 | Cursor + Ripple |
| Type Into | Interaction | #26A69A | Input + Cursor |
| Type Into Advanced | Interaction | #9C27B0 | Keyboard + Sparkles |
| Find Element | Interaction | #00BCD4 | Magnifier + AI |
| Take Screenshot | Interaction | #EC407A | Camera + Browser |
| Get Text | Interaction | #66BB6A | Text Extraction |
| Get Table | Interaction | #26A69A | Spreadsheet Grid |
| Element Exists | Interaction | #66BB6A | Checkbox + Magnifier |
| Page Loaded | Interaction | #66BB6A | Page + Checkmark |
| Download File | Interaction | #1E88E5 | Arrow + Folder |
| Get Select Options | Select | #FF9800 | Dropdown List |
| Select Option | Select | #42A5F5 | Dropdown + Check |

---

**Total Nodes:** 15  
**Generated:** 2025-11-21  
**Version:** 1.0

