import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';

// Type declarations for DOM elements
declare global {
  interface HTMLSelectElement {
    value: string;
    options: HTMLOptionElement[];
    selectedIndex: number;
  }
  interface HTMLOptionElement {
    value: string;
    text: string;
    selected: boolean;
    disabled: boolean;
  }
  interface Element {
    tagName: string;
  }
}

export class GetSelectOptions implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Get Select Options',
    name: 'getSelectOptions',
    icon: 'file:Get Select Options.png',
    group: ['transform'],
    version: 1,
    description: 'Gets all available options from a select/dropdown element',
    defaults: { name: 'Get Select Options' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser',
      },
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'E.g. select#country, select[name="state"]',
        description: 'CSS selector for the select/dropdown element',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 3500,
        description: 'Maximum time to wait for selector to appear',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;

      let optionsResult: any = {};
      let browser: Browser | null = null;

      try {
        // Connect to browser via CDP
        browser = await chromium.connectOverCDP(cdpUrl);
        const context = browser.contexts()[0];
        const page = context.pages()[0] || (await context.newPage());

        // Wait for page to be ready
        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        // Basic debug info
        optionsResult.currentUrl = await page.url();
        optionsResult.selector = selector;

        // Wait for element to be available
        await page.waitForSelector(selector, { timeout: waitTimeout });
        const selectElement = await page.$(selector);
        
        if (!selectElement) {
          throw new Error(`Select element with selector "${selector}" not found`);
        }

        // Verify it's a select element
        const tagName = await selectElement.evaluate(el => el.tagName.toLowerCase());
        if (tagName !== 'select') {
          throw new Error(`Element is not a select element. Found: ${tagName}`);
        }

        // Get all options
        const options = await selectElement.evaluate((select: HTMLSelectElement) => {
          return Array.from(select.options).map(option => ({
            value: option.value,
            text: option.text,
            selected: option.selected,
            disabled: option.disabled,
          }));
        });

        // Get currently selected value
        const selectedValue = await selectElement.evaluate((select: HTMLSelectElement) => select.value);
        const selectedText = await selectElement.evaluate((select: HTMLSelectElement) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        optionsResult.result = 'success';
        optionsResult.options = options;
        optionsResult.optionCount = options.length;
        optionsResult.selectedValue = selectedValue;
        optionsResult.selectedText = selectedText;
        optionsResult.availableValues = options.map(opt => opt.value);
        optionsResult.availableTexts = options.map(opt => opt.text);

        await browser.close();

      } catch (e) {
        const errorMsg = (e as Error).message;

        // Error result with context
        optionsResult.result = 'error';
        optionsResult.error = errorMsg;
        optionsResult.selector = selector;

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      // Push result WITH session data
      results.push({ json: { ...session, selectOptions: optionsResult } });
    }

    return [results];
  }
}

