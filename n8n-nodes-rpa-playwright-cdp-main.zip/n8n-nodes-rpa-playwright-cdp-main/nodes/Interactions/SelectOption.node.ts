import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';

// Type declarations for DOM elements
declare global {
  interface HTMLSelectElement {
    value: string;
    options: HTMLOptionElement[];
    selectedIndex: number;
  }
  interface HTMLOptionElement {
    text: string;
  }
  interface Element {
    tagName: string;
  }
}

export class SelectOption implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Select Option',
    name: 'selectOption',
    icon: 'file:Select Option.png',
    group: ['transform'],
    version: 1,
    description: 'Selects an option from a select/dropdown element by value or text',
    defaults: { name: 'Select Option' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser',
      },
      {
        displayName: 'CSS Selector',
        name: 'selector',
        type: 'string',
        default: '',
        required: true,
        placeholder: 'E.g. select#country, select[name="state"]',
        description: 'CSS selector for the select/dropdown element',
      },
      {
        displayName: 'Selection Method',
        name: 'selectionMethod',
        type: 'options',
        options: [
          { name: 'By Value', value: 'value' },
          { name: 'By Text', value: 'text' },
          { name: 'By Index', value: 'index' },
        ],
        default: 'value',
        description: 'How to select the option: by value (option value attribute), by text (visible text), or by index (position starting from 0)',
      },
      {
        displayName: 'Option Value/Text/Index',
        name: 'optionValue',
        type: 'string',
        default: '',
        required: true,
        description: 'The value, text, or index of the option to select (depending on Selection Method)',
      },
      {
        displayName: 'Wait For Selector Timeout (ms)',
        name: 'waitTimeout',
        type: 'number',
        default: 3500,
        description: 'Maximum time to wait for selector to appear',
      },
      {
        displayName: 'Wait After Selection (ms)',
        name: 'waitAfter',
        type: 'number',
        default: 0,
        description: 'Wait time after selecting the option',
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const selector = this.getNodeParameter('selector', i) as string;
      const selectionMethod = this.getNodeParameter('selectionMethod', i, 'value') as string;
      const optionValue = this.getNodeParameter('optionValue', i) as string;
      const waitTimeout = this.getNodeParameter('waitTimeout', i, 5000) as number;
      const waitAfter = this.getNodeParameter('waitAfter', i, 0) as number;

      let selectResult: any = {};
      let browser: Browser | null = null;

      try {
        // Connect to browser via CDP
        browser = await chromium.connectOverCDP(cdpUrl);
        const context = browser.contexts()[0];
        const page = context.pages()[0] || (await context.newPage());

        // Wait for page to be ready
        await page.waitForLoadState('domcontentloaded', { timeout: 9000 });

        // Basic debug info
        selectResult.currentUrl = await page.url();
        selectResult.selector = selector;
        selectResult.selectionMethod = selectionMethod;
        selectResult.requestedValue = optionValue;

        // Wait for element to be available
        await page.waitForSelector(selector, { timeout: waitTimeout });
        const selectElement = await page.$(selector);
        
        if (!selectElement) {
          throw new Error(`Select element with selector "${selector}" not found`);
        }

        // Verify it's a select element
        const tagName = await selectElement.evaluate(el => el.tagName.toLowerCase());
        if (tagName !== 'select') {
          throw new Error(`Element is not a select element. Found: ${tagName}`);
        }

        // Get value before selection
        selectResult.valueBefore = await selectElement.evaluate((select: HTMLSelectElement) => select.value);
        selectResult.textBefore = await selectElement.evaluate((select: HTMLSelectElement) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        // Perform selection based on method
        if (selectionMethod === 'value') {
          await selectElement.selectOption({ value: optionValue });
        } else if (selectionMethod === 'text') {
          await selectElement.selectOption({ label: optionValue });
        } else if (selectionMethod === 'index') {
          const index = parseInt(optionValue, 10);
          if (isNaN(index)) {
            throw new Error(`Invalid index: ${optionValue}. Must be a number.`);
          }
          await selectElement.selectOption({ index });
        }

        // Get value after selection
        selectResult.valueAfter = await selectElement.evaluate((select: HTMLSelectElement) => select.value);
        selectResult.textAfter = await selectElement.evaluate((select: HTMLSelectElement) => {
          return select.options[select.selectedIndex]?.text || '';
        });

        // Verify selection was successful
        selectResult.selectionChanged = selectResult.valueBefore !== selectResult.valueAfter;

        // Wait after selection if requested
        if (waitAfter > 0) {
          await page.waitForTimeout(waitAfter);
        }

        selectResult.result = 'success';
        selectResult.selectedValue = selectResult.valueAfter;
        selectResult.selectedText = selectResult.textAfter;

        await browser.close();

      } catch (e) {
        const errorMsg = (e as Error).message;

        // Error result with context
        selectResult.result = 'error';
        selectResult.error = errorMsg;
        selectResult.selector = selector;
        selectResult.selectionMethod = selectionMethod;
        selectResult.requestedValue = optionValue;

        if (browser) {
          await browser.close().catch(() => {});
        }
      }

      // Push result WITH session data
      results.push({ json: { ...session, selectAction: selectResult } });
    }

    return [results];
  }
}

