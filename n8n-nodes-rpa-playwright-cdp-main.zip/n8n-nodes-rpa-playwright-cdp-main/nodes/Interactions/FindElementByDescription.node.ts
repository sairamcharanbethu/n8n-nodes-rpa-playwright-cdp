import {
  INodeType,
  INodeTypeDescription,
  IExecuteFunctions,
  INodeExecutionData,
  NodeConnectionType,
} from 'n8n-workflow';
import { chromium, Browser, Page } from 'playwright';
import { SessionObject } from '../../utils/SessionObject';
import axios from 'axios';
import { createClient } from 'redis';

export class FindElementByDescription implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Find Element By Description (AI)',
    name: 'findElementByDescription',
    icon: 'file:Find Element By Description.png',
    group: ['transform'],
    version: 1,
    description: 'Uses an LLM to find a reliable Playwright-compatible selector for a described element on the current page.',
    defaults: { name: 'Find Element' },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],

    credentials: [
      { name: 'aiProviderApi', required: false },
    ],

    properties: [
      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://localhost:9222/devtools/browser/...',
        required: true,
      },
      {
        displayName: 'Element Description',
        name: 'description',
        type: 'string',
        default: '',
        placeholder: 'E.g. "blue submit button in signup form"',
        required: true,
        description: 'Natural language description of the element to find',
      },
			{
				displayName: 'Element Type',
				name: 'elementType',
				type: 'options',
				options: [
					{ name: 'Input', value: 'input' },
					{ name: 'Button', value: 'button' },
					{ name: 'Select / Dropdown', value: 'select' },
					{ name: 'Checkbox', value: 'checkbox' },
					{ name: 'Radio', value: 'radio' },
					{ name: 'Textarea', value: 'textarea' },
					{ name: 'Div / Container', value: 'div' },
					{ name: 'Link / Anchor', value: 'a' },
					{ name: 'Image', value: 'img' },
					{ name: 'Span', value: 'span' },
					{ name: 'Paragraph', value: 'p' },
					{ name: 'Heading', value: 'h1,h2,h3,h4,h5,h6' },
					{ name: 'Table', value: 'table' },
					{ name: 'Other', value: '*' },
				],
				default: 'input',
				description: 'Type of HTML element: input (text fields), button (clickable buttons), select (dropdowns), checkbox, radio, textarea, div, a (links), img, span, p, h1,h2,h3,h4,h5,h6 (headings), table, or * (any)',
			},
      {
        displayName: 'AI Provider',
        name: 'aiProvider',
        type: 'options',
        options: [
          { name: 'OpenAI', value: 'openai' },
          { name: 'OpenRouter', value: 'openrouter' },
          { name: 'Gemini', value: 'gemini' },
          { name: 'Ollama (Local)', value: 'ollama' },
        ],
        default: 'openai',
        required: true,
      },
      {
        displayName: 'OpenAI / OpenRouter Model',
        name: 'openAiModel',
        type: 'string',
        default: 'gpt-4o-mini',
        placeholder: 'e.g. gpt-4o-mini, gpt-4o',
        required: true,
        displayOptions: {
          show: { aiProvider: ['openai', 'openrouter'] },
        },
      },
      {
        displayName: 'Gemini Model',
        name: 'geminiModel',
        type: 'string',
        default: 'gemini-1.5-pro',
        placeholder: 'e.g. gemini-1.5-pro, gemini-2.0',
        required: true,
        displayOptions: {
          show: { aiProvider: ['gemini'] },
        },
      },
      {
        displayName: 'Ollama Base URL',
        name: 'ollamaUrl',
        type: 'string',
        default: 'http://localhost:11434',
        placeholder: 'e.g. http://localhost:11434',
        required: true,
        displayOptions: {
          show: { aiProvider: ['ollama'] },
        },
      },
      {
        displayName: 'Ollama Model',
        name: 'ollamaModel',
        type: 'string',
        default: 'llama3.2',
        placeholder: 'e.g. llama3.2, mistral, qwen2.5',
        required: true,
        displayOptions: {
          show: { aiProvider: ['ollama'] },
        },
      },
      {
        displayName: 'Max Attempts',
        name: 'maxAttempts',
        type: 'number',
        default: 1,
        description: 'Number of AI retries per HTML chunk before failing',
      },
      {
        displayName: 'Enable Selector Cache',
        name: 'enableCache',
        type: 'boolean',
        default: true,
        description: 'Cache successful selectors to avoid repeated AI calls (saves time and costs)',
      },
    ],
  };



  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

  // Helper functions
  function parseAiJson(text: string) {
    const cleaned = text.replace(/```(json)?\n?/g, '').replace(/```$/, '').trim();
    return JSON.parse(cleaned);
  }

  function getRelevantHTML(html: string, maxLength = 18000): string {
    if (html.length <= maxLength) return html;
    const mid = Math.floor(html.length / 2);
    const start = Math.max(0, mid - maxLength / 2);
    return html.slice(start, start + maxLength);
  }

  // Redis cache helper
  async function getCachedSelector(cacheKey: string, redisUrl: string): Promise<any | null> {
    try {
      const client = createClient({ url: redisUrl });
      await client.connect();
      const cached = await client.get(cacheKey);
      await client.disconnect();
      if (cached) {
        return JSON.parse(cached);
      }
    } catch (error) {
      console.warn('Redis cache get failed:', error);
    }
    return null;
  }

  async function setCachedSelector(cacheKey: string, data: any, redisUrl: string): Promise<void> {
    try {
      const client = createClient({ url: redisUrl });
      await client.connect();
      await client.setEx(cacheKey, 2592000, JSON.stringify(data)); // 30 days TTL
      await client.disconnect();
    } catch (error) {
      console.warn('Redis cache set failed:', error);
    }
  }
    const aiProviderCheck = this.getNodeParameter('aiProvider', 0) as string;

    let credentials: any = null;
    // Only require credentials for non-local providers
    if (aiProviderCheck !== 'ollama') {
      credentials = await this.getCredentials('aiProviderApi');
      if (!credentials) throw new Error('No credentials provided for AI provider.');
      if ((credentials.provider === 'openai' || credentials.provider === 'openrouter') && !credentials.apiKey) {
        throw new Error('API Key missing for OpenAI / OpenRouter');
      }
      if (credentials.provider === 'gemini' && !credentials.googleApiKey) {
        throw new Error('Google API Key missing for Gemini');
      }
    }

    for (let i = 0; i < items.length; i++) {
      const session = items[i].json as unknown as SessionObject;
			const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;
      const description = this.getNodeParameter('description', i) as string;
      const aiProvider = this.getNodeParameter('aiProvider', i) as string;
      const maxAttempts = this.getNodeParameter('maxAttempts', i, 1) as number;
      const enableCache = this.getNodeParameter('enableCache', i, true) as boolean;
      const elementType = this.getNodeParameter('elementType', i) as string;

      let model = '';
      let ollamaUrl = '';
      if (aiProvider === 'openai' || aiProvider === 'openrouter') {
        model = this.getNodeParameter('openAiModel', i) as string;
      } else if (aiProvider === 'gemini') {
        model = this.getNodeParameter('geminiModel', i) as string;
      } else if (aiProvider === 'ollama') {
        model = this.getNodeParameter('ollamaModel', i) as string;
        ollamaUrl = this.getNodeParameter('ollamaUrl', i) as string;
      }

      if (!cdpUrl) throw new Error('Session object missing cdpUrl.');

      let browser: Browser | null = null;
      let page: Page | null = null;
      let pageHTML = '';
      let bodyHTML = '';
      let attempts = 0;
      let selector = '';
      let confidence = 0;
      let reasoning = '';
      let alternatives: string[] = [];
      let validated = false;
      let cacheHit = false;

      // Create cache key from domain + description + elementType
      const domain = cdpUrl.replace('ws://', '').replace('wss://', '').split('/')[0];
      const cacheKey = `selector:${domain}:${description.toLowerCase().replace(/\s+/g, '_')}:${elementType}`;
      const redisUrl = `redis://${process.env.REDIS_HOST || 'redis-cache'}:${process.env.REDIS_PORT || 6379}`;

      // Check cache first
      if (enableCache) {
        const cached = await getCachedSelector(cacheKey, redisUrl);
        if (cached && cached.selector) {
          selector = cached.selector;
          confidence = cached.confidence || 0.9;
          reasoning = 'Retrieved from cache';
          alternatives = cached.alternatives || [];
          validated = true;
          cacheHit = true;
        }
      }

      // Only fetch HTML if not from cache
      if (!cacheHit) {
        try {
          browser = await chromium.connectOverCDP(cdpUrl);
          const context = browser.contexts()[0];
          page = context.pages()[0] || (await context.newPage());
          await page.waitForLoadState('domcontentloaded', { timeout: 6000 });
          const rawHTML = await page.content();

          pageHTML = rawHTML
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
            .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
            .replace(/<!--[\s\S]*?-->/g, '');
          bodyHTML = pageHTML.match(/<body[^>]*>([\s\S]*)<\/body>/i)?.[1] || pageHTML;
        } catch (e) {
          if (browser) await browser.close().catch(() => {});
          throw new Error('Could not connect to browser/obtain HTML: ' + (e as Error).message);
        }
      }

function getRelevantHTMLByType(html: string, elementType: string, maxLength = 18000): string {
  let relevant = '';

  // Helper to prioritize elements with ID/name attributes
  const prioritize = (matches: string[]): string => {
    const withId = matches.filter(m => /\sid=["']/i.test(m));
    const withName = matches.filter(m => /\sname=["']/i.test(m));
    const others = matches.filter(m => !/\s(id|name)=["']/i.test(m));
    return [...withId, ...withName, ...others.slice(0, 20)].join('\n');
  };

  switch (elementType.toLowerCase()) {
    case 'input': {
      const matches = html.match(/<input[^>]*>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'button': {
      const matches = html.match(/<button[^>]*>.*?<\/button>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'select': {
      const matches = html.match(/<select[^>]*>[\s\S]*?<\/select>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'checkbox': {
      const matches = html.match(/<input[^>]*type=["']?checkbox["']?[^>]*>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'radio': {
      const matches = html.match(/<input[^>]*type=["']?radio["']?[^>]*>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'textarea': {
      const matches = html.match(/<textarea[^>]*>[\s\S]*?<\/textarea>/gi) || [];
      relevant = prioritize(matches);
      break;
    }
    case 'a': {
      const matches = html.match(/<a[^>]*>.*?<\/a>/gi) || [];
      relevant = prioritize(matches.slice(0, 50)); // Limit links
      break;
    }
    case 'div':
    case 'span':
    case 'p':
    case 'img':
    case 'h1,h2,h3,h4,h5,h6':
    case 'table':
      // For non-interactive elements, use original logic but limit
      relevant = html;
      break;
    case '*':
      relevant = html;
      break;
    default:
      relevant = html;
  }

  if (!relevant) relevant = html;

  return relevant.length > maxLength ? relevant.slice(0, maxLength) : relevant;
}

      // Only process HTML and call AI if not from cache
      if (!cacheHit) {
        bodyHTML = getRelevantHTMLByType(bodyHTML, elementType, 12000);
        // ------------------------
        // Slice HTML into chunks for multiple attempts
        // ------------------------
        const chunkSize = 12000;
        const htmlChunks: string[] = [];
        for (let start = 0; start < bodyHTML.length; start += chunkSize) {
          htmlChunks.push(bodyHTML.slice(start, start + chunkSize));
        }

        for (const chunk of htmlChunks) {
        attempts = 0;
        while (attempts < maxAttempts && !validated) {
          attempts++;
					const elementType = this.getNodeParameter('elementType', i) as string;
          const prompt = `Find CSS selector for: "${description}" (type: ${elementType})
Priority: 1) ID attribute, 2) name/unique class, 3) data attributes

HTML:
${getRelevantHTML(chunk, 18000)}

Return JSON only:
{"selector":"<css>","confidence":0-1,"reasoning":"<why>","alternatives":["<alt>"]}`.trim();

          let apiUrl = '';
          let headers: any = {};
          let body: any = {};

          if (aiProvider === 'openai') {
            apiUrl = 'https://api.openai.com/v1/chat/completions';
            headers = { Authorization: `Bearer ${credentials.apiKey}` };
            body = { model, messages: [{ role: 'user', content: prompt }], temperature: 0.1, max_tokens: 200 };
          } else if (aiProvider === 'openrouter') {
            apiUrl = 'https://openrouter.ai/api/v1/chat/completions';
            headers = { Authorization: `Bearer ${credentials.apiKey}` };
            body = { model, messages: [{ role: 'user', content: prompt }], temperature: 0.1, max_tokens: 200 };
          } else if (aiProvider === 'gemini') {
            apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${credentials.googleApiKey}`;
            headers = { 'Content-Type': 'application/json' };
            body = { contents: [{ parts: [{ text: prompt }] }] };
          } else if (aiProvider === 'ollama') {
            apiUrl = `${ollamaUrl}/api/generate`;
            headers = { 'Content-Type': 'application/json' };
            body = {
              model,
              prompt,
              stream: false,
              options: {
                temperature: 0.1,
                num_predict: 200
              }
            };
          }

          try {
            const aiResponse = await axios.post(apiUrl, body, { headers });
            let parsed: any = {};

            if (aiProvider === 'gemini') {
              const geminiContent = aiResponse.data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
              parsed = typeof geminiContent === 'string' ? parseAiJson(geminiContent) : geminiContent;
            } else if (aiProvider === 'ollama') {
              const ollamaContent = aiResponse.data?.response ?? '';
              parsed = typeof ollamaContent === 'string' ? parseAiJson(ollamaContent) : ollamaContent;
            } else {
              const content = aiResponse.data.choices?.[0]?.message?.content ?? aiResponse.data.choices?.[0]?.text ?? '';
              parsed = typeof content === 'string' ? parseAiJson(content) : content;
            }

            selector = parsed.selector || '';
            confidence = parsed.confidence || 0;
            reasoning = parsed.reasoning || '';
            alternatives = parsed.alternatives || [];

            // ------------------------
            // Validate selector + alternatives
            // ------------------------
            // for (const sel of [selector, ...alternatives]) {
            //   if (!sel || !page) continue;
            //   try {
            //     const elementHandle = await page.$(sel);
            //     if (elementHandle) {
            //       selector = sel;
            //       validated = true;
            //       break;
            //     }
            //   } catch {
            //     validated = false;
            //   }
            // }
						//for (const sel of [selector, ...alternatives]) {
						for (const sel of [selector, ...alternatives.slice(0, 1)]) {
							if (!sel || !page) continue;
							try {
								const elementHandle = await page.$(sel);
								if (elementHandle) {
									// Get tagName to validate against requested type
									//const tagName = (await elementHandle.evaluate(el => el.tagName.toLowerCase())) || '';
									//const typeAttr = (await elementHandle.evaluate(el => el.getAttribute('type'))) || '';
									const { tagName, typeAttr } = await elementHandle.evaluate(el => ({
										tagName: el.tagName.toLowerCase(),
										typeAttr: el.getAttribute('type') || ''
									}));
									const elementType = (this.getNodeParameter('elementType', i) as string).toLowerCase();

									let typeMatches = false;
									switch (elementType) {
										case 'input':
											// For input type, only match text-like inputs (not buttons, submit, etc.)
											typeMatches = tagName === 'input' &&
												(!typeAttr || ['text', 'email', 'password', 'search', 'tel', 'url', 'number', 'date', 'time', 'datetime-local', 'month', 'week'].includes(typeAttr));
											break;
										case 'button':
											// Match button elements OR input elements with button-like types
											typeMatches = tagName === 'button' ||
												(tagName === 'input' && ['button', 'submit', 'reset'].includes(typeAttr));
											break;
										case 'select': typeMatches = tagName === 'select'; break;
										case 'checkbox': typeMatches = tagName === 'input' && typeAttr === 'checkbox'; break;
										case 'radio': typeMatches = tagName === 'input' && typeAttr === 'radio'; break;
										case 'textarea': typeMatches = tagName === 'textarea'; break;
										case 'div': typeMatches = tagName === 'div'; break;
										case 'a': typeMatches = tagName === 'a'; break;
										case 'img': typeMatches = tagName === 'img'; break;
										case 'span': typeMatches = tagName === 'span'; break;
										case 'p': typeMatches = tagName === 'p'; break;
										case 'h1,h2,h3,h4,h5,h6': typeMatches = /^h[1-6]$/.test(tagName); break;
										case 'table': typeMatches = tagName === 'table'; break;
										case '*': typeMatches = true; break;
									}

									if (typeMatches) {
										selector = sel;
										validated = true;
										break;
									}
								}
							} catch {
								validated = false;
							}
						}

          } catch (err: any) {
            reasoning = `AI did not return valid JSON or failed: ${err.message}`;
          }
        }
        if (validated) break;
        }
      }

      if (browser) await browser.close(); // Close after all validation attempts

      // Save to cache if successful and not from cache
      if (validated && !cacheHit && enableCache && selector) {
        await setCachedSelector(cacheKey, {
          selector,
          confidence,
          alternatives,
          timestamp: new Date().toISOString(),
        }, redisUrl);
      }

      results.push({
        json: {
          ...session,
          selector: selector, // Top-level for easy AI access
          elementDescription: description,
          findElementResult: {
            selector,
            confidence,
            reasoning,
            attempts,
            alternatives,
            validated,
            success: validated,
            elementType,
            cacheHit,
            cached: cacheHit,
          },
        },
      });
    }

    return [results];
  }
}
