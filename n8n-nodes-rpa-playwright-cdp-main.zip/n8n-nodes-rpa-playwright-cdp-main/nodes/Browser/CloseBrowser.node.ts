import { INodeType, INodeTypeDescription, IExecuteFunctions, INodeExecutionData, NodeConnectionType } from 'n8n-workflow';
import { closeSession } from '../../utils/sessionManager';
import { SessionObject } from '../../utils/SessionObject';
import { chromium } from 'playwright';

export class CloseBrowser implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Close Browser',
    name: 'closeBrowser',
    icon: 'file:Close Browser.png',
    group: ['transform'],
    version: 1,
    description: 'Closes the browser/session created by Launch Browser. Requires CDP URL from Launch Browser.',
    defaults: {
      name: 'Close Browser',
    },
    usableAsTool: true,
    inputs: [NodeConnectionType.Main],
    outputs: [NodeConnectionType.Main],
    properties: [
			      {
        displayName: 'CDP URL',
        name: 'cdpUrl',
        type: 'string',
        default: '',
        placeholder: 'E.g. ws://selenium-hub:4444/session/{sessionId}/se/cdp',
        required: true,
        description: 'CDP WebSocket URL from Launch Browser (used to extract session info and close the browser session)',
      }
		],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const results: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i++) {
      const session: SessionObject = items[i].json as unknown as SessionObject;
      const cdpUrl = this.getNodeParameter('cdpUrl', i) as string;

      // If CDP URL is provided, parse it to get session info
      let sessionToClose = { ...session };
      
      // Check if we need to extract session info from CDP URL
      if (cdpUrl) {
        // Parse CDP URL: ws://selenium-hub:4444/session/{sessionId}/se/cdp
        // or wss://host:port/session/{sessionId}/se/cdp
        try {
          const urlMatch = cdpUrl.match(/^wss?:\/\/([^\/]+)\/session\/([^\/]+)\//);
          if (urlMatch) {
            const host = urlMatch[1]; // e.g., selenium-hub:4444
            const sessionId = urlMatch[2]; // e.g., 80c9d9fa955c05bc94977b2b1aeb0593
            const seleniumHubUrl = `http://${host}`; // Convert ws:// to http://
            
            sessionToClose.sessionId = sessionId;
            sessionToClose.seleniumHubUrl = seleniumHubUrl;
            sessionToClose.cdpUrl = cdpUrl;
          } else {
            // If regex doesn't match, try alternative parsing
            throw new Error(`Unable to parse CDP URL: ${cdpUrl}. Expected format: ws://host:port/session/{sessionId}/se/cdp`);
          }
        } catch (error: any) {
          // If parsing fails, return error
          results.push({
            json: {
              ...session,
              success: false,
              error: error.message || 'Failed to parse CDP URL',
              step: 'close',
              cdpUrl,
              timestamp: new Date().toISOString(),
            },
          });
          continue;
        }
      }

      // Attempt to close the session
      try {
        const closedSession = await closeSession(sessionToClose);
      results.push({ json: closedSession as unknown as { [key: string]: any } });
      } catch (error: any) {
        results.push({
          json: {
            ...sessionToClose,
            success: false,
            error: error.message || 'Failed to close session',
            step: 'close',
            timestamp: new Date().toISOString(),
          },
        });
      }
    }
    return [results];
  }
}
