# How to See Ollama Option in n8n

## Problem

Ollama option not appearing in FindElement node's AI Provider dropdown.

## Cause

n8n loads custom nodes at startup. Changes to nodes require n8n restart to be visible.

## Solution

### Step 1: Restart n8n

**If running n8n locally**:
```bash
# Stop n8n (Ctrl+C if running in terminal)
# Then restart:
n8n start
```

**If running n8n in Docker**:
```bash
docker restart n8n

# Or if using docker-compose:
docker-compose restart n8n
```

**If running n8n as a service**:
```bash
# Windows
sc stop n8n
sc start n8n

# Linux/Mac
sudo systemctl restart n8n
```

### Step 2: Reload the Workflow

1. Open your workflow in n8n
2. Click on the FindElement node
3. Look at the "AI Provider" dropdown
4. You should now see: OpenAI, OpenRouter, Gemini, **Ollama (Local)**

### Step 3: Verify the Build

If Ollama still doesn't appear, verify the build was successful:

```bash
cd C:\n8n-src\n8n-workflows\n8n-nodes-rpa-playwright-cdp-main

# Check if dist files were updated
dir dist\nodes\Interactions\FindElementByDescription.node.js

# Rebuild if needed
npm run build
```

### Step 4: Check n8n Custom Nodes Path

Make sure n8n is loading from the correct directory:

**Option A: Global installation**
```bash
# Check where n8n is loading custom nodes from
n8n info

# Make sure this package is in the right location
```

**Option B: Local development**
```bash
# Link the package for development
npm link

# Then restart n8n
```

## Quick Test

After restarting n8n:

1. Open workflow
2. Edit FindElement node
3. Click "AI Provider" dropdown
4. Should see these options:
   - OpenAI
   - OpenRouter
   - Gemini
   - **Ollama (Local)** ← New option

## If Still Not Showing

### Check package.json

Verify the node is registered:
```json
{
  "n8n": {
    "nodes": [
      "dist/nodes/Interactions/FindElementByDescription.node.js",
      ...
    ]
  }
}
```

### Check dist file

Verify Ollama code is in compiled file:
```bash
# Search for "ollama" in the compiled file
findstr /i "ollama" dist\nodes\Interactions\FindElementByDescription.node.js

# Or on Linux/Mac:
grep -i "ollama" dist/nodes/Interactions/FindElementByDescription.node.js
```

Should see "ollama" multiple times in the output.

### Check n8n logs

Look for errors when n8n starts:
```bash
# Run n8n in terminal to see logs
n8n start

# Look for lines like:
# "Loaded nodes from: ..."
# "Error loading node: ..." (if there's a problem)
```

## Alternative: Manual Node Reinstall

If restart doesn't work:

```bash
cd C:\n8n-src\n8n-workflows\n8n-nodes-rpa-playwright-cdp-main

# Clean build
npm run clean
npm run build

# Reinstall in n8n
cd ~/.n8n/nodes  # Or your n8n custom nodes directory
rm -rf n8n-nodes-rpa-playwright  # Remove old version
cp -r C:\n8n-src\n8n-workflows\n8n-nodes-rpa-playwright-cdp-main .

# Restart n8n
n8n start
```

## Expected Result

After proper restart, the AI Provider dropdown should show:

```
┌─────────────────────┐
│ AI Provider         │
├─────────────────────┤
│ ○ OpenAI            │
│ ○ OpenRouter        │
│ ○ Gemini            │
│ ○ Ollama (Local)    │ ← NEW!
└─────────────────────┘
```

When you select "Ollama (Local)", two new fields appear:
- Ollama Base URL (default: http://localhost:11434)
- Ollama Model (default: llama3.2)

## Quick Verification Command

Run this to confirm Ollama code is in the build:

```bash
cd C:\n8n-src\n8n-workflows\n8n-nodes-rpa-playwright-cdp-main
findstr /i "Ollama" dist\nodes\Interactions\FindElementByDescription.node.js | more
```

You should see multiple lines containing "Ollama".

---

**TL;DR**: Restart n8n to see the new Ollama option! 🔄

